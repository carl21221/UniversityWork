﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeetingScheduler
{
    class Meeting
    {
        private int meetingID;

        private DateTime startDateTime;

        private Room room;

        private List<User> participants;
        private User initiator;
        public Meeting(int id, int day, int month, int year, int hour, int min,
                       string roomID, string buildingID, int initiatorID, List<User> participantList)
        {
            meetingID = id;
            startDateTime = new DateTime(year, month, day, hour, min, 0);

            room = DataFileHandler.GetRoomAsObject(roomID, buildingID);
            initiator = DataFileHandler.GetUserObject($@"{initiatorID}");
            participants = participantList;
        }
        // meetingID,day,month,year,hour,min,roomNum,buildingNum,initiator|userID1,userID2,userID3
        public Meeting(int newID, MeetingRequest r)
        {
            meetingID = newID;
            this.startDateTime = r.GetDate();
            this.room = r.GetRoomPref();

            this.participants = r.GetPeopleConfirmed();
            this.initiator = r.GetInitiator();
        }
        //Getters
        public int GetMeetingID() { return meetingID; }
        public DateTime GetDate() { return startDateTime; }
        public Room GetRoom() { return room; }
        public List<User> GetParticipants() { return this.participants; }
        public User GetInitiator() { return this.initiator; }
        public int GetInitiatorID() { return initiator.GetID(); }

        //Setters
        public void SetDate(DateTime date) { this.startDateTime = date; }
        public void SetRoom(Room room) { this.room = room; }
        public void SetParticipants(List<User> newList) { this.participants = newList; }
        public void SetInitiator(User p) { this.initiator = p; }

        //Others
        public void AddParticpant(User p) { this.participants.Add(p); }
        public void RemoveParticpant(User pToRemove)
        {
            foreach(User p in this.participants)
            {
                if (p.GetID() == pToRemove.GetID()) this.participants.Remove(p);
            }
        }
    }
}
