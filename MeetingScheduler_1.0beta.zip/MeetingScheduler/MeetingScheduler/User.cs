﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeetingScheduler
{
    class User
    {
        private int userID;
        private string password;
        private string firstName;
        private string secondName;
        private string title;

        public User(int newID, string newPassword, string newTitle, string newFirstName, string newSecondName)
        {
            this.userID = newID;
            this.password = newPassword;
            this.title = newTitle;
            this.firstName = newFirstName;
            this.secondName = newSecondName;
        }
        public int GetID() { return this.userID; }
        public string GetPassword() { return this.password; }
        public string GetFirstName() { return this.firstName; }
        public string GetSecondName() { return this.secondName; }
        public string GetFullName() { return this.firstName + " " + this.secondName; }
        public string GetTitle() { return this.title; }
        public void SetPassword(string newPassword) { this.password = newPassword; }
    }
}
