﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeetingScheduler
{
    class TimeSlots
    {
        List<TimeSlot> slots = new List<TimeSlot>();
    }
}
