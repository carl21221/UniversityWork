﻿namespace MeetingScheduler
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpbox_LogIn = new System.Windows.Forms.GroupBox();
            this.lbl_LogIn_Password = new System.Windows.Forms.Label();
            this.lbl_LogIn_UserID = new System.Windows.Forms.Label();
            this.btn_LogIn_Register = new System.Windows.Forms.Button();
            this.btn_LogIn_Submit = new System.Windows.Forms.Button();
            this.txtbox_LogIn_Password = new System.Windows.Forms.TextBox();
            this.txtbox_LogIn_UserID = new System.Windows.Forms.TextBox();
            this.grpbox_CreateMeetingRequest = new System.Windows.Forms.GroupBox();
            this.btn_CreateMeetingRequest_Cancel = new System.Windows.Forms.Button();
            this.btn_CreateMeetingRequest_RemoveParticipant = new System.Windows.Forms.Button();
            this.btn_CreateMeetingRequest_AddParticipant = new System.Windows.Forms.Button();
            this.combobox_CreateMeetingRequest_Time = new System.Windows.Forms.ComboBox();
            this.combobox_CreateMeetingRequest_AvailableRooms = new System.Windows.Forms.ComboBox();
            this.lbl_CreateMeetingRequest_Rooms = new System.Windows.Forms.Label();
            this.lbl_CreateMeetingRequest_AvailableParticipants = new System.Windows.Forms.Label();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btn_CreateMeetingRequest_Submit = new System.Windows.Forms.Button();
            this.listbox_CreateMeetingRequest_PeopleInvited = new System.Windows.Forms.ListBox();
            this.combobox_CreateMeetingRequest_AvailablePeople = new System.Windows.Forms.ComboBox();
            this.checkbox_CreateMeetingRequest_NeedWCAccess = new System.Windows.Forms.CheckBox();
            this.checkbox_CreateMeetingRequest_NeedPA = new System.Windows.Forms.CheckBox();
            this.checkbox_CreateMeetingRequest_NeedProjecter = new System.Windows.Forms.CheckBox();
            this.groupbox_MainMenu = new System.Windows.Forms.GroupBox();
            this.btn_MainMenu_CreateMeetingRequest = new System.Windows.Forms.Button();
            this.listbox_MainMenu_MyMeetingRequests = new System.Windows.Forms.ListBox();
            this.lbl_MainMenu_MyMeetingRequests = new System.Windows.Forms.Label();
            this.btn_MainMenu_CancelMeeting = new System.Windows.Forms.Button();
            this.lbl_MainMenu_MyMeetings = new System.Windows.Forms.Label();
            this.listbox_MainMenu_MyMeetings = new System.Windows.Forms.ListBox();
            this.lbl_MainMenu_MeetingsToAccept = new System.Windows.Forms.Label();
            this.lbl_MainMenu_UpcomingMeetings = new System.Windows.Forms.Label();
            this.listbox_MainMenu_MeetingsToAccept = new System.Windows.Forms.ListBox();
            this.btn_MainMenu_AcceptMeeting = new System.Windows.Forms.Button();
            this.btn_MainMenu_DeclineMeeting = new System.Windows.Forms.Button();
            this.listbox_MainMenu_UpcomingMeetings = new System.Windows.Forms.ListBox();
            this.groupbox_ViewMeetingRequestInfo = new System.Windows.Forms.GroupBox();
            this.lbl_ViewMeetingRequestInfo_Confirmed = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingRequestInfo_Unavailable = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingRequestInfo_Invited = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingRequestInfo_BuildingNumber = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingRequestInfo_RoomNumber = new System.Windows.Forms.Label();
            this.listbox_ViewMeetingRequestInfo_Confirmed = new System.Windows.Forms.ListBox();
            this.listbox_ViewMeetingRequestInfo_Unavailable = new System.Windows.Forms.ListBox();
            this.listbox_ViewMeetingRequestInfo_Invited = new System.Windows.Forms.ListBox();
            this.lbl_ViewMeetingRequestInfo_InitiatorName = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingRequestInfo_WCAccess = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingRequestInfo_PASystem = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingRequestInfo_Projector = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingRequestInfo_DateScheduled = new System.Windows.Forms.Label();
            this.groupbox_ViewMeetingInfo = new System.Windows.Forms.GroupBox();
            this.lbl_ViewMeetingInfo_Participants = new System.Windows.Forms.Label();
            this.listbox_ViewMeetingInfo_Participants = new System.Windows.Forms.ListBox();
            this.lbl_ViewMeetingInfo_WCAccess = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingInfo_PASystem = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingInfo_Projector = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingInfo_BuildingID = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingInfo_RoomID = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingInfo_DateScheduled = new System.Windows.Forms.Label();
            this.lbl_ViewMeetingInfo_InitiatorName = new System.Windows.Forms.Label();
            this.btn_LogOut = new System.Windows.Forms.Button();
            this.btn_MainMenu_Finalise = new System.Windows.Forms.Button();
            this.grpbox_LogIn.SuspendLayout();
            this.grpbox_CreateMeetingRequest.SuspendLayout();
            this.groupbox_MainMenu.SuspendLayout();
            this.groupbox_ViewMeetingRequestInfo.SuspendLayout();
            this.groupbox_ViewMeetingInfo.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpbox_LogIn
            // 
            this.grpbox_LogIn.Controls.Add(this.lbl_LogIn_Password);
            this.grpbox_LogIn.Controls.Add(this.lbl_LogIn_UserID);
            this.grpbox_LogIn.Controls.Add(this.btn_LogIn_Register);
            this.grpbox_LogIn.Controls.Add(this.btn_LogIn_Submit);
            this.grpbox_LogIn.Controls.Add(this.txtbox_LogIn_Password);
            this.grpbox_LogIn.Controls.Add(this.txtbox_LogIn_UserID);
            this.grpbox_LogIn.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.grpbox_LogIn.Location = new System.Drawing.Point(12, 12);
            this.grpbox_LogIn.Name = "grpbox_LogIn";
            this.grpbox_LogIn.Size = new System.Drawing.Size(338, 184);
            this.grpbox_LogIn.TabIndex = 0;
            this.grpbox_LogIn.TabStop = false;
            this.grpbox_LogIn.Text = "Log In Screen";
            // 
            // lbl_LogIn_Password
            // 
            this.lbl_LogIn_Password.AutoSize = true;
            this.lbl_LogIn_Password.Location = new System.Drawing.Point(42, 88);
            this.lbl_LogIn_Password.Name = "lbl_LogIn_Password";
            this.lbl_LogIn_Password.Size = new System.Drawing.Size(73, 17);
            this.lbl_LogIn_Password.TabIndex = 5;
            this.lbl_LogIn_Password.Text = "Password:";
            // 
            // lbl_LogIn_UserID
            // 
            this.lbl_LogIn_UserID.AutoSize = true;
            this.lbl_LogIn_UserID.Location = new System.Drawing.Point(42, 37);
            this.lbl_LogIn_UserID.Name = "lbl_LogIn_UserID";
            this.lbl_LogIn_UserID.Size = new System.Drawing.Size(59, 17);
            this.lbl_LogIn_UserID.TabIndex = 4;
            this.lbl_LogIn_UserID.Text = "User ID:";
            // 
            // btn_LogIn_Register
            // 
            this.btn_LogIn_Register.BackColor = System.Drawing.Color.White;
            this.btn_LogIn_Register.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LogIn_Register.Location = new System.Drawing.Point(167, 137);
            this.btn_LogIn_Register.Name = "btn_LogIn_Register";
            this.btn_LogIn_Register.Size = new System.Drawing.Size(75, 34);
            this.btn_LogIn_Register.TabIndex = 3;
            this.btn_LogIn_Register.Text = "Register";
            this.btn_LogIn_Register.UseVisualStyleBackColor = false;
            this.btn_LogIn_Register.Visible = false;
            this.btn_LogIn_Register.Click += new System.EventHandler(this.btn_LogIn_Register_Click);
            // 
            // btn_LogIn_Submit
            // 
            this.btn_LogIn_Submit.BackColor = System.Drawing.Color.White;
            this.btn_LogIn_Submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LogIn_Submit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_LogIn_Submit.Location = new System.Drawing.Point(86, 137);
            this.btn_LogIn_Submit.Name = "btn_LogIn_Submit";
            this.btn_LogIn_Submit.Size = new System.Drawing.Size(75, 34);
            this.btn_LogIn_Submit.TabIndex = 2;
            this.btn_LogIn_Submit.Text = "Log In";
            this.btn_LogIn_Submit.UseVisualStyleBackColor = false;
            this.btn_LogIn_Submit.Click += new System.EventHandler(this.btn_LogIn_Submit_Click);
            // 
            // txtbox_LogIn_Password
            // 
            this.txtbox_LogIn_Password.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.txtbox_LogIn_Password.Location = new System.Drawing.Point(42, 108);
            this.txtbox_LogIn_Password.Name = "txtbox_LogIn_Password";
            this.txtbox_LogIn_Password.Size = new System.Drawing.Size(245, 23);
            this.txtbox_LogIn_Password.TabIndex = 1;
            // 
            // txtbox_LogIn_UserID
            // 
            this.txtbox_LogIn_UserID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.txtbox_LogIn_UserID.Location = new System.Drawing.Point(42, 56);
            this.txtbox_LogIn_UserID.Name = "txtbox_LogIn_UserID";
            this.txtbox_LogIn_UserID.Size = new System.Drawing.Size(245, 23);
            this.txtbox_LogIn_UserID.TabIndex = 0;
            // 
            // grpbox_CreateMeetingRequest
            // 
            this.grpbox_CreateMeetingRequest.Controls.Add(this.btn_CreateMeetingRequest_Cancel);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.btn_CreateMeetingRequest_RemoveParticipant);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.btn_CreateMeetingRequest_AddParticipant);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.combobox_CreateMeetingRequest_Time);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.combobox_CreateMeetingRequest_AvailableRooms);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.lbl_CreateMeetingRequest_Rooms);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.lbl_CreateMeetingRequest_AvailableParticipants);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.dateTimePicker1);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.btn_CreateMeetingRequest_Submit);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.listbox_CreateMeetingRequest_PeopleInvited);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.combobox_CreateMeetingRequest_AvailablePeople);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.checkbox_CreateMeetingRequest_NeedWCAccess);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.checkbox_CreateMeetingRequest_NeedPA);
            this.grpbox_CreateMeetingRequest.Controls.Add(this.checkbox_CreateMeetingRequest_NeedProjecter);
            this.grpbox_CreateMeetingRequest.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.grpbox_CreateMeetingRequest.Location = new System.Drawing.Point(792, 206);
            this.grpbox_CreateMeetingRequest.Name = "grpbox_CreateMeetingRequest";
            this.grpbox_CreateMeetingRequest.Size = new System.Drawing.Size(422, 545);
            this.grpbox_CreateMeetingRequest.TabIndex = 1;
            this.grpbox_CreateMeetingRequest.TabStop = false;
            this.grpbox_CreateMeetingRequest.Text = "Create Meeting Request";
            this.grpbox_CreateMeetingRequest.Visible = false;
            // 
            // btn_CreateMeetingRequest_Cancel
            // 
            this.btn_CreateMeetingRequest_Cancel.BackColor = System.Drawing.Color.White;
            this.btn_CreateMeetingRequest_Cancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CreateMeetingRequest_Cancel.Location = new System.Drawing.Point(302, 500);
            this.btn_CreateMeetingRequest_Cancel.Name = "btn_CreateMeetingRequest_Cancel";
            this.btn_CreateMeetingRequest_Cancel.Size = new System.Drawing.Size(102, 32);
            this.btn_CreateMeetingRequest_Cancel.TabIndex = 12;
            this.btn_CreateMeetingRequest_Cancel.Text = "Cancel";
            this.btn_CreateMeetingRequest_Cancel.UseVisualStyleBackColor = false;
            this.btn_CreateMeetingRequest_Cancel.Click += new System.EventHandler(this.button1_Click);
            // 
            // btn_CreateMeetingRequest_RemoveParticipant
            // 
            this.btn_CreateMeetingRequest_RemoveParticipant.BackColor = System.Drawing.Color.White;
            this.btn_CreateMeetingRequest_RemoveParticipant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CreateMeetingRequest_RemoveParticipant.Location = new System.Drawing.Point(94, 454);
            this.btn_CreateMeetingRequest_RemoveParticipant.Name = "btn_CreateMeetingRequest_RemoveParticipant";
            this.btn_CreateMeetingRequest_RemoveParticipant.Size = new System.Drawing.Size(72, 32);
            this.btn_CreateMeetingRequest_RemoveParticipant.TabIndex = 11;
            this.btn_CreateMeetingRequest_RemoveParticipant.Text = "Remove Participant";
            this.btn_CreateMeetingRequest_RemoveParticipant.UseVisualStyleBackColor = false;
            this.btn_CreateMeetingRequest_RemoveParticipant.Click += new System.EventHandler(this.btn_CreateMeetingRequest_RemoveParticipant_Click);
            // 
            // btn_CreateMeetingRequest_AddParticipant
            // 
            this.btn_CreateMeetingRequest_AddParticipant.BackColor = System.Drawing.Color.White;
            this.btn_CreateMeetingRequest_AddParticipant.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CreateMeetingRequest_AddParticipant.Location = new System.Drawing.Point(16, 454);
            this.btn_CreateMeetingRequest_AddParticipant.Name = "btn_CreateMeetingRequest_AddParticipant";
            this.btn_CreateMeetingRequest_AddParticipant.Size = new System.Drawing.Size(72, 32);
            this.btn_CreateMeetingRequest_AddParticipant.TabIndex = 10;
            this.btn_CreateMeetingRequest_AddParticipant.Text = "Add";
            this.btn_CreateMeetingRequest_AddParticipant.UseVisualStyleBackColor = false;
            this.btn_CreateMeetingRequest_AddParticipant.Click += new System.EventHandler(this.btn_CreateMeetingRequest_AddParticipant_Click);
            // 
            // combobox_CreateMeetingRequest_Time
            // 
            this.combobox_CreateMeetingRequest_Time.FormattingEnabled = true;
            this.combobox_CreateMeetingRequest_Time.Items.AddRange(new object[] {
            "08:00",
            "09:00",
            "10:00",
            "11:00",
            "12:00",
            "13:00",
            "14:00",
            "15:00",
            "16:00",
            "17:00"});
            this.combobox_CreateMeetingRequest_Time.Location = new System.Drawing.Point(149, 28);
            this.combobox_CreateMeetingRequest_Time.MaxDropDownItems = 10;
            this.combobox_CreateMeetingRequest_Time.Name = "combobox_CreateMeetingRequest_Time";
            this.combobox_CreateMeetingRequest_Time.Size = new System.Drawing.Size(108, 25);
            this.combobox_CreateMeetingRequest_Time.TabIndex = 9;
            this.combobox_CreateMeetingRequest_Time.Text = "[Choose time]";
            this.combobox_CreateMeetingRequest_Time.SelectedIndexChanged += new System.EventHandler(this.combobox_CreateMeetingRequest_Time_SelectedIndexChanged);
            // 
            // combobox_CreateMeetingRequest_AvailableRooms
            // 
            this.combobox_CreateMeetingRequest_AvailableRooms.FormattingEnabled = true;
            this.combobox_CreateMeetingRequest_AvailableRooms.Location = new System.Drawing.Point(16, 162);
            this.combobox_CreateMeetingRequest_AvailableRooms.Name = "combobox_CreateMeetingRequest_AvailableRooms";
            this.combobox_CreateMeetingRequest_AvailableRooms.Size = new System.Drawing.Size(388, 25);
            this.combobox_CreateMeetingRequest_AvailableRooms.TabIndex = 8;
            this.combobox_CreateMeetingRequest_AvailableRooms.SelectedIndexChanged += new System.EventHandler(this.combobox_CreateMeetingRequest_AvailableRooms_SelectedIndexChanged);
            // 
            // lbl_CreateMeetingRequest_Rooms
            // 
            this.lbl_CreateMeetingRequest_Rooms.AutoSize = true;
            this.lbl_CreateMeetingRequest_Rooms.Location = new System.Drawing.Point(13, 140);
            this.lbl_CreateMeetingRequest_Rooms.Name = "lbl_CreateMeetingRequest_Rooms";
            this.lbl_CreateMeetingRequest_Rooms.Size = new System.Drawing.Size(56, 17);
            this.lbl_CreateMeetingRequest_Rooms.TabIndex = 7;
            this.lbl_CreateMeetingRequest_Rooms.Text = "Rooms:";
            // 
            // lbl_CreateMeetingRequest_AvailableParticipants
            // 
            this.lbl_CreateMeetingRequest_AvailableParticipants.AutoSize = true;
            this.lbl_CreateMeetingRequest_AvailableParticipants.Location = new System.Drawing.Point(13, 242);
            this.lbl_CreateMeetingRequest_AvailableParticipants.Name = "lbl_CreateMeetingRequest_AvailableParticipants";
            this.lbl_CreateMeetingRequest_AvailableParticipants.Size = new System.Drawing.Size(147, 17);
            this.lbl_CreateMeetingRequest_AvailableParticipants.TabIndex = 6;
            this.lbl_CreateMeetingRequest_AvailableParticipants.Text = "Available Participants:";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateTimePicker1.Location = new System.Drawing.Point(16, 28);
            this.dateTimePicker1.MinDate = new System.DateTime(2020, 12, 6, 18, 36, 42, 0);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(126, 23);
            this.dateTimePicker1.TabIndex = 0;
            this.dateTimePicker1.Value = new System.DateTime(2020, 12, 6, 18, 36, 42, 0);
            this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
            // 
            // btn_CreateMeetingRequest_Submit
            // 
            this.btn_CreateMeetingRequest_Submit.BackColor = System.Drawing.Color.White;
            this.btn_CreateMeetingRequest_Submit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_CreateMeetingRequest_Submit.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_CreateMeetingRequest_Submit.ForeColor = System.Drawing.SystemColors.ControlText;
            this.btn_CreateMeetingRequest_Submit.Location = new System.Drawing.Point(194, 500);
            this.btn_CreateMeetingRequest_Submit.Name = "btn_CreateMeetingRequest_Submit";
            this.btn_CreateMeetingRequest_Submit.Size = new System.Drawing.Size(102, 32);
            this.btn_CreateMeetingRequest_Submit.TabIndex = 5;
            this.btn_CreateMeetingRequest_Submit.Text = "Submit";
            this.btn_CreateMeetingRequest_Submit.UseVisualStyleBackColor = false;
            this.btn_CreateMeetingRequest_Submit.Click += new System.EventHandler(this.btn_CreateMeetingRequest_Submit_Click);
            // 
            // listbox_CreateMeetingRequest_PeopleInvited
            // 
            this.listbox_CreateMeetingRequest_PeopleInvited.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.listbox_CreateMeetingRequest_PeopleInvited.FormattingEnabled = true;
            this.listbox_CreateMeetingRequest_PeopleInvited.ItemHeight = 17;
            this.listbox_CreateMeetingRequest_PeopleInvited.Location = new System.Drawing.Point(16, 293);
            this.listbox_CreateMeetingRequest_PeopleInvited.Name = "listbox_CreateMeetingRequest_PeopleInvited";
            this.listbox_CreateMeetingRequest_PeopleInvited.Size = new System.Drawing.Size(388, 157);
            this.listbox_CreateMeetingRequest_PeopleInvited.TabIndex = 4;
            // 
            // combobox_CreateMeetingRequest_AvailablePeople
            // 
            this.combobox_CreateMeetingRequest_AvailablePeople.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.combobox_CreateMeetingRequest_AvailablePeople.FormattingEnabled = true;
            this.combobox_CreateMeetingRequest_AvailablePeople.Location = new System.Drawing.Point(16, 262);
            this.combobox_CreateMeetingRequest_AvailablePeople.Name = "combobox_CreateMeetingRequest_AvailablePeople";
            this.combobox_CreateMeetingRequest_AvailablePeople.Size = new System.Drawing.Size(388, 25);
            this.combobox_CreateMeetingRequest_AvailablePeople.TabIndex = 5;
            // 
            // checkbox_CreateMeetingRequest_NeedWCAccess
            // 
            this.checkbox_CreateMeetingRequest_NeedWCAccess.AutoSize = true;
            this.checkbox_CreateMeetingRequest_NeedWCAccess.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.checkbox_CreateMeetingRequest_NeedWCAccess.Location = new System.Drawing.Point(16, 109);
            this.checkbox_CreateMeetingRequest_NeedWCAccess.Name = "checkbox_CreateMeetingRequest_NeedWCAccess";
            this.checkbox_CreateMeetingRequest_NeedWCAccess.Size = new System.Drawing.Size(193, 21);
            this.checkbox_CreateMeetingRequest_NeedWCAccess.TabIndex = 3;
            this.checkbox_CreateMeetingRequest_NeedWCAccess.Text = "Need Wheelchair Access?";
            this.checkbox_CreateMeetingRequest_NeedWCAccess.UseVisualStyleBackColor = true;
            this.checkbox_CreateMeetingRequest_NeedWCAccess.CheckedChanged += new System.EventHandler(this.checkbox_CreateMeetingRequest_NeedWCAccess_CheckedChanged);
            // 
            // checkbox_CreateMeetingRequest_NeedPA
            // 
            this.checkbox_CreateMeetingRequest_NeedPA.AutoSize = true;
            this.checkbox_CreateMeetingRequest_NeedPA.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.checkbox_CreateMeetingRequest_NeedPA.Location = new System.Drawing.Point(16, 85);
            this.checkbox_CreateMeetingRequest_NeedPA.Name = "checkbox_CreateMeetingRequest_NeedPA";
            this.checkbox_CreateMeetingRequest_NeedPA.Size = new System.Drawing.Size(141, 21);
            this.checkbox_CreateMeetingRequest_NeedPA.TabIndex = 2;
            this.checkbox_CreateMeetingRequest_NeedPA.Text = "Need PA System?";
            this.checkbox_CreateMeetingRequest_NeedPA.UseVisualStyleBackColor = true;
            this.checkbox_CreateMeetingRequest_NeedPA.CheckedChanged += new System.EventHandler(this.checkbox_CreateMeetingRequest_NeedPA_CheckedChanged);
            // 
            // checkbox_CreateMeetingRequest_NeedProjecter
            // 
            this.checkbox_CreateMeetingRequest_NeedProjecter.AutoSize = true;
            this.checkbox_CreateMeetingRequest_NeedProjecter.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.checkbox_CreateMeetingRequest_NeedProjecter.Location = new System.Drawing.Point(16, 61);
            this.checkbox_CreateMeetingRequest_NeedProjecter.Name = "checkbox_CreateMeetingRequest_NeedProjecter";
            this.checkbox_CreateMeetingRequest_NeedProjecter.Size = new System.Drawing.Size(130, 21);
            this.checkbox_CreateMeetingRequest_NeedProjecter.TabIndex = 1;
            this.checkbox_CreateMeetingRequest_NeedProjecter.Text = "Need Projector?";
            this.checkbox_CreateMeetingRequest_NeedProjecter.UseVisualStyleBackColor = true;
            this.checkbox_CreateMeetingRequest_NeedProjecter.CheckedChanged += new System.EventHandler(this.checkbox_CreateMeetingRequest_NeedProjecter_CheckedChanged);
            // 
            // groupbox_MainMenu
            // 
            this.groupbox_MainMenu.Controls.Add(this.btn_MainMenu_Finalise);
            this.groupbox_MainMenu.Controls.Add(this.btn_MainMenu_CreateMeetingRequest);
            this.groupbox_MainMenu.Controls.Add(this.listbox_MainMenu_MyMeetingRequests);
            this.groupbox_MainMenu.Controls.Add(this.lbl_MainMenu_MyMeetingRequests);
            this.groupbox_MainMenu.Controls.Add(this.btn_MainMenu_CancelMeeting);
            this.groupbox_MainMenu.Controls.Add(this.lbl_MainMenu_MyMeetings);
            this.groupbox_MainMenu.Controls.Add(this.listbox_MainMenu_MyMeetings);
            this.groupbox_MainMenu.Controls.Add(this.lbl_MainMenu_MeetingsToAccept);
            this.groupbox_MainMenu.Controls.Add(this.lbl_MainMenu_UpcomingMeetings);
            this.groupbox_MainMenu.Controls.Add(this.listbox_MainMenu_MeetingsToAccept);
            this.groupbox_MainMenu.Controls.Add(this.btn_MainMenu_AcceptMeeting);
            this.groupbox_MainMenu.Controls.Add(this.btn_MainMenu_DeclineMeeting);
            this.groupbox_MainMenu.Controls.Add(this.listbox_MainMenu_UpcomingMeetings);
            this.groupbox_MainMenu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.groupbox_MainMenu.Location = new System.Drawing.Point(356, 12);
            this.groupbox_MainMenu.Name = "groupbox_MainMenu";
            this.groupbox_MainMenu.Size = new System.Drawing.Size(1147, 184);
            this.groupbox_MainMenu.TabIndex = 2;
            this.groupbox_MainMenu.TabStop = false;
            this.groupbox_MainMenu.Text = "Main Menu";
            this.groupbox_MainMenu.Visible = false;
            // 
            // btn_MainMenu_CreateMeetingRequest
            // 
            this.btn_MainMenu_CreateMeetingRequest.BackColor = System.Drawing.Color.White;
            this.btn_MainMenu_CreateMeetingRequest.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MainMenu_CreateMeetingRequest.Location = new System.Drawing.Point(1054, 140);
            this.btn_MainMenu_CreateMeetingRequest.Name = "btn_MainMenu_CreateMeetingRequest";
            this.btn_MainMenu_CreateMeetingRequest.Size = new System.Drawing.Size(75, 35);
            this.btn_MainMenu_CreateMeetingRequest.TabIndex = 7;
            this.btn_MainMenu_CreateMeetingRequest.Text = "Create";
            this.btn_MainMenu_CreateMeetingRequest.UseVisualStyleBackColor = false;
            this.btn_MainMenu_CreateMeetingRequest.Click += new System.EventHandler(this.btn_MainMenu_CreateMeetingRequest_Click);
            // 
            // listbox_MainMenu_MyMeetingRequests
            // 
            this.listbox_MainMenu_MyMeetingRequests.FormattingEnabled = true;
            this.listbox_MainMenu_MyMeetingRequests.ItemHeight = 17;
            this.listbox_MainMenu_MyMeetingRequests.Location = new System.Drawing.Point(856, 43);
            this.listbox_MainMenu_MyMeetingRequests.Name = "listbox_MainMenu_MyMeetingRequests";
            this.listbox_MainMenu_MyMeetingRequests.Size = new System.Drawing.Size(273, 89);
            this.listbox_MainMenu_MyMeetingRequests.TabIndex = 6;
            this.listbox_MainMenu_MyMeetingRequests.SelectedIndexChanged += new System.EventHandler(this.listbox_MainMenu_MyMeetingRequests_SelectedIndexChanged);
            // 
            // lbl_MainMenu_MyMeetingRequests
            // 
            this.lbl_MainMenu_MyMeetingRequests.AutoSize = true;
            this.lbl_MainMenu_MyMeetingRequests.Location = new System.Drawing.Point(853, 22);
            this.lbl_MainMenu_MyMeetingRequests.Name = "lbl_MainMenu_MyMeetingRequests";
            this.lbl_MainMenu_MyMeetingRequests.Size = new System.Drawing.Size(144, 17);
            this.lbl_MainMenu_MyMeetingRequests.TabIndex = 5;
            this.lbl_MainMenu_MyMeetingRequests.Text = "My Meeting Requests";
            // 
            // btn_MainMenu_CancelMeeting
            // 
            this.btn_MainMenu_CancelMeeting.BackColor = System.Drawing.Color.White;
            this.btn_MainMenu_CancelMeeting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MainMenu_CancelMeeting.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_MainMenu_CancelMeeting.Location = new System.Drawing.Point(856, 140);
            this.btn_MainMenu_CancelMeeting.Name = "btn_MainMenu_CancelMeeting";
            this.btn_MainMenu_CancelMeeting.Size = new System.Drawing.Size(75, 34);
            this.btn_MainMenu_CancelMeeting.TabIndex = 3;
            this.btn_MainMenu_CancelMeeting.Text = "Cancel";
            this.btn_MainMenu_CancelMeeting.UseVisualStyleBackColor = false;
            this.btn_MainMenu_CancelMeeting.Click += new System.EventHandler(this.btn_MainMenu_CancelMeeting_Click);
            // 
            // lbl_MainMenu_MyMeetings
            // 
            this.lbl_MainMenu_MyMeetings.AutoSize = true;
            this.lbl_MainMenu_MyMeetings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_MainMenu_MyMeetings.Location = new System.Drawing.Point(295, 23);
            this.lbl_MainMenu_MyMeetings.Name = "lbl_MainMenu_MyMeetings";
            this.lbl_MainMenu_MyMeetings.Size = new System.Drawing.Size(154, 17);
            this.lbl_MainMenu_MyMeetings.TabIndex = 3;
            this.lbl_MainMenu_MyMeetings.Text = "My Upcoming Meetings";
            // 
            // listbox_MainMenu_MyMeetings
            // 
            this.listbox_MainMenu_MyMeetings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.listbox_MainMenu_MyMeetings.FormattingEnabled = true;
            this.listbox_MainMenu_MyMeetings.ItemHeight = 17;
            this.listbox_MainMenu_MyMeetings.Location = new System.Drawing.Point(297, 43);
            this.listbox_MainMenu_MyMeetings.Name = "listbox_MainMenu_MyMeetings";
            this.listbox_MainMenu_MyMeetings.Size = new System.Drawing.Size(273, 89);
            this.listbox_MainMenu_MyMeetings.TabIndex = 3;
            this.listbox_MainMenu_MyMeetings.SelectedIndexChanged += new System.EventHandler(this.listbox_MainMenu_MyMeetings_SelectedIndexChanged);
            // 
            // lbl_MainMenu_MeetingsToAccept
            // 
            this.lbl_MainMenu_MeetingsToAccept.AutoSize = true;
            this.lbl_MainMenu_MeetingsToAccept.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_MainMenu_MeetingsToAccept.Location = new System.Drawing.Point(575, 23);
            this.lbl_MainMenu_MeetingsToAccept.Name = "lbl_MainMenu_MeetingsToAccept";
            this.lbl_MainMenu_MeetingsToAccept.Size = new System.Drawing.Size(189, 17);
            this.lbl_MainMenu_MeetingsToAccept.TabIndex = 3;
            this.lbl_MainMenu_MeetingsToAccept.Text = "Meetings Pending Response";
            // 
            // lbl_MainMenu_UpcomingMeetings
            // 
            this.lbl_MainMenu_UpcomingMeetings.AutoSize = true;
            this.lbl_MainMenu_UpcomingMeetings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_MainMenu_UpcomingMeetings.Location = new System.Drawing.Point(13, 23);
            this.lbl_MainMenu_UpcomingMeetings.Name = "lbl_MainMenu_UpcomingMeetings";
            this.lbl_MainMenu_UpcomingMeetings.Size = new System.Drawing.Size(132, 17);
            this.lbl_MainMenu_UpcomingMeetings.TabIndex = 3;
            this.lbl_MainMenu_UpcomingMeetings.Text = "Upcoming Meetings";
            // 
            // listbox_MainMenu_MeetingsToAccept
            // 
            this.listbox_MainMenu_MeetingsToAccept.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.listbox_MainMenu_MeetingsToAccept.FormattingEnabled = true;
            this.listbox_MainMenu_MeetingsToAccept.ItemHeight = 17;
            this.listbox_MainMenu_MeetingsToAccept.Location = new System.Drawing.Point(577, 43);
            this.listbox_MainMenu_MeetingsToAccept.Name = "listbox_MainMenu_MeetingsToAccept";
            this.listbox_MainMenu_MeetingsToAccept.Size = new System.Drawing.Size(273, 89);
            this.listbox_MainMenu_MeetingsToAccept.TabIndex = 3;
            this.listbox_MainMenu_MeetingsToAccept.SelectedIndexChanged += new System.EventHandler(this.listbox_MainMenu_MeetingsToAccept_SelectedIndexChanged);
            // 
            // btn_MainMenu_AcceptMeeting
            // 
            this.btn_MainMenu_AcceptMeeting.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btn_MainMenu_AcceptMeeting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MainMenu_AcceptMeeting.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_MainMenu_AcceptMeeting.Location = new System.Drawing.Point(578, 140);
            this.btn_MainMenu_AcceptMeeting.Name = "btn_MainMenu_AcceptMeeting";
            this.btn_MainMenu_AcceptMeeting.Size = new System.Drawing.Size(75, 33);
            this.btn_MainMenu_AcceptMeeting.TabIndex = 3;
            this.btn_MainMenu_AcceptMeeting.Text = "Accept";
            this.btn_MainMenu_AcceptMeeting.UseVisualStyleBackColor = false;
            this.btn_MainMenu_AcceptMeeting.Click += new System.EventHandler(this.btn_MainMenu_AcceptMeeting_Click);
            // 
            // btn_MainMenu_DeclineMeeting
            // 
            this.btn_MainMenu_DeclineMeeting.BackColor = System.Drawing.Color.Red;
            this.btn_MainMenu_DeclineMeeting.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MainMenu_DeclineMeeting.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.btn_MainMenu_DeclineMeeting.Location = new System.Drawing.Point(659, 140);
            this.btn_MainMenu_DeclineMeeting.Name = "btn_MainMenu_DeclineMeeting";
            this.btn_MainMenu_DeclineMeeting.Size = new System.Drawing.Size(75, 33);
            this.btn_MainMenu_DeclineMeeting.TabIndex = 4;
            this.btn_MainMenu_DeclineMeeting.Text = "Decline";
            this.btn_MainMenu_DeclineMeeting.UseVisualStyleBackColor = false;
            this.btn_MainMenu_DeclineMeeting.Click += new System.EventHandler(this.btn_MainMenu_DeclineMeeting_Click);
            // 
            // listbox_MainMenu_UpcomingMeetings
            // 
            this.listbox_MainMenu_UpcomingMeetings.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.listbox_MainMenu_UpcomingMeetings.FormattingEnabled = true;
            this.listbox_MainMenu_UpcomingMeetings.ItemHeight = 17;
            this.listbox_MainMenu_UpcomingMeetings.Location = new System.Drawing.Point(16, 43);
            this.listbox_MainMenu_UpcomingMeetings.Name = "listbox_MainMenu_UpcomingMeetings";
            this.listbox_MainMenu_UpcomingMeetings.Size = new System.Drawing.Size(273, 89);
            this.listbox_MainMenu_UpcomingMeetings.TabIndex = 0;
            this.listbox_MainMenu_UpcomingMeetings.SelectedIndexChanged += new System.EventHandler(this.listbox_MainMenu_UpcomingMeetings_SelectedIndexChanged);
            // 
            // groupbox_ViewMeetingRequestInfo
            // 
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_Confirmed);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_Unavailable);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_Invited);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_BuildingNumber);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_RoomNumber);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.listbox_ViewMeetingRequestInfo_Confirmed);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.listbox_ViewMeetingRequestInfo_Unavailable);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.listbox_ViewMeetingRequestInfo_Invited);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_InitiatorName);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_WCAccess);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_PASystem);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_Projector);
            this.groupbox_ViewMeetingRequestInfo.Controls.Add(this.lbl_ViewMeetingRequestInfo_DateScheduled);
            this.groupbox_ViewMeetingRequestInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.groupbox_ViewMeetingRequestInfo.Location = new System.Drawing.Point(356, 206);
            this.groupbox_ViewMeetingRequestInfo.Name = "groupbox_ViewMeetingRequestInfo";
            this.groupbox_ViewMeetingRequestInfo.Size = new System.Drawing.Size(422, 567);
            this.groupbox_ViewMeetingRequestInfo.TabIndex = 3;
            this.groupbox_ViewMeetingRequestInfo.TabStop = false;
            this.groupbox_ViewMeetingRequestInfo.Text = "View Meeting Request Info";
            this.groupbox_ViewMeetingRequestInfo.Visible = false;
            // 
            // lbl_ViewMeetingRequestInfo_Confirmed
            // 
            this.lbl_ViewMeetingRequestInfo_Confirmed.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_Confirmed.Location = new System.Drawing.Point(14, 419);
            this.lbl_ViewMeetingRequestInfo_Confirmed.Name = "lbl_ViewMeetingRequestInfo_Confirmed";
            this.lbl_ViewMeetingRequestInfo_Confirmed.Size = new System.Drawing.Size(76, 17);
            this.lbl_ViewMeetingRequestInfo_Confirmed.TabIndex = 12;
            this.lbl_ViewMeetingRequestInfo_Confirmed.Text = "Confirmed:";
            // 
            // lbl_ViewMeetingRequestInfo_Unavailable
            // 
            this.lbl_ViewMeetingRequestInfo_Unavailable.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_Unavailable.Location = new System.Drawing.Point(16, 300);
            this.lbl_ViewMeetingRequestInfo_Unavailable.Name = "lbl_ViewMeetingRequestInfo_Unavailable";
            this.lbl_ViewMeetingRequestInfo_Unavailable.Size = new System.Drawing.Size(82, 17);
            this.lbl_ViewMeetingRequestInfo_Unavailable.TabIndex = 11;
            this.lbl_ViewMeetingRequestInfo_Unavailable.Text = "Unavailable";
            // 
            // lbl_ViewMeetingRequestInfo_Invited
            // 
            this.lbl_ViewMeetingRequestInfo_Invited.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_Invited.Location = new System.Drawing.Point(14, 178);
            this.lbl_ViewMeetingRequestInfo_Invited.Name = "lbl_ViewMeetingRequestInfo_Invited";
            this.lbl_ViewMeetingRequestInfo_Invited.Size = new System.Drawing.Size(53, 17);
            this.lbl_ViewMeetingRequestInfo_Invited.TabIndex = 10;
            this.lbl_ViewMeetingRequestInfo_Invited.Text = "Invited:";
            // 
            // lbl_ViewMeetingRequestInfo_BuildingNumber
            // 
            this.lbl_ViewMeetingRequestInfo_BuildingNumber.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_BuildingNumber.Location = new System.Drawing.Point(14, 82);
            this.lbl_ViewMeetingRequestInfo_BuildingNumber.Name = "lbl_ViewMeetingRequestInfo_BuildingNumber";
            this.lbl_ViewMeetingRequestInfo_BuildingNumber.Size = new System.Drawing.Size(116, 17);
            this.lbl_ViewMeetingRequestInfo_BuildingNumber.TabIndex = 5;
            this.lbl_ViewMeetingRequestInfo_BuildingNumber.Text = "Building Number:";
            // 
            // lbl_ViewMeetingRequestInfo_RoomNumber
            // 
            this.lbl_ViewMeetingRequestInfo_RoomNumber.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_RoomNumber.Location = new System.Drawing.Point(14, 65);
            this.lbl_ViewMeetingRequestInfo_RoomNumber.Name = "lbl_ViewMeetingRequestInfo_RoomNumber";
            this.lbl_ViewMeetingRequestInfo_RoomNumber.Size = new System.Drawing.Size(103, 17);
            this.lbl_ViewMeetingRequestInfo_RoomNumber.TabIndex = 9;
            this.lbl_ViewMeetingRequestInfo_RoomNumber.Text = "Room Number:";
            // 
            // listbox_ViewMeetingRequestInfo_Confirmed
            // 
            this.listbox_ViewMeetingRequestInfo_Confirmed.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.listbox_ViewMeetingRequestInfo_Confirmed.FormattingEnabled = true;
            this.listbox_ViewMeetingRequestInfo_Confirmed.ItemHeight = 17;
            this.listbox_ViewMeetingRequestInfo_Confirmed.Location = new System.Drawing.Point(17, 439);
            this.listbox_ViewMeetingRequestInfo_Confirmed.Name = "listbox_ViewMeetingRequestInfo_Confirmed";
            this.listbox_ViewMeetingRequestInfo_Confirmed.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listbox_ViewMeetingRequestInfo_Confirmed.Size = new System.Drawing.Size(391, 89);
            this.listbox_ViewMeetingRequestInfo_Confirmed.TabIndex = 8;
            // 
            // listbox_ViewMeetingRequestInfo_Unavailable
            // 
            this.listbox_ViewMeetingRequestInfo_Unavailable.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.listbox_ViewMeetingRequestInfo_Unavailable.FormattingEnabled = true;
            this.listbox_ViewMeetingRequestInfo_Unavailable.ItemHeight = 17;
            this.listbox_ViewMeetingRequestInfo_Unavailable.Location = new System.Drawing.Point(17, 319);
            this.listbox_ViewMeetingRequestInfo_Unavailable.Name = "listbox_ViewMeetingRequestInfo_Unavailable";
            this.listbox_ViewMeetingRequestInfo_Unavailable.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listbox_ViewMeetingRequestInfo_Unavailable.Size = new System.Drawing.Size(391, 89);
            this.listbox_ViewMeetingRequestInfo_Unavailable.TabIndex = 7;
            // 
            // listbox_ViewMeetingRequestInfo_Invited
            // 
            this.listbox_ViewMeetingRequestInfo_Invited.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.listbox_ViewMeetingRequestInfo_Invited.FormattingEnabled = true;
            this.listbox_ViewMeetingRequestInfo_Invited.ItemHeight = 17;
            this.listbox_ViewMeetingRequestInfo_Invited.Location = new System.Drawing.Point(17, 198);
            this.listbox_ViewMeetingRequestInfo_Invited.Name = "listbox_ViewMeetingRequestInfo_Invited";
            this.listbox_ViewMeetingRequestInfo_Invited.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listbox_ViewMeetingRequestInfo_Invited.Size = new System.Drawing.Size(391, 89);
            this.listbox_ViewMeetingRequestInfo_Invited.TabIndex = 6;
            // 
            // lbl_ViewMeetingRequestInfo_InitiatorName
            // 
            this.lbl_ViewMeetingRequestInfo_InitiatorName.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_InitiatorName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingRequestInfo_InitiatorName.Location = new System.Drawing.Point(14, 23);
            this.lbl_ViewMeetingRequestInfo_InitiatorName.Name = "lbl_ViewMeetingRequestInfo_InitiatorName";
            this.lbl_ViewMeetingRequestInfo_InitiatorName.Size = new System.Drawing.Size(99, 17);
            this.lbl_ViewMeetingRequestInfo_InitiatorName.TabIndex = 5;
            this.lbl_ViewMeetingRequestInfo_InitiatorName.Text = "Initiator Name:";
            this.lbl_ViewMeetingRequestInfo_InitiatorName.Click += new System.EventHandler(this.lbl_ViewMeetingRequestInfo_InitiatorName_Click);
            // 
            // lbl_ViewMeetingRequestInfo_WCAccess
            // 
            this.lbl_ViewMeetingRequestInfo_WCAccess.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_WCAccess.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingRequestInfo_WCAccess.Location = new System.Drawing.Point(14, 133);
            this.lbl_ViewMeetingRequestInfo_WCAccess.Name = "lbl_ViewMeetingRequestInfo_WCAccess";
            this.lbl_ViewMeetingRequestInfo_WCAccess.Size = new System.Drawing.Size(132, 17);
            this.lbl_ViewMeetingRequestInfo_WCAccess.TabIndex = 4;
            this.lbl_ViewMeetingRequestInfo_WCAccess.Text = "Wheelchair Access:";
            // 
            // lbl_ViewMeetingRequestInfo_PASystem
            // 
            this.lbl_ViewMeetingRequestInfo_PASystem.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_PASystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingRequestInfo_PASystem.Location = new System.Drawing.Point(14, 116);
            this.lbl_ViewMeetingRequestInfo_PASystem.Name = "lbl_ViewMeetingRequestInfo_PASystem";
            this.lbl_ViewMeetingRequestInfo_PASystem.Size = new System.Drawing.Size(80, 17);
            this.lbl_ViewMeetingRequestInfo_PASystem.TabIndex = 3;
            this.lbl_ViewMeetingRequestInfo_PASystem.Text = "PA System:";
            // 
            // lbl_ViewMeetingRequestInfo_Projector
            // 
            this.lbl_ViewMeetingRequestInfo_Projector.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_Projector.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingRequestInfo_Projector.Location = new System.Drawing.Point(14, 99);
            this.lbl_ViewMeetingRequestInfo_Projector.Name = "lbl_ViewMeetingRequestInfo_Projector";
            this.lbl_ViewMeetingRequestInfo_Projector.Size = new System.Drawing.Size(73, 17);
            this.lbl_ViewMeetingRequestInfo_Projector.TabIndex = 2;
            this.lbl_ViewMeetingRequestInfo_Projector.Text = "Projector: ";
            // 
            // lbl_ViewMeetingRequestInfo_DateScheduled
            // 
            this.lbl_ViewMeetingRequestInfo_DateScheduled.AutoSize = true;
            this.lbl_ViewMeetingRequestInfo_DateScheduled.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingRequestInfo_DateScheduled.Location = new System.Drawing.Point(13, 40);
            this.lbl_ViewMeetingRequestInfo_DateScheduled.Name = "lbl_ViewMeetingRequestInfo_DateScheduled";
            this.lbl_ViewMeetingRequestInfo_DateScheduled.Size = new System.Drawing.Size(114, 17);
            this.lbl_ViewMeetingRequestInfo_DateScheduled.TabIndex = 0;
            this.lbl_ViewMeetingRequestInfo_DateScheduled.Text = "Time Scheduled:";
            // 
            // groupbox_ViewMeetingInfo
            // 
            this.groupbox_ViewMeetingInfo.Controls.Add(this.lbl_ViewMeetingInfo_Participants);
            this.groupbox_ViewMeetingInfo.Controls.Add(this.listbox_ViewMeetingInfo_Participants);
            this.groupbox_ViewMeetingInfo.Controls.Add(this.lbl_ViewMeetingInfo_WCAccess);
            this.groupbox_ViewMeetingInfo.Controls.Add(this.lbl_ViewMeetingInfo_PASystem);
            this.groupbox_ViewMeetingInfo.Controls.Add(this.lbl_ViewMeetingInfo_Projector);
            this.groupbox_ViewMeetingInfo.Controls.Add(this.lbl_ViewMeetingInfo_BuildingID);
            this.groupbox_ViewMeetingInfo.Controls.Add(this.lbl_ViewMeetingInfo_RoomID);
            this.groupbox_ViewMeetingInfo.Controls.Add(this.lbl_ViewMeetingInfo_DateScheduled);
            this.groupbox_ViewMeetingInfo.Controls.Add(this.lbl_ViewMeetingInfo_InitiatorName);
            this.groupbox_ViewMeetingInfo.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.groupbox_ViewMeetingInfo.Location = new System.Drawing.Point(12, 206);
            this.groupbox_ViewMeetingInfo.Name = "groupbox_ViewMeetingInfo";
            this.groupbox_ViewMeetingInfo.Size = new System.Drawing.Size(338, 311);
            this.groupbox_ViewMeetingInfo.TabIndex = 4;
            this.groupbox_ViewMeetingInfo.TabStop = false;
            this.groupbox_ViewMeetingInfo.Text = "View Meeting Info";
            this.groupbox_ViewMeetingInfo.Visible = false;
            // 
            // lbl_ViewMeetingInfo_Participants
            // 
            this.lbl_ViewMeetingInfo_Participants.AutoSize = true;
            this.lbl_ViewMeetingInfo_Participants.Location = new System.Drawing.Point(12, 178);
            this.lbl_ViewMeetingInfo_Participants.Name = "lbl_ViewMeetingInfo_Participants";
            this.lbl_ViewMeetingInfo_Participants.Size = new System.Drawing.Size(86, 17);
            this.lbl_ViewMeetingInfo_Participants.TabIndex = 5;
            this.lbl_ViewMeetingInfo_Participants.Text = "Participants:";
            // 
            // listbox_ViewMeetingInfo_Participants
            // 
            this.listbox_ViewMeetingInfo_Participants.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.listbox_ViewMeetingInfo_Participants.FormattingEnabled = true;
            this.listbox_ViewMeetingInfo_Participants.ItemHeight = 17;
            this.listbox_ViewMeetingInfo_Participants.Location = new System.Drawing.Point(15, 202);
            this.listbox_ViewMeetingInfo_Participants.Name = "listbox_ViewMeetingInfo_Participants";
            this.listbox_ViewMeetingInfo_Participants.SelectionMode = System.Windows.Forms.SelectionMode.None;
            this.listbox_ViewMeetingInfo_Participants.Size = new System.Drawing.Size(265, 89);
            this.listbox_ViewMeetingInfo_Participants.TabIndex = 8;
            // 
            // lbl_ViewMeetingInfo_WCAccess
            // 
            this.lbl_ViewMeetingInfo_WCAccess.AutoSize = true;
            this.lbl_ViewMeetingInfo_WCAccess.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingInfo_WCAccess.Location = new System.Drawing.Point(12, 142);
            this.lbl_ViewMeetingInfo_WCAccess.Name = "lbl_ViewMeetingInfo_WCAccess";
            this.lbl_ViewMeetingInfo_WCAccess.Size = new System.Drawing.Size(132, 17);
            this.lbl_ViewMeetingInfo_WCAccess.TabIndex = 7;
            this.lbl_ViewMeetingInfo_WCAccess.Text = "Wheelchair Access:";
            // 
            // lbl_ViewMeetingInfo_PASystem
            // 
            this.lbl_ViewMeetingInfo_PASystem.AutoSize = true;
            this.lbl_ViewMeetingInfo_PASystem.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingInfo_PASystem.Location = new System.Drawing.Point(11, 125);
            this.lbl_ViewMeetingInfo_PASystem.Name = "lbl_ViewMeetingInfo_PASystem";
            this.lbl_ViewMeetingInfo_PASystem.Size = new System.Drawing.Size(80, 17);
            this.lbl_ViewMeetingInfo_PASystem.TabIndex = 6;
            this.lbl_ViewMeetingInfo_PASystem.Text = "PA System:";
            // 
            // lbl_ViewMeetingInfo_Projector
            // 
            this.lbl_ViewMeetingInfo_Projector.AutoSize = true;
            this.lbl_ViewMeetingInfo_Projector.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingInfo_Projector.Location = new System.Drawing.Point(11, 108);
            this.lbl_ViewMeetingInfo_Projector.Name = "lbl_ViewMeetingInfo_Projector";
            this.lbl_ViewMeetingInfo_Projector.Size = new System.Drawing.Size(69, 17);
            this.lbl_ViewMeetingInfo_Projector.TabIndex = 5;
            this.lbl_ViewMeetingInfo_Projector.Text = "Projector:";
            // 
            // lbl_ViewMeetingInfo_BuildingID
            // 
            this.lbl_ViewMeetingInfo_BuildingID.AutoSize = true;
            this.lbl_ViewMeetingInfo_BuildingID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingInfo_BuildingID.Location = new System.Drawing.Point(11, 91);
            this.lbl_ViewMeetingInfo_BuildingID.Name = "lbl_ViewMeetingInfo_BuildingID";
            this.lbl_ViewMeetingInfo_BuildingID.Size = new System.Drawing.Size(116, 17);
            this.lbl_ViewMeetingInfo_BuildingID.TabIndex = 4;
            this.lbl_ViewMeetingInfo_BuildingID.Text = "Building Number:";
            // 
            // lbl_ViewMeetingInfo_RoomID
            // 
            this.lbl_ViewMeetingInfo_RoomID.AutoSize = true;
            this.lbl_ViewMeetingInfo_RoomID.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingInfo_RoomID.Location = new System.Drawing.Point(12, 73);
            this.lbl_ViewMeetingInfo_RoomID.Name = "lbl_ViewMeetingInfo_RoomID";
            this.lbl_ViewMeetingInfo_RoomID.Size = new System.Drawing.Size(103, 17);
            this.lbl_ViewMeetingInfo_RoomID.TabIndex = 3;
            this.lbl_ViewMeetingInfo_RoomID.Text = "Room Number:";
            // 
            // lbl_ViewMeetingInfo_DateScheduled
            // 
            this.lbl_ViewMeetingInfo_DateScheduled.AutoSize = true;
            this.lbl_ViewMeetingInfo_DateScheduled.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingInfo_DateScheduled.Location = new System.Drawing.Point(12, 45);
            this.lbl_ViewMeetingInfo_DateScheduled.Name = "lbl_ViewMeetingInfo_DateScheduled";
            this.lbl_ViewMeetingInfo_DateScheduled.Size = new System.Drawing.Size(113, 17);
            this.lbl_ViewMeetingInfo_DateScheduled.TabIndex = 1;
            this.lbl_ViewMeetingInfo_DateScheduled.Text = "Date Scheduled:";
            // 
            // lbl_ViewMeetingInfo_InitiatorName
            // 
            this.lbl_ViewMeetingInfo_InitiatorName.AutoSize = true;
            this.lbl_ViewMeetingInfo_InitiatorName.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_ViewMeetingInfo_InitiatorName.Location = new System.Drawing.Point(12, 28);
            this.lbl_ViewMeetingInfo_InitiatorName.Name = "lbl_ViewMeetingInfo_InitiatorName";
            this.lbl_ViewMeetingInfo_InitiatorName.Size = new System.Drawing.Size(58, 17);
            this.lbl_ViewMeetingInfo_InitiatorName.TabIndex = 0;
            this.lbl_ViewMeetingInfo_InitiatorName.Text = "Initiator:";
            // 
            // btn_LogOut
            // 
            this.btn_LogOut.Location = new System.Drawing.Point(1410, 751);
            this.btn_LogOut.Name = "btn_LogOut";
            this.btn_LogOut.Size = new System.Drawing.Size(98, 24);
            this.btn_LogOut.TabIndex = 5;
            this.btn_LogOut.Text = "Log Out";
            this.btn_LogOut.UseVisualStyleBackColor = true;
            this.btn_LogOut.Visible = false;
            this.btn_LogOut.Click += new System.EventHandler(this.btn_LogOut_Click);
            // 
            // btn_MainMenu_Finalise
            // 
            this.btn_MainMenu_Finalise.BackColor = System.Drawing.Color.White;
            this.btn_MainMenu_Finalise.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_MainMenu_Finalise.Location = new System.Drawing.Point(954, 140);
            this.btn_MainMenu_Finalise.Name = "btn_MainMenu_Finalise";
            this.btn_MainMenu_Finalise.Size = new System.Drawing.Size(75, 34);
            this.btn_MainMenu_Finalise.TabIndex = 8;
            this.btn_MainMenu_Finalise.Text = "Finalise";
            this.btn_MainMenu_Finalise.UseVisualStyleBackColor = false;
            this.btn_MainMenu_Finalise.Click += new System.EventHandler(this.btn_MainMenu_Finalise_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1520, 785);
            this.Controls.Add(this.btn_LogOut);
            this.Controls.Add(this.groupbox_ViewMeetingInfo);
            this.Controls.Add(this.groupbox_ViewMeetingRequestInfo);
            this.Controls.Add(this.groupbox_MainMenu);
            this.Controls.Add(this.grpbox_CreateMeetingRequest);
            this.Controls.Add(this.grpbox_LogIn);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.grpbox_LogIn.ResumeLayout(false);
            this.grpbox_LogIn.PerformLayout();
            this.grpbox_CreateMeetingRequest.ResumeLayout(false);
            this.grpbox_CreateMeetingRequest.PerformLayout();
            this.groupbox_MainMenu.ResumeLayout(false);
            this.groupbox_MainMenu.PerformLayout();
            this.groupbox_ViewMeetingRequestInfo.ResumeLayout(false);
            this.groupbox_ViewMeetingRequestInfo.PerformLayout();
            this.groupbox_ViewMeetingInfo.ResumeLayout(false);
            this.groupbox_ViewMeetingInfo.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox grpbox_LogIn;
        private System.Windows.Forms.Button btn_LogIn_Submit;
        private System.Windows.Forms.TextBox txtbox_LogIn_Password;
        private System.Windows.Forms.TextBox txtbox_LogIn_UserID;
        private System.Windows.Forms.GroupBox grpbox_CreateMeetingRequest;
        private System.Windows.Forms.CheckBox checkbox_CreateMeetingRequest_NeedWCAccess;
        private System.Windows.Forms.CheckBox checkbox_CreateMeetingRequest_NeedPA;
        private System.Windows.Forms.CheckBox checkbox_CreateMeetingRequest_NeedProjecter;
        private System.Windows.Forms.Button btn_CreateMeetingRequest_Submit;
        private System.Windows.Forms.ListBox listbox_CreateMeetingRequest_PeopleInvited;
        private System.Windows.Forms.ComboBox combobox_CreateMeetingRequest_AvailablePeople;
        private System.Windows.Forms.GroupBox groupbox_MainMenu;
        private System.Windows.Forms.ListBox listbox_MainMenu_MeetingsToAccept;
        private System.Windows.Forms.ListBox listbox_MainMenu_UpcomingMeetings;
        private System.Windows.Forms.Label lbl_MainMenu_MeetingsToAccept;
        private System.Windows.Forms.Label lbl_MainMenu_UpcomingMeetings;
        private System.Windows.Forms.Button btn_MainMenu_AcceptMeeting;
        private System.Windows.Forms.Button btn_MainMenu_DeclineMeeting;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Button btn_MainMenu_CancelMeeting;
        private System.Windows.Forms.Label lbl_MainMenu_MyMeetings;
        private System.Windows.Forms.ListBox listbox_MainMenu_MyMeetings;
        private System.Windows.Forms.GroupBox groupbox_ViewMeetingRequestInfo;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_DateScheduled;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_Projector;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_PASystem;
        private System.Windows.Forms.ListBox listbox_ViewMeetingRequestInfo_Confirmed;
        private System.Windows.Forms.ListBox listbox_ViewMeetingRequestInfo_Unavailable;
        private System.Windows.Forms.ListBox listbox_ViewMeetingRequestInfo_Invited;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_InitiatorName;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_WCAccess;
        private System.Windows.Forms.GroupBox groupbox_ViewMeetingInfo;
        private System.Windows.Forms.ListBox listbox_ViewMeetingInfo_Participants;
        private System.Windows.Forms.Label lbl_ViewMeetingInfo_WCAccess;
        private System.Windows.Forms.Label lbl_ViewMeetingInfo_PASystem;
        private System.Windows.Forms.Label lbl_ViewMeetingInfo_Projector;
        private System.Windows.Forms.Label lbl_ViewMeetingInfo_BuildingID;
        private System.Windows.Forms.Label lbl_ViewMeetingInfo_RoomID;
        private System.Windows.Forms.Label lbl_ViewMeetingInfo_DateScheduled;
        private System.Windows.Forms.Label lbl_ViewMeetingInfo_InitiatorName;
        private System.Windows.Forms.Button btn_LogIn_Register;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_BuildingNumber;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_RoomNumber;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_Unavailable;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_Invited;
        private System.Windows.Forms.Label lbl_ViewMeetingRequestInfo_Confirmed;
        private System.Windows.Forms.ComboBox combobox_CreateMeetingRequest_AvailableRooms;
        private System.Windows.Forms.Label lbl_CreateMeetingRequest_Rooms;
        private System.Windows.Forms.Label lbl_CreateMeetingRequest_AvailableParticipants;
        private System.Windows.Forms.Label lbl_LogIn_Password;
        private System.Windows.Forms.Label lbl_LogIn_UserID;
        private System.Windows.Forms.ComboBox combobox_CreateMeetingRequest_Time;
        private System.Windows.Forms.Button btn_CreateMeetingRequest_RemoveParticipant;
        private System.Windows.Forms.Button btn_CreateMeetingRequest_AddParticipant;
        private System.Windows.Forms.ListBox listbox_MainMenu_MyMeetingRequests;
        private System.Windows.Forms.Label lbl_MainMenu_MyMeetingRequests;
        private System.Windows.Forms.Button btn_MainMenu_CreateMeetingRequest;
        private System.Windows.Forms.Button btn_CreateMeetingRequest_Cancel;
        private System.Windows.Forms.Label lbl_ViewMeetingInfo_Participants;
        private System.Windows.Forms.Button btn_LogOut;
        private System.Windows.Forms.Button btn_MainMenu_Finalise;
    }
}

