﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

// ---------------------------------------------------------- //
// --- A large portion of this class is untested due to   --- //
// --- extremely tight time constraints. If you come      --- //
// --- across any crashes or bugs caused by this class,   --- //
// --- let me know as soon as possible and I will fix it  --- //
// --- as soon as I can.                           - Carl --- //
// ---------------------------------------------------------- //

namespace MeetingScheduler
{
    /// <summary>
    /// A collection of methods to assist in the reading and writing of files.
    /// </summary>
    static class DataFileHandler
    {
        static string meetingFilePath = @"..\data\meetings.txt";
        static string roomFilePath = @"..\data\rooms.txt";
        static string userFilePath = @"..\data\users.txt";
        static string meetingRequestFilePath = @"..\data\meetingrequests.txt";

        static string userTimeSlotFileDir = @"..\data\timeslots\user\";
        static string roomTimeSlotFileDir = @"..\data\timeslots\room\";


        // ---- Get Vars -------- //
        static public string GetMeetingFilePath() { return meetingFilePath; }
        static public string GetRoomFilePath() { return roomFilePath; }
        static public string GetUserFilePath() { return userFilePath; }

        // ---- Meeting - Read ---- //
        static private string GetMeetingStringFromFile(string meetingID)
        {
            StreamReader reader = new StreamReader(meetingFilePath);
            string currentLine = "";
            bool meetingFound = false;

            do //read each line and check for the meetingID.
            {
                currentLine = reader.ReadLine();
                if (currentLine.StartsWith(meetingID + ","))
                {
                    meetingFound = true;
                    break;
                }

            } while (!reader.EndOfStream);
            reader.Close();

            if (meetingFound)
            {
                return currentLine;
            }
            else return null;
        }
        static private Meeting ConvertLineToMeetingObject(string line)
        {
            //ID,day,month,year,hour,minute,roomnum,buildingnum,initiatorID|ListofParticipants
            string[] lineHalves = line.Split('|');
            string[] usersIDArray = lineHalves[1].Split(',');
            List<User> users = new List<User>();
            string[] info = lineHalves[0].Split(',');
            foreach (string s in usersIDArray)
            {
                users.Add(GetUserObject(s));
            }
            return new Meeting(int.Parse(info[0]), int.Parse(info[1]), int.Parse(info[2]),
                   int.Parse(info[3]), int.Parse(info[4]), int.Parse(info[5]),
                   info[6], info[7], int.Parse(info[8]), users);
        }
        static public string[] GetMeetingInfoAsStringArray(string meetingID)
        {
            string foundLine = GetMeetingStringFromFile(meetingID);
            if (foundLine != null)
            {
                string[] lineHalves = foundLine.Split('|');

                return lineHalves[0].Split(',');
            }
            else return null;
        }
        static public string[] GetMeetingParticipantsAsStringArray(string meetingID)
        {
            string foundLine = GetMeetingStringFromFile(meetingID);
            if (foundLine != null) //ensures that its operating on a string that exists
            {
                // split at pipe and store as array
                string[] lineHalves = foundLine.Split('|');
                // return individual values from right side of pipe
                return lineHalves[1].Split(',');
            }
            else return null; // return null if no string is found
        }
        static public Meeting GetMeetingAsObject(string meetingID)
        {
            string[] info = GetMeetingInfoAsStringArray(meetingID);
            string[] participants = GetMeetingParticipantsAsStringArray(meetingID);
            List<User> users = new List<User>();
            foreach (string p in participants)
            {
                User newUser = GetUserObject(p);
                users.Add(newUser);
            }
            return new Meeting(int.Parse(info[0]), int.Parse(info[1]), int.Parse(info[2]),
                               int.Parse(info[3]), int.Parse(info[4]), int.Parse(info[5]),
                               info[6], info[7], int.Parse(info[0]), users);
        }
        static public string GetMeetingInitiator(string meetingID)
        {
            string foundLine = GetMeetingStringFromFile(meetingID);
            if (foundLine != null) //ensures that its operating on a string that exists
            {
                string[] lineHalves = foundLine.Split('|');
                string[] lineVals = lineHalves[0].Split(',');
                return lineVals[8];
            }
            else return null; // return null if no string is found
        }
        static public string GetMeetingRoomNumber(string meetingID)
        {
            string foundLine = GetMeetingStringFromFile(meetingID);
            if (foundLine != null) //ensures that its operating on a string that exists
            {
                string[] lineHalves = foundLine.Split('|');
                string[] lineVals = lineHalves[0].Split(',');
                return lineVals[6];
            }
            else return null; // return null if no string is found
        }
        static public string GetMeetingBuildingNumber(string meetingID)
        {
            string foundLine = GetMeetingStringFromFile(meetingID);
            if (foundLine != null) //ensures that its operating on a string that exists
            {
                string[] lineHalves = foundLine.Split('|');
                string[] lineVals = lineHalves[0].Split(',');
                return lineVals[7];
            }
            else return null; // return null if no string is found
        }
        static public DateTime GetMeetingDateAndTime(string meetingID)
        {
            string[] infoArray = GetMeetingInfoAsStringArray(meetingID);
            if (infoArray != null)
            {
                return new DateTime(int.Parse(infoArray[3]), int.Parse(infoArray[2]), int.Parse(infoArray[1]),
                                                     int.Parse(infoArray[4]), int.Parse(infoArray[5]), 0);
            }
            else return new DateTime(0, 0, 0, 0, 0, 0);
        }
        static public DateTime GetMeetingDate(string meetingID)
        {
            string[] infoArray = GetMeetingInfoAsStringArray(meetingID);
            DateTime dateTimeToReturn = new DateTime(int.Parse(infoArray[3]), int.Parse(infoArray[2]), int.Parse(infoArray[1]));
            //year month day, hour min second
            return new DateTime();
        }
        static public List<Meeting> GetAllMeetings()
        {
            List<Meeting> foundMeetings = new List<Meeting>();
            StreamReader reader = new StreamReader(meetingFilePath);
            do
            {
                string currentLine = reader.ReadLine();
                if (currentLine != null)
                {
                    foundMeetings.Add(ConvertLineToMeetingObject(currentLine));
                }
            } while (!reader.EndOfStream);
            reader.Close();
            return foundMeetings;
        }
        static public List<Meeting> GetAllUpcomingMeetings()
        {
            List<Meeting> unfilteredList = GetAllMeetings();
            List<Meeting> filteredList = new List<Meeting>();

            foreach (Meeting m in unfilteredList)
            {
                if (DateTime.Now.CompareTo(m.GetDate()) < 0)
                {
                    filteredList.Add(m);
                }
            }
            return filteredList;
        }
        static public List<Meeting> GetAllUpcomingMeetingsForUser(string userID)
        {
            List<Meeting> unfilteredList = GetAllMeetings(); //gets all meetings in file
            List<Meeting> filteredList = new List<Meeting>();
            foreach (Meeting m in unfilteredList)
            {
                bool isFound = false;
                //check the date to see if it is valid first
                if (DateTime.Now.CompareTo(m.GetDate()) < 0) //date check
                {
                    foreach (User u in m.GetParticipants()) //participant check
                    {
                        if (u != null)
                        {
                            if (u.GetID() == int.Parse(userID)) //if the user id is found
                            {
                                isFound = true;
                                break;
                            }
                        }
                    }
                }
                if (isFound == true)
                {
                    filteredList.Add(m);
                }
            }
            return filteredList;
        }
        static public List<Meeting> GetAllUpcomingMeetingsForInitiator(string initiatorID)
        {
            List<Meeting> unfilteredList = GetAllMeetings(); //gets all meetings in file
            List<Meeting> filteredList = new List<Meeting>();
            foreach (Meeting m in unfilteredList)
            {
                bool isValid = false;
                //check the date to see if it is valid first
                if (DateTime.Now.CompareTo(m.GetDate()) < 0)
                {
                    if (m.GetInitiatorID() == int.Parse(initiatorID))
                    {
                        filteredList.Add(m);
                    }
                    //else MessageBox.Show($@"Meeting: {m.GetMeetingID()}'s initator is {m.GetInitiatorID()} and doesnt match the current user {initiatorID}");
                }
            }
            return filteredList;
        }

        // --- Meeting - Write --- //
        static public void SaveMeetingToFile(Meeting m)
        {
            if (m != null)
            { // Save all current lines to a list
                List<string> lineEntries = new List<string>();
                StreamReader reader = new StreamReader(meetingFilePath);
                do
                {
                    lineEntries.Add(reader.ReadLine());
                } while (!reader.EndOfStream);
                reader.Close();

                // meetingID,day,month,year,hour,min,roomNum,buildingNum,initiator|userID1,userID2,userID3
                string newLine = $@"{m.GetMeetingID()},{m.GetDate().Day},{m.GetDate().Month},{m.GetDate().Year}," +
                                    $@"{m.GetDate().Hour},{m.GetDate().Minute},{m.GetRoom().GetRoomID()}," +
                                    $@"{m.GetRoom().GetRoomID()},{m.GetInitiator().GetID()}|";
                string newLineParticipants = "";
                if(m.GetParticipants().Count != 0)
                {
                    foreach (User u in m.GetParticipants())
                    {
                        if(u != null)
                        {
                            newLineParticipants = $@"{newLineParticipants}{u.GetID()},";
                        }
                    }
                    newLineParticipants = newLineParticipants.TrimEnd(',');
                }


                StreamWriter writer = new StreamWriter(meetingFilePath);
                foreach (string line in lineEntries)
                { // Rewrite the lines back into the file
                    if (line != null)
                    {
                        writer.WriteLine(line);
                    }
                }
                if(newLine != "")
                {
                    writer.WriteLine(newLine+newLineParticipants);
                }
                writer.Close();
            }
        }

        // ---- Meeting Request - Read ---- //

        static private string GetMeetingRequestStringFromFile(string meetingRequestID)
        {
            StreamReader reader = new StreamReader(meetingRequestFilePath);
            string currentLine = "";
            bool meetingRequestFound = false;

            do //read each line and check for the meetingID.
            {
                currentLine = reader.ReadLine();
                if (currentLine.StartsWith(meetingRequestID + ","))
                {
                    meetingRequestFound = true;
                    break;
                }

            } while (!reader.EndOfStream);
            reader.Close();

            if (meetingRequestFound)
            {
                return currentLine;
            }
            else return null;
        }
        static private string[] GetMeetingRequestInfoAsStringArray(string meetingRequestID)
        {
            string foundLine = GetMeetingRequestStringFromFile(meetingRequestID);
            if (foundLine != null)
            {
                string[] lineHalves = foundLine.Split('|');

                return lineHalves[0].Split(',');
            }
            else return null;
        }
        static private string[] GetMeetingRequestInvitedAsStringArray(string meetingRequestID)
        {
            string foundLine = GetMeetingRequestStringFromFile(meetingRequestID);
            // # - meetingID,Day,Month,Year,Hour,Minute,RoomID,BuildingID,initiator|listOfInvited|ListOfUnvailable|ListofConfirmed
            string[] lines = foundLine.Split('|');
            //1 = invited, 2 = unavailable, 3 = confirmed
            return lines[1].Split(',');
        }
        static private string[] GetMeetingRequestUnavailableAsStringArray(string meetingRequestID)
        {
            string foundLine = GetMeetingRequestStringFromFile(meetingRequestID);
            // # - meetingID,Day,Month,Year,Hour,Minute,RoomID,BuildingID,initiator|listOfInvited|ListOfUnvailable|ListofConfirmed
            string[] lines = foundLine.Split('|');
            //1 = invited, 2 = unavailable, 3 = confirmed
            return lines[2].Split(',');
        }
        static private string[] GetMeetingRequestConfirmedAsStringArray(string meetingRequestID)
        {
            string foundLine = GetMeetingRequestStringFromFile(meetingRequestID);
            // # - meetingID,Day,Month,Year,Hour,Minute,RoomID,BuildingID,initiator|listOfInvited|ListOfUnvailable|ListofConfirmed
            string[] lines = foundLine.Split('|');
            //1 = invited, 2 = unavailable, 3 = confirmed
            return lines[3].Split(',');
        }

        static public MeetingRequest GetMeetingRequestAsObject(string meetingRequestID)
        {
            string[] info = GetMeetingRequestInfoAsStringArray(meetingRequestID);
            string[] invited = GetMeetingRequestInvitedAsStringArray(meetingRequestID);
            string[] confirmed = GetMeetingRequestConfirmedAsStringArray(meetingRequestID);
            string[] unavailable = GetMeetingRequestUnavailableAsStringArray(meetingRequestID);
            List<User> invitedList = new List<User>(); List<User> confirmedList = new List<User>(); List<User> unavailableList = new List<User>();
            foreach (string s in invited)
            {
                invitedList.Add(GetUserObject(s));
            }
            foreach (string s in confirmed)
            {
                confirmedList.Add(GetUserObject(s));
            }
            foreach (string s in unavailable)
            {
                unavailableList.Add(GetUserObject(s));
            }
            int meetingID = int.Parse(info[0]);
            int day = int.Parse(info[1]);
            int month = int.Parse(info[2]);
            int year = int.Parse(info[3]);
            int hour = int.Parse(info[4]);
            int minute = int.Parse(info[5]);
            string roomID = info[6];
            string buildingID = info[7];
            string initiator = info[8];

            // meetingID,Day,Month,Year,Hour,Minute,RoomID,BuildingID,initiator|listOfInvited|ListOfUnvailable|ListofConfirmed
            return new MeetingRequest(meetingID, new DateTime(year,month,day,hour,minute,0), GetRoomAsObject(roomID, buildingID), 
                                      invitedList, unavailableList, confirmedList, GetUserObject(initiator));
        }
        static private MeetingRequest ConvertLineToMeetingRequest(string line)
        {
            //meetingID,Day,Month,Year,Hour,Minute,RoomID,BuildingID,initiator|listOfInvited|ListOfUnvailable|ListofConfirmed
            //    0      1    2     3    4    5     6         7          8
            string[] lineSegments = line.Split('|');
            string rInfo = lineSegments[0]; string rInvited = lineSegments[1]; string rUnavailable = lineSegments[2]; string rConfirmed = lineSegments[3];
            string[] infoArray = rInfo.Split(',');
            string[] invitedArray = rInvited.Split(',');
            string[] unavailableArray = rUnavailable.Split(',');
            string[] confirmedArray = rConfirmed.Split(',');

            List<User> invitedList = new List<User>(); List<User> confirmedList = new List<User>(); List<User> unavailableList = new List<User>();
            foreach (string s in invitedArray)
            {
                invitedList.Add(GetUserObject(s));
            }
            foreach (string s in confirmedArray)
            {
                confirmedList.Add(GetUserObject(s));
            }
            foreach (string s in unavailableArray)
            {
                unavailableList.Add(GetUserObject(s));
            }

            return new MeetingRequest(int.Parse(infoArray[0]), new DateTime(int.Parse(infoArray[3]), int.Parse(infoArray[2]), int.Parse(infoArray[1]), int.Parse(infoArray[4]), int.Parse(infoArray[5]), 0),
                GetRoomAsObject(infoArray[6], infoArray[7]), invitedList, unavailableList, confirmedList, GetUserObject(infoArray[8]));
        }

        static public List<MeetingRequest> GetAllMeetingRequests()
        {
            List<MeetingRequest> foundMeetingRequests = new List<MeetingRequest>();
            StreamReader reader = new StreamReader(meetingRequestFilePath);
            do
            {
                string currentLine = reader.ReadLine();
                if (currentLine != null)
                {
                    foundMeetingRequests.Add(ConvertLineToMeetingRequest(currentLine));
                }
            } while (!reader.EndOfStream);
            reader.Close();
            return foundMeetingRequests;
        }

        static public List<MeetingRequest> GetAllUpcomingMeetingRequests()
        {
            List<MeetingRequest> unfilteredList = GetAllMeetingRequests();
            List<MeetingRequest> filteredList = new List<MeetingRequest>();

            foreach(MeetingRequest mR in unfilteredList)
            {
                if (DateTime.Now.CompareTo(mR.GetDate()) < 0)
                {
                    filteredList.Add(mR);
                }
            }
            return filteredList;
        }

        static public List<MeetingRequest> GetAllUpcomingMeetingRequestsForUser(string userID)
        {
            List<MeetingRequest> unfilteredList = GetAllMeetingRequests();
            List<MeetingRequest> filteredList = new List<MeetingRequest>();

            foreach (MeetingRequest mR in unfilteredList)
            {
                bool isFound = false;
                if (DateTime.Now.CompareTo(mR.GetDate()) < 0)
                {
                    foreach(User u in mR.GetPeopleInvited())
                    {
                        if(u != null)
                        {
                            if(u.GetID() == int.Parse(userID))
                            {
                                isFound = true;
                                break;
                            }
                        }
                    }
                }
                if (isFound == true)
                {
                    filteredList.Add(mR);
                }
            }
            return filteredList;
        }

        static public List<MeetingRequest> GetAllUpcomingMeetingRequestsForInitiator(string userID)
        {
            List<MeetingRequest> unfilteredList = GetAllMeetingRequests();
            List<MeetingRequest> filteredList = new List<MeetingRequest>();

            foreach (MeetingRequest mR in unfilteredList)
            {
                if (DateTime.Now.CompareTo(mR.GetDate()) < 0)
                {
                    if (mR.GetInitiator().GetID() == int.Parse(userID))
                    {
                        filteredList.Add(mR);
                    }
                }
            }
            return filteredList;
        }

        // ---- Meeting Request - Write ---- //
        static public void WriteMeetingRequestToFile(MeetingRequest r)
        {
            List<string> existingLines = new List<string>();
            try
            { 
                StreamReader reader = new StreamReader(meetingRequestFilePath);
                do
                {
                    existingLines.Add(reader.ReadLine());
                } while (!reader.EndOfStream);
                reader.Close();
            }
            catch (FileNotFoundException) { }

            //meetingID,Day,Month,Year,Hour,Minute,RoomID,BuildingID,initiator|listOfInvited|ListOfUnvailable|ListofConfirmed
            string infoSection = $@"{r.GetID()},{r.GetDate().Day},{r.GetDate().Month},{r.GetDate().Year},{r.GetDate().Hour},{r.GetDate().Minute},{r.GetRoomPref().GetRoomID()},{r.GetRoomPref().GetBuildingID()},{r.GetInitiator().GetID()}";
            
            string invitedSection = "";
            foreach(User u in r.GetPeopleInvited())
            {
                if (u != null) { invitedSection = $@"{invitedSection}{u.GetID()},"; }
            }
            invitedSection = invitedSection.TrimEnd(',');

            string unavailableSection = "";
            foreach (User u in r.GetPeopleUnavailable())
            {
                if (u != null) { unavailableSection = $@"{unavailableSection}{u.GetID()},"; }
            }
            unavailableSection = unavailableSection.TrimEnd(',');

            string confirmedSection = "";
            foreach (User u in r.GetPeopleConfirmed())
            {
                if (u != null) { confirmedSection = $@"{confirmedSection}{u.GetID()},"; }
            }
            confirmedSection = confirmedSection.TrimEnd(',');

            bool existingFound = false;
            StreamWriter writer = new StreamWriter(meetingRequestFilePath);
            foreach(string s in existingLines)
            {
                if (s != null)
                {
                    if (s.StartsWith($@"{r.GetID()},"))
                    {
                        writer.WriteLine($@"{infoSection}|{invitedSection}|{unavailableSection}|{confirmedSection}");
                        existingFound = true;
                    }
                    else
                    {
                        writer.WriteLine(s);
                    }
                }
            }
            if(!existingFound) writer.WriteLine($@"{infoSection}|{invitedSection}|{unavailableSection}|{confirmedSection}");
            writer.Close();
        }

        static public void DeleteMeetingRequestFromFile(MeetingRequest r)
        {
            List<string> existingLines = new List<string>();

            // Delete line from meetingrequestFile
            StreamReader firstReader = new StreamReader(meetingRequestFilePath);
            do
            {
                existingLines.Add(firstReader.ReadLine());          
            } while (!firstReader.EndOfStream);
            firstReader.Close();

            //loop through all lines and if the line matches, delete it from the list
            foreach(string s in existingLines)
            {
                MeetingRequest tempMR = ConvertLineToMeetingRequest(s);
                if(tempMR.GetDate() == r.GetDate()) // if the date match
                {
                    if (tempMR.GetRoomPref().GetRoomID() == r.GetRoomPref().GetRoomID() && tempMR.GetRoomPref().GetBuildingID() == r.GetRoomPref().GetBuildingID()) // and the room matches
                    {
                        existingLines.Remove(s);
                        break;
                    }
                }
            }
            StreamWriter firstWriter = new StreamWriter(meetingRequestFilePath);
            foreach(string s in existingLines)
            {
                firstWriter.WriteLine(s);
            }
            firstWriter.Close();

        }

        static public void DeleteTimeSlotFromUserFile(MeetingRequest mR, string userID)
        {
            List<string> existingLines = GetExistingLinesFromUserTimeSlotFile(userID);
            
            foreach(string s in existingLines)
            {
                DateTime tempDT = GetDateTimeFromLine(s);
                if (tempDT.CompareTo(mR.GetDate()) == 0) // if the date of the request matches the line's date
                {
                    existingLines.Remove(s); //remove it from the list
                }
            }
            try
            {
                StreamWriter writer = new StreamWriter($@"{userTimeSlotFileDir}{userID}.txt");
                foreach(string s in existingLines)
                {
                    writer.WriteLine(s);
                }
                writer.Close();
            }catch(IOException)
            {
                MessageBox.Show("Something went wrong with IO");
            }
        }

        static public void DeleteTimeslotFromRoomFile(MeetingRequest mR, string roomID, string buildingID)
        {
            List<string> existingLines = GetExistingLinesFromRoomTimeSlotFile(roomID, buildingID);

            foreach (string s in existingLines)
            {
                DateTime tempDT = GetDateTimeFromLine(s);
                if (tempDT.CompareTo(mR.GetDate()) == 0) // if the date of the request matches the line's date
                {
                    existingLines.Remove(s); //remove it from the list
                }
            }

            try
            {
                StreamWriter writer = new StreamWriter($@"{roomTimeSlotFileDir}{roomID}-{buildingID}.txt");
                foreach (string s in existingLines)
                {
                    writer.WriteLine(s);
                }
                writer.Close();
            }
            catch (IOException)
            {
                MessageBox.Show("Something went wrong with IO");
            }
        }

        // ---- Room Methods - Read ---- //
        static private List<string> GetAllRoomsAsStrings()
        {
            List<string> listToReturn = new List<string>();
            StreamReader reader = new StreamReader(roomFilePath);
            do //read each line and check for the meetingID.
            {
                string currentLine = reader.ReadLine();
                if (!currentLine.StartsWith("#"))
                {
                    listToReturn.Add(currentLine);
                }
            } while (!reader.EndOfStream);
            reader.Close();
            return listToReturn;
        }
        static private string GetRoomStringFromFile(string roomID, string buildingID)
        {
            StreamReader reader = new StreamReader(roomFilePath);
            string currentLine = "";
            bool roomFound = false;

            do //read each line and check for the meetingID.
            {
                currentLine = reader.ReadLine();
                if (currentLine.StartsWith(roomID + "," + buildingID + ","))
                {
                    roomFound = true;
                    break;
                }
            } while (!reader.EndOfStream);
            reader.Close();

            if (roomFound)
            {
                return currentLine;
            }
            else return null;
        }
        static private string[] GetRoomInfoAsStringArray(string roomID, string buildingID)
        {
            string foundLine = GetRoomStringFromFile(roomID, buildingID);
            if (foundLine != null) //ensures that its operating on a string that exists
            {
                string[] foundAtts = foundLine.Split(',');
                return foundAtts;
            }
            else return null; // return null if no string is found
        }
        static private string[] GetRoomLineAsStringArray(string line)
        {
 
            string[] lines = line.Split(',');
            return lines;

        }
        static public Room GetRoomAsObject(string roomID, string buildingID)
        {
            string[] attribs = GetRoomInfoAsStringArray(roomID, buildingID);
            return new Room(attribs[0], attribs[1], int.Parse(attribs[2]), Boolean.Parse(attribs[3]),
                            Boolean.Parse(attribs[4]), Boolean.Parse(attribs[5]));
        }
        static public List<Room> GetAllRooms()
        {
            List<Room> listToReturn = new List<Room>();
            foreach (string line in GetAllRoomsAsStrings())
            {
                string[] attribs = GetRoomLineAsStringArray(line);
                //convert line to an arra
                listToReturn.Add(GetRoomAsObject(attribs[0], attribs[1]));
            }
            return listToReturn;
        }

        // ---- User Methods - Read ---- //
        static private string GetUserStringFromFile(string userID)
        {
            StreamReader reader = new StreamReader(userFilePath);
            string currentLine = "";
            bool userFound = false;
            do
            {
                currentLine = reader.ReadLine();
                if (currentLine.StartsWith(userID + ","))
                {
                    userFound = true;
                    break;
                }
            } while (!reader.EndOfStream);
            if (userFound)
            {
                return currentLine;
            }
            else return null;
        }
        static private string[] GetUserInfoAsArray(string userId)
        {
            //userID,password,title,firstName,secondName
            string foundLine = GetUserStringFromFile(userId);
            if (foundLine != null)
            {
                string[] foundAttribs = foundLine.Split(',');
                return foundAttribs;
            }
            else return null;
        }
        static private string[] GetUserInfoAsArrayFromLine(string line)
        {
            //userID,password,title,firstName,secondName
            if (line != null)
            {
                string[] foundAttribs = line.Split(',');
                return foundAttribs;
            }
            else return null;
        }
        
        static public User GetUserObject(string userID)
        {
            string[] userInfo = GetUserInfoAsArray(userID);
            if (userInfo != null)
            {
                return new User(int.Parse(userInfo[0]), userInfo[1], userInfo[2], userInfo[3], userInfo[4]);
            }
            else return null;
        }
        static public List<User> GetAllUsers()
        {
            List<User> listToReturn = new List<User>();
            foreach (string line in GetAllUsersAsStrings())
            {
                if(line != "")
                {
                    string[] attribs = GetUserInfoAsArrayFromLine(line);
                    listToReturn.Add(GetUserObject(attribs[0]));
                }
            }
            return listToReturn;
        }

        static private List<string> GetAllUsersAsStrings()
        {
            List<string> listToReturn = new List<string>();
            StreamReader reader = new StreamReader(userFilePath);
            do 
            {
                string currentLine = reader.ReadLine();
                listToReturn.Add(currentLine);
            } while (!reader.EndOfStream);
            reader.Close();
            return listToReturn;
        }

        // ---- User Methods - Write --- //
        static public void SaveUserToFile(User u)
        {
            bool written = false;
            List<string> existingLines = new List<string>();
            StreamReader reader = new StreamReader(userFilePath);
            do
            {
                existingLines.Add(reader.ReadLine());
            } while (!reader.EndOfStream);
            reader.Close();

            StreamWriter writer = new StreamWriter(userFilePath);
            foreach (string s in existingLines)
            {
                if (s.StartsWith(u.GetID() + ","))
                {
                    writer.WriteLine($@"{u.GetID()},{u.GetPassword()},{u.GetTitle()},{u.GetFirstName()},{u.GetSecondName()}");
                    written = true;
                }
                else
                    writer.WriteLine(s);

                if(!written)
                {
                    writer.WriteLine($@"{u.GetID()},{u.GetPassword()},{u.GetTitle()},{u.GetFirstName()},{u.GetSecondName()}");
                }
            }
            writer.Close();
        }

        // ---- Timeslots ---- //
        // --- user slots --- //
        static private DateTime GetDateTimeFromLine(string line)
        {
                string[] lineVals = line.Split('|');
                string[] dateTimeVals = lineVals[0].Split(' ');

                string[] dateVals = dateTimeVals[0].Split('/');
                string day = dateVals[0];
                string month = dateVals[1];
                string year = dateVals[2];

                string[] timeVals = dateTimeVals[1].Split(':');
                string hour = timeVals[0];
                string minute = timeVals[1];
                string second = timeVals[2];

                return new DateTime(int.Parse(year), int.Parse(month), int.Parse(day), int.Parse(hour), int.Parse(minute), int.Parse(second));
        }

        static private List<string> GetExistingLinesFromUserTimeSlotFile(string userID)
        {
            try
            {
                StreamReader reader = new StreamReader($@"{userTimeSlotFileDir}{userID}.txt");
                List<string> allLines = new List<string>();

                do // Put all existing lines into a list
                {
                    string currentLine = reader.ReadLine();
                    if (currentLine != null)
                    {
                        allLines.Add(currentLine);
                    }
                } while (!reader.EndOfStream);

                return allLines;
            }catch(FileNotFoundException) //if the file isnt found, take it as there are no lines
            {
                return new List<string>();
            }
        }

        static public List<DateTime> GetAllSavedUserTimeSlots(string userID)
        {
            List<DateTime> fetchedDateTimes = new List<DateTime>();
            try
            {
                StreamReader reader = new StreamReader($@"{userTimeSlotFileDir}{userID}.txt");
                string currentLine = "";
                do
                {
                    currentLine = reader.ReadLine();
                    if (currentLine != "")
                    {
                        fetchedDateTimes.Add(GetDateTimeFromLine(currentLine));
                    }
                } while (!reader.EndOfStream);
                reader.Close();
            }
            catch (FileNotFoundException)
            {
                return null;
            }
            return fetchedDateTimes;
        }

        static public DateTime GetUserTimeSlotByMeetingID(string userID, string meetingID)
        {
            DateTime dt = new DateTime();
            try
            {
                StreamReader reader = new StreamReader($@"{userTimeSlotFileDir}{userID}.txt");
                string currentLine = "";

                do
                {
                    currentLine = reader.ReadLine();
                    if (currentLine != "")
                    {
                        dt = GetDateTimeFromLine(currentLine);
                    }
                } while (!reader.EndOfStream);
                reader.Close();
            } catch (FileNotFoundException)
            {
                return new DateTime(0, 0, 0);
            }

            return dt;
        }

        static private string ConvertDateTimeToLine(DateTime dt, string meetingID)
        {
            return $@"{dt.Day}/{dt.Month}/{dt.Year} {dt.Hour}:{dt.Minute}:{dt.Second}|{meetingID}";
        }

        static private List<string> GetExistingLinesFromUserFile(string userID)
        {
            List<string> existingLines = new List<string>();
            string currentLine = "";
            //try
            //{
                StreamReader reader = new StreamReader($@"{userTimeSlotFileDir}{userID}.txt");
                do //Adds each existing line to a string list
                {
                    currentLine = reader.ReadLine();
                    if (currentLine != null) { existingLines.Add(currentLine); }
                } while (!reader.EndOfStream);
                reader.Close();
            //}
            //catch (FileNotFoundException) { }

            return existingLines;
        }

        static public void WriteMeetingRequestToUserFile(MeetingRequest m, string userID)
        {
            List<string> existingLines = GetExistingLinesFromUserFile(userID);
            StreamWriter writer = null;
            try
            {
                writer = new StreamWriter($@"{userTimeSlotFileDir}{userID}.txt");
                string newLine = ConvertDateTimeToLine(m.GetDate(), $@"{m.GetID()}");
                bool written = false;
                foreach (string line in existingLines)
                {
                    if (m.GetDate() == GetDateTimeFromLine(line)) //if the timeslot already exists
                    {
                        MessageBox.Show("Line Cannot Be Written - Meeting already exists at that time");
                        written = true;
                    }
                    else
                    {
                        writer.WriteLine(line);
                    }
                }
                if (!written) { writer.WriteLine(newLine); }
                //writer.Flush();
                //writer.Dispose();
                //writer.Close();
            }
            catch (IOException) { MessageBox.Show("user file went wrong"); }
            finally 
            {
                if(writer != null)
                {
                    writer.Dispose();
                    writer.Close();
                }
            }
        }
        
        static public bool IsUserAvailableAt(DateTime dt, User u)
        {
            //loop through list of all meetings
            List<Meeting> allMeetings = GetAllMeetings();

            foreach(Meeting m in allMeetings)
            {
                if(m.GetDate().CompareTo(dt) == 0)
                {
                    foreach(User tempUser in m.GetParticipants())
                    {
                        if(tempUser != null)
                        {
                            if (u.GetID() == tempUser.GetID())
                            {
                                return false;
                            }
                        }
                    }
                }
            }
            return true;
        }

        static public bool IsUserAvailableAt(DateTime dtToCheck, string userID)
        {
            List<DateTime> dateTimesFromFile = new List<DateTime>();
            List<string> lines = GetExistingLinesFromUserTimeSlotFile(userID);
            if (lines.Count != 0)
            {
                foreach (string line in lines)
                {
                    dateTimesFromFile.Add(GetDateTimeFromLine(line));
                }
                foreach (DateTime dt in dateTimesFromFile)
                {
                    if (dtToCheck.ToString() == dt.ToString())
                    {
                        return false;
                    }
                }
            }
            return true;
        }

        static public void RemoveMeetingFromUserFile(Meeting m, string userID)
        {
            List<string> lines = GetExistingLinesFromUserTimeSlotFile(userID);
            StreamWriter writer = new StreamWriter($@"{userTimeSlotFileDir}{userID}.txt");
            foreach (string line in lines)
            {
                if (m.GetDate() == GetDateTimeFromLine(line) && m.GetMeetingID() == ExtractMeetingIDFromLine(line)) //if the timeslot already exists
                {
                    lines.Remove(line);
                }
            }
            foreach(string line in lines)
            {
                writer.WriteLine(line);
            }
        }

        static private int ExtractMeetingIDFromLine(string line)
        {
            string[] lineHalves = line.Split('|');
            return int.Parse(lineHalves[1]);
        }

        // ---- Room Slots ---- //

        static private List<string> GetExistingLinesFromRoomTimeSlotFile(string roomID, string buildingID)
        {
            List<string> allLines = new List<string>();
            try
            {
                StreamReader reader = new StreamReader($@"{roomTimeSlotFileDir}{roomID}-{buildingID}.txt");
                do // Put all existing lines into a list
                {
                    string currentLine = reader.ReadLine();
                    if (currentLine != null)
                    {
                        allLines.Add(currentLine);
                    }
                } while (!reader.EndOfStream);          
            }
            catch(FileNotFoundException)
            {
                return null;
            }
            return allLines;
        }
        static public void WriteMeetingRequestToRoomFile(MeetingRequest m)
        {
            List<string> existingLines = GetExistingLinesFromRoomTimeSlotFile(m.GetRoomPref().GetRoomID(), m.GetRoomPref().GetBuildingID());
            StreamWriter writer = null;
            try
            {
                writer = new StreamWriter($@"{roomTimeSlotFileDir}{m.GetRoomPref().GetRoomID()}-{m.GetRoomPref().GetBuildingID()}.txt");
                string newLine = ConvertDateTimeToLine(m.GetDate(), $@"{m.GetID()}");
                bool written = false;
                foreach (string line in existingLines)
                {
                    if (newLine == line) //if the timeslot already exists
                    {
                        written = true;
                    }
                    else
                    {
                        writer.WriteLine(line);
                    }
                }
                if (!written) { writer.WriteLine(newLine); }
            }
            catch (IOException) { MessageBox.Show("Some shitty thing has been caught writing to' room file"); }
            finally 
            {
                if(writer != null)
                {
                    writer.Dispose();
                    writer.Close();
                }
            }
            

        }
        static public void RemoveMeetingFromRoomFile(Meeting m, string roomID, string buildingID)
        {
            List<string> lines = GetExistingLinesFromRoomTimeSlotFile(roomID, buildingID);
            StreamWriter writer = new StreamWriter($@"{roomTimeSlotFileDir}{m.GetRoom().GetRoomID()}-{m.GetRoom().GetBuildingID()}");
            foreach (string line in lines)
            {
                if (m.GetDate() == GetDateTimeFromLine(line) && m.GetMeetingID() == ExtractMeetingIDFromLine(line)) //if the timeslot already exists
                {
                    lines.Remove(line);
                }
            }
            foreach (string line in lines)
            {
                writer.WriteLine(line);
            }
        }
        static public bool IsRoomAvailableAt(DateTime dt, Room r)
        {
            List<Meeting> allMeetings = GetAllMeetings();
            foreach (Meeting m in allMeetings)
            {
                if (m.GetDate().CompareTo(dt) == 0)
                {
                    if(m.GetRoom().GetRoomID() == r.GetRoomID())
                    {
                        if(m.GetRoom().GetBuildingID() == r.GetBuildingID())
                        {
                            return false;
                        }
                    }
                }
            }
            return true;
        }
        

        static public List<DateTime> GetTakenTimeSlotsForRoom(Room r)
        {
            List<DateTime> listToReturn = new List<DateTime>();
            List<string> lines = new List<string>();

            if (r != null)
            {
                lines = GetExistingLinesFromRoomTimeSlotFile(r.GetRoomID(), r.GetBuildingID());
                foreach (string line in lines)
                {
                    listToReturn.Add(GetDateTimeFromLine(line));
                }
                return listToReturn;
            }
            else
            {
                return null;
            }
            
        }
        // ---- Misc ---- //
        static public int GetGreatestUserID()
        {
            int greatestID = 0;
            StreamReader reader = new StreamReader(userFilePath);
            do
            {
                string currentLine = reader.ReadLine();
                if (currentLine != null)
                {
                    string[] valArray = currentLine.Split(',');
                    if (valArray[0] != null)
                    {
                        if (int.Parse(valArray[0]) >= greatestID)
                        {
                            greatestID = int.Parse(valArray[0]);
                        }
                    }
                }
            } while (!reader.EndOfStream);
            reader.Close();
            return greatestID;
        }

        static public int GetGreatestMeetingID()
        {
            int greatestID = 0;
            StreamReader reader = new StreamReader(meetingFilePath);
            do
            {
                string currentLine = reader.ReadLine();
                if (currentLine != null)
                {
                    string[] valArray = currentLine.Split(',');
                    if (valArray[0] != null)
                    {
                        if (int.Parse(valArray[0]) >= greatestID)
                        {
                            greatestID = int.Parse(valArray[0]);
                        }
                    }
                }
            } while (!reader.EndOfStream);
            reader.Close();
            return greatestID;
        }

        static public int GetGreatestMeetingRequestID()
        {
            int greatestID = 0;
            StreamReader reader = new StreamReader(meetingRequestFilePath);
            do
            {
                string currentLine = reader.ReadLine();
                if (currentLine != null)
                {
                    string[] valArray = currentLine.Split(',');
                    if (valArray[0] != null)
                    {
                        if (int.Parse(valArray[0]) >= greatestID)
                        {
                            greatestID = int.Parse(valArray[0]);
                        }
                    }
                }
            } while (!reader.EndOfStream);
            reader.Close();
            return greatestID;
        }
    }
}
