﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MeetingScheduler
{
    public partial class Form1 : Form
    {
        User currentUser;
        List<Meeting> upcomingMeetingsList;
        List<Meeting> myMeetingsList;
        List<MeetingRequest> meetingsToAcceptList;
        List<MeetingRequest> myMeetingRequestsList;

        //Create Meeting global variables
        List<Room> createMeeting_AvailableRooms = new List<Room>();
        List<User> createMeeting_AvailableParticipants = new List<User>();
        List<User> createMeeting_AddedParticipants = new List<User>();

        public Form1()
        {
            InitializeComponent();

            // ---------------------------------------------------------- //
            // --- NOTES:                                             --- //
            // --- With the DataFileHandler (DFH), everything in this --- //
            // --- form code should be minimal. Any reading or        --- //
            // --- writing to/from any of the files should be handled --- //
            // --- by the DFH only. This will ensure that all read    --- //
            // --- and write operations work flawlessly and uniformly --- //
            // --- with each other.                                   --- //
            // ---------------------------------------------------------- //

            // TODO:
            // Sort out "File being used by another process" exception when a 2nd meeting gets created consecutively
            // Sort cancel meeting request button
            //    - Deleted all timeslot records for all participants included#
            // On create meeting request, validate the amount of users invited. Cant be less than 2.
            // Find conditions that allows the meeting request to turn into a full-fledged meeting

            // TODO (if time permits, probably not lol)
            // For Create meeting request, concatonate "(initator)" to the end of the name of the participant IF the user ID matches the current User

        }
        private void Form1_Load(object sender, EventArgs e)
        {
            combobox_CreateMeetingRequest_Time.SelectedIndex = 0;
            combobox_CreateMeetingRequest_AvailablePeople.Enabled = false;
            listbox_CreateMeetingRequest_PeopleInvited.Enabled = false;
        }

        private void btn_LogIn_Register_Click(object sender, EventArgs e)
        {
            string firstName = Microsoft.VisualBasic.Interaction.InputBox("Please enter your First Name: ", "Register your Account", "", 0, 0);
            string secondName = Microsoft.VisualBasic.Interaction.InputBox("Please enter your Second Name: ", "Register your Account", "", 0, 0);
            string title = Microsoft.VisualBasic.Interaction.InputBox("Please enter your Title: ", "Register your Account", "", 0, 0);
            string password = Microsoft.VisualBasic.Interaction.InputBox("Please enter your new Password: ", "Register your Account", "", 0, 0);
            string passwordCheck = Microsoft.VisualBasic.Interaction.InputBox("Please enter your enter your Password again:  ", "Register your Account", "", 0, 0);
            bool passMatching = false;
            if (password == passwordCheck) passMatching = true;
            if (passMatching)  //validation for if the password checker matched the chosen pword
            {
                int newID = DataFileHandler.GetGreatestUserID() + 1;
                User p = new User(newID, password, title, firstName, secondName); //passes values from inputboxes into ctor
                DataFileHandler.SaveUserToFile(p);
            }
            else
            {
                MessageBox.Show("The passwords you entered did not match. Please try again.");
            }
        }

        private void btn_LogIn_Submit_Click(object sender, EventArgs e)
        {
            string inputtedUserID;
            string inputtedPassword;
            string filePath = DataFileHandler.GetUserFilePath();

            inputtedUserID = txtbox_LogIn_UserID.Text;
            inputtedPassword = txtbox_LogIn_Password.Text;     //sets the variables to what was in the textboxes (TB's)
            bool valid = false;

            User tempUser = DataFileHandler.GetUserObject(inputtedUserID);
            if (tempUser != null)
            {
                if (tempUser.GetPassword() == inputtedPassword)
                {
                    valid = true;
                }
                else valid = false;
            }
            else
            {
                MessageBox.Show("User was not found");
            }

            if (valid == true)
            {
                MessageBox.Show("Logged in");
                currentUser = tempUser;
                listbox_MainMenu_UpcomingMeetings.Items.Clear();
                groupbox_MainMenu.Visible = true;
                grpbox_LogIn.Visible = false;
                btn_LogOut.Visible = true;
                LoadUserLists();
            }
            else
            {
                MessageBox.Show("The credentials entered do not match any accounts in the database. Please check your spelling and try again.");
            }

        }
        private void LoadUserLists()
        {
            upcomingMeetingsList = DataFileHandler.GetAllUpcomingMeetingsForUser($@"{currentUser.GetID()}");
            myMeetingsList = DataFileHandler.GetAllUpcomingMeetingsForInitiator($@"{currentUser.GetID()}");
            meetingsToAcceptList = DataFileHandler.GetAllUpcomingMeetingRequestsForUser($@"{currentUser.GetID()}");
            myMeetingRequestsList = DataFileHandler.GetAllUpcomingMeetingRequestsForInitiator($@"{currentUser.GetID()}");
            RefreshMainMenu();
        }
       
        private void RefreshMainMenu()
        {
            listbox_MainMenu_UpcomingMeetings.Items.Clear();
            listbox_MainMenu_MyMeetings.Items.Clear();
            listbox_MainMenu_MeetingsToAccept.Items.Clear();
            listbox_MainMenu_MyMeetingRequests.Items.Clear();

            foreach (Meeting m in upcomingMeetingsList)
            {
                listbox_MainMenu_UpcomingMeetings.Items.Add($@"{m.GetMeetingID()} - {m.GetDate()} - {m.GetRoom().GetRoomID()}-{m.GetRoom().GetBuildingID()}");
            }
            foreach (Meeting m in myMeetingsList)
            {
                listbox_MainMenu_MyMeetings.Items.Add($@"{m.GetMeetingID()} - {m.GetDate()} - {m.GetRoom().GetRoomID()}-{m.GetRoom().GetBuildingID()}");
            }
            foreach(MeetingRequest m in meetingsToAcceptList)
            {
                listbox_MainMenu_MeetingsToAccept.Items.Add($@"{m.GetID()} - {m.GetDate()} - {m.GetRoomPref().GetRoomID()}-{m.GetRoomPref().GetBuildingID()}");
            }
            foreach(MeetingRequest m in myMeetingRequestsList)
            {
                listbox_MainMenu_MyMeetingRequests.Items.Add($@"{m.GetID()} - {m.GetDate()} - {m.GetRoomPref().GetRoomID()}-{m.GetRoomPref().GetBuildingID()}");
            }
        }

        private void lbl_ViewMeetingRequestInfo_InitiatorName_Click(object sender, EventArgs e)
        {

        }

        private void RefreshMeetingRequestInfo(MeetingRequest r)
        {
            lbl_ViewMeetingRequestInfo_InitiatorName.Text = $@"Initiator: {r.GetInitiator().GetFirstName()} {r.GetInitiator().GetSecondName()}";
            lbl_ViewMeetingRequestInfo_DateScheduled.Text = $@"Time Scheduled: {r.GetDate()}";
            lbl_ViewMeetingRequestInfo_RoomNumber.Text = $@"Room Number: {r.GetRoomPref().GetRoomID()}";
            lbl_ViewMeetingRequestInfo_BuildingNumber.Text = $@"Building Number: {r.GetRoomPref().GetBuildingID()}";

            if (r.GetRoomPref().HasProjector()) { lbl_ViewMeetingRequestInfo_Projector.Text = "Projector: Yes"; }
            else lbl_ViewMeetingRequestInfo_Projector.Text = "Projector: No";

            if (r.GetRoomPref().HasPASystem()) { lbl_ViewMeetingRequestInfo_PASystem.Text = "PA System: Yes"; }
            else lbl_ViewMeetingRequestInfo_PASystem.Text = "PA System: No";

            if (r.GetRoomPref().HasWheelchairAccess()) { lbl_ViewMeetingRequestInfo_WCAccess.Text = "Wheelchair Access: Yes"; }
            else lbl_ViewMeetingRequestInfo_WCAccess.Text = "Wheelchair Access: No";

            listbox_ViewMeetingRequestInfo_Invited.Items.Clear();

            foreach (User u in r.GetPeopleInvited())
            {
                if (u != null)
                    listbox_ViewMeetingRequestInfo_Invited.Items.Add($@"{u.GetFullName()} (User ID: {u.GetID()})");
            }

            listbox_ViewMeetingRequestInfo_Confirmed.Items.Clear();
            foreach (User u in r.GetPeopleConfirmed())
            {
                if(u != null)
                    listbox_ViewMeetingRequestInfo_Confirmed.Items.Add($@"{u.GetFullName()} (User ID: {u.GetID()})");
            }

            listbox_ViewMeetingRequestInfo_Unavailable.Items.Clear();
            foreach (User u in r.GetPeopleUnavailable())
            {
                if (u != null)
                    listbox_ViewMeetingRequestInfo_Unavailable.Items.Add($@"{u.GetFullName()} (User ID: {u.GetID()})");
            }

        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
            combobox_CreateMeetingRequest_AvailableRooms.SelectedItem = null;
            combobox_CreateMeetingRequest_AvailableRooms.Items.Clear();

            bool needProjector = checkbox_CreateMeetingRequest_NeedProjecter.Checked;
            bool needPA = checkbox_CreateMeetingRequest_NeedPA.Checked;
            bool needWCA = checkbox_CreateMeetingRequest_NeedWCAccess.Checked;

            // Assigns the chosen time --------------
            DateTime datePicked = dateTimePicker1.Value;
            int day = datePicked.Day; int month = datePicked.Month; int year = datePicked.Year; int hour = 0;
            if (combobox_CreateMeetingRequest_Time.SelectedItem != null)
            {
                string[] timeSplit = combobox_CreateMeetingRequest_Time.Text.Split(':');
                hour = int.Parse(timeSplit[0]);
            }
            DateTime actualDateTime = new DateTime(year, month, day, hour, 0, 0);
            // ---------------------------------------

            // Rooms ---------------------------------
            createMeeting_AvailableRooms = CreateMeeting_GetValidRooms(actualDateTime, needProjector, needPA, needWCA);
            CreateMeeting_UpdateRoomList();
            // --------------------------------------

            // Participants --------------------------
            combobox_CreateMeetingRequest_AvailablePeople.SelectedItem = null;
            combobox_CreateMeetingRequest_AvailablePeople.Items.Clear();

            createMeeting_AvailableParticipants = CreateMeeting_GetValidUsers(actualDateTime);
            createMeeting_AddedParticipants.Clear();
            CreateMeeting_UpdateParticipantList();
            // ---------------------------------------
        }

        private void CreateMeeting_AddParticipantToMeetingRequest()
        {
            int selectedIndex = combobox_CreateMeetingRequest_AvailablePeople.SelectedIndex;
            if(selectedIndex != -1)
            {
                createMeeting_AddedParticipants.Add(createMeeting_AvailableParticipants[selectedIndex]);
                createMeeting_AvailableParticipants.RemoveAt(selectedIndex);
                CreateMeeting_UpdateParticipantList();
            }
        }

        private void CreateMeeting_RemovePartipantFromMeetingRequest()
        {
            int selectedIndex = listbox_CreateMeetingRequest_PeopleInvited.SelectedIndex;
            if(selectedIndex != -1)
            {
                createMeeting_AvailableParticipants.Add(createMeeting_AddedParticipants[selectedIndex]);
                createMeeting_AddedParticipants.RemoveAt(selectedIndex);
                CreateMeeting_UpdateParticipantList();
            }
        }

        private List<User> CreateMeeting_GetValidUsers(DateTime dtToCheck)
        {
            //First get all Users
            List<User> unfilteredUsers = DataFileHandler.GetAllUsers();
            List<User> filteredUsers = new List<User>();
            //loop through list and check if theyre available
            foreach (User u in unfilteredUsers)
            {
                bool userInvalid = false;
                if (!DataFileHandler.IsUserAvailableAt(dtToCheck, u)) { userInvalid = true; }
                if (!userInvalid)
                {
                    filteredUsers.Add(u);
                }
            }
            return filteredUsers;
        }

        private void CreateMeeting_UpdateParticipantList()
        {
            combobox_CreateMeetingRequest_AvailablePeople.Items.Clear();
            listbox_CreateMeetingRequest_PeopleInvited.Items.Clear();

            combobox_CreateMeetingRequest_AvailablePeople.Text = "";

            foreach (User p in createMeeting_AvailableParticipants)
            {
                combobox_CreateMeetingRequest_AvailablePeople.Items.Add($@"{p.GetFullName()} (User ID: {p.GetID()})");
            }

            foreach(User p in createMeeting_AddedParticipants)
            {
                listbox_CreateMeetingRequest_PeopleInvited.Items.Add($@"{p.GetFullName()} (User ID: {p.GetID()})");
            }
        }

        private void CreateMeeting_UpdateRoomList()
        {
            combobox_CreateMeetingRequest_AvailableRooms.Items.Clear();

            foreach (Room r in createMeeting_AvailableRooms) 
            {
                combobox_CreateMeetingRequest_AvailableRooms.Items.Add($@"Room: {r.GetRoomID()} - Building: {r.GetBuildingID()}");
            }
        }

        private List<Room> CreateMeeting_GetValidRooms(DateTime dtToCheck, bool proj, bool pa, bool wca)
        {
            //First get all rooms
             List<Room> unfilteredRooms = DataFileHandler.GetAllRooms();
             List<Room> filteredRooms = new List<Room>();
             //loop through list and check if theyre allowed
             foreach (Room r in unfilteredRooms)
             {
                bool roomInvalid = false;
                if (proj && !r.HasProjector()) { roomInvalid = true; }
                if (pa && !r.HasPASystem()) { roomInvalid = true; }
                if (wca && !r.HasWheelchairAccess()) { roomInvalid = true; }
                if (!DataFileHandler.IsRoomAvailableAt(dtToCheck, r)) { roomInvalid = true; }
                if (!roomInvalid)
                {
                    filteredRooms.Add(r);
                }
             }
            return filteredRooms;
        }
        private void btn_CreateMeetingRequest_Submit_Click(object sender, EventArgs e)
        {
            DateTime datePicked = dateTimePicker1.Value;
            int day = datePicked.Day; int month = datePicked.Month; int year = datePicked.Year; int hour = 0;
            if (combobox_CreateMeetingRequest_Time.SelectedItem != null)
            {
                string[] timeSplit = combobox_CreateMeetingRequest_Time.Text.Split(':');
                hour = int.Parse(timeSplit[0]);
            }
            DateTime actualDateTime = new DateTime(year, month, day, hour, 0, 0);

            MeetingRequest newMeeting = new MeetingRequest(DataFileHandler.GetGreatestMeetingRequestID()+1, actualDateTime, createMeeting_AvailableRooms[combobox_CreateMeetingRequest_AvailableRooms.SelectedIndex], 
                                                           createMeeting_AddedParticipants, new List<User>(), new List<User>(), currentUser);
            if (newMeeting.GetPeopleInvited().Count >= 2)
            {
                DataFileHandler.WriteMeetingRequestToFile(newMeeting);
                string participantsLine = "";
                foreach (User u in newMeeting.GetPeopleInvited())
                {
                    participantsLine = $@"{participantsLine} {u.GetFullName()},";
                }
                participantsLine = participantsLine.TrimEnd(',');
                MessageBox.Show($@"Meeting request {newMeeting.GetID()} has been created for the date and time {newMeeting.GetDate()}.{Environment.NewLine} Participants: {participantsLine}");
            }
            else
            {
                MessageBox.Show($@"Meeting request cannot be created, you need at least 2 participants to be invited");
            }


            // Loop through all invited participants and add the actualDateTime to their timeslot file
            //foreach(User u in newMeeting.GetPeopleInvited())
            //{
            //    DataFileHandler.WriteMeetingRequestToUserFile(newMeeting, $@"{u.GetID()}");
            //}
            // Same for room
            // DataFileHandler.WriteMeetingRequestToRoomFile(newMeeting);
            // DO THIS EVERY TIME FILES HAVE BEEN CHANGED

            LoadUserLists();
            RefreshMainMenu();

        }

        private void RefreshViewMeeting(Meeting r)
        {
            listbox_ViewMeetingInfo_Participants.Items.Clear();
            lbl_ViewMeetingInfo_InitiatorName.Text = $@"Initiator: {r.GetInitiator().GetFirstName()} {r.GetInitiator().GetSecondName()}";
            lbl_ViewMeetingInfo_DateScheduled.Text = $@"Time Scheduled: {r.GetDate()}";

            lbl_ViewMeetingInfo_RoomID.Text = $@"Room Number: {r.GetRoom().GetRoomID()}";
            lbl_ViewMeetingInfo_BuildingID.Text = $@"Building Number: {r.GetRoom().GetBuildingID()}";

            if (r.GetRoom().HasProjector()) { lbl_ViewMeetingInfo_Projector.Text = "Projector: Yes"; }
            else lbl_ViewMeetingInfo_Projector.Text = "Projector: No";

            if (r.GetRoom().HasPASystem()) { lbl_ViewMeetingInfo_PASystem.Text = "PA System: Yes"; }
            else lbl_ViewMeetingInfo_PASystem.Text = "PA System: No";

            if (r.GetRoom().HasWheelchairAccess()) { lbl_ViewMeetingInfo_WCAccess.Text = "Wheelchair Access: Yes"; }
            else lbl_ViewMeetingInfo_WCAccess.Text = "Wheelchair Access: No";

            foreach (User u in r.GetParticipants())
            {
                if (u != null)
                {
                    listbox_ViewMeetingInfo_Participants.Items.Add($@"{u.GetFullName()} (User ID: {u.GetID()})");
                }
            }


        }

        private void combobox_CreateMeetingRequest_Time_SelectedIndexChanged(object sender, EventArgs e)
        {
            dateTimePicker1_ValueChanged(sender, e);
        }

        private void checkbox_CreateMeetingRequest_NeedProjecter_CheckedChanged(object sender, EventArgs e)
        {
            dateTimePicker1_ValueChanged(sender, e);
        }

        private void checkbox_CreateMeetingRequest_NeedPA_CheckedChanged(object sender, EventArgs e)
        {
            dateTimePicker1_ValueChanged(sender, e);
        }

        private void checkbox_CreateMeetingRequest_NeedWCAccess_CheckedChanged(object sender, EventArgs e)
        {
            dateTimePicker1_ValueChanged(sender, e);
        }

        private void listbox_MainMenu_UpcomingMeetings_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listbox_MainMenu_UpcomingMeetings.SelectedIndex != -1)
            {
                listbox_MainMenu_MeetingsToAccept.SelectedItem = null;
                listbox_MainMenu_MyMeetings.SelectedItem = null;
                listbox_MainMenu_MyMeetingRequests.SelectedItem = null;

                RefreshViewMeeting(upcomingMeetingsList[listbox_MainMenu_UpcomingMeetings.SelectedIndex]);

                groupbox_ViewMeetingInfo.Visible = true;
                groupbox_ViewMeetingRequestInfo.Visible = false;
            }
        }

        private void listbox_MainMenu_MyMeetings_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listbox_MainMenu_MyMeetings.SelectedIndex != -1)
            {
                listbox_MainMenu_MeetingsToAccept.SelectedItem = null;
                listbox_MainMenu_UpcomingMeetings.SelectedItem = null;
                listbox_MainMenu_MyMeetingRequests.SelectedItem = null;

                RefreshViewMeeting(myMeetingsList[listbox_MainMenu_MyMeetings.SelectedIndex]);

                groupbox_ViewMeetingInfo.Visible = true;
                groupbox_ViewMeetingRequestInfo.Visible = false;
            }
        }

        private void listbox_MainMenu_MeetingsToAccept_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listbox_MainMenu_MeetingsToAccept.SelectedIndex != -1)
            {
                listbox_MainMenu_MyMeetings.SelectedItem = null;
                listbox_MainMenu_UpcomingMeetings.SelectedItem = null;
                listbox_MainMenu_MyMeetingRequests.SelectedItem = null;

                RefreshMeetingRequestInfo(meetingsToAcceptList[listbox_MainMenu_MeetingsToAccept.SelectedIndex]);

                groupbox_ViewMeetingInfo.Visible = false;
                groupbox_ViewMeetingRequestInfo.Visible = true;
            }
            else
            {
            }
        }

        private void listbox_MainMenu_MyMeetingRequests_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(listbox_MainMenu_MyMeetingRequests.SelectedIndex != -1)
            {
                listbox_MainMenu_MyMeetings.SelectedItem = null;
                listbox_MainMenu_UpcomingMeetings.SelectedItem = null;
                listbox_MainMenu_MeetingsToAccept.SelectedItem = null;

                RefreshMeetingRequestInfo(myMeetingRequestsList[listbox_MainMenu_MyMeetingRequests.SelectedIndex]);

                groupbox_ViewMeetingInfo.Visible = false;
                groupbox_ViewMeetingRequestInfo.Visible = true;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            grpbox_CreateMeetingRequest.Visible = false;
        }

        private void btn_MainMenu_CreateMeetingRequest_Click(object sender, EventArgs e)
        {
            grpbox_CreateMeetingRequest.Visible = true;
            listbox_MainMenu_MeetingsToAccept.SelectedItem = null;
            listbox_MainMenu_UpcomingMeetings.SelectedItem = null;
            listbox_MainMenu_MyMeetings.SelectedItem = null;
            listbox_MainMenu_MyMeetingRequests.SelectedItem = null;

            groupbox_ViewMeetingInfo.Visible = false;
            groupbox_ViewMeetingRequestInfo.Visible = false;
        }

        private void btn_MainMenu_CancelMeeting_Click(object sender, EventArgs e)
        {
            if(listbox_MainMenu_MyMeetingRequests.SelectedIndex != -1)
            {
                MeetingRequest selectedMeeting = myMeetingRequestsList[listbox_MainMenu_MyMeetingRequests.SelectedIndex];
                DialogResult result = MessageBox.Show("Are you sure you want to cancel this Meeting Request?", "Caution", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    DataFileHandler.DeleteMeetingRequestFromFile(selectedMeeting);
                    MessageBox.Show("Meeting request has been cancelled!");
                }
                LoadUserLists();
                RefreshMainMenu();
            }
        }

        private void btn_CreateMeetingRequest_AddParticipant_Click(object sender, EventArgs e)
        {

            CreateMeeting_AddParticipantToMeetingRequest();
        }

        private void btn_CreateMeetingRequest_RemoveParticipant_Click(object sender, EventArgs e)
        {
            CreateMeeting_RemovePartipantFromMeetingRequest();
        }

        private void combobox_CreateMeetingRequest_AvailableRooms_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(combobox_CreateMeetingRequest_AvailableRooms.SelectedIndex != -1)
            {
                // if it does have a valid room selected
                combobox_CreateMeetingRequest_AvailablePeople.Enabled = true;
                listbox_CreateMeetingRequest_PeopleInvited.Enabled = true;

                //reset available list
                DateTime datePicked = dateTimePicker1.Value;
                int day = datePicked.Day; int month = datePicked.Month; int year = datePicked.Year; int hour = 0;
                if (combobox_CreateMeetingRequest_Time.SelectedItem != null)
                {
                    string[] timeSplit = combobox_CreateMeetingRequest_Time.Text.Split(':');
                    hour = int.Parse(timeSplit[0]);
                }
                DateTime actualDateTime = new DateTime(year, month, day, hour, 0, 0);
                createMeeting_AvailableParticipants = CreateMeeting_GetValidUsers(actualDateTime);
               
                //empty added list
                createMeeting_AddedParticipants.Clear();
                
                
                CreateMeeting_UpdateParticipantList();

            }
            else
            {
                //if not
                combobox_CreateMeetingRequest_AvailablePeople.Enabled = false;
                listbox_CreateMeetingRequest_PeopleInvited.Enabled = false;
                CreateMeeting_UpdateParticipantList();
            }
        }

        private void btn_MainMenu_AcceptMeeting_Click(object sender, EventArgs e)
        {
            int selectedIndex = listbox_MainMenu_MeetingsToAccept.SelectedIndex;
            if (selectedIndex != -1)
            {
                //Get the correct meeting request in the list
                MeetingRequest r = meetingsToAcceptList[selectedIndex];
                //Add currentUser to confirmed
                r.AddPersonToConfirmed(currentUser);
                //remove currentUser from invited
                User foundUser = null;
                foreach (User u in r.GetPeopleInvited())
                {
                    if (u.GetID() == currentUser.GetID()) { foundUser = u; }
                }
                if (foundUser != null)
                {
                    r.GetPeopleInvited().Remove(foundUser);
                }
                //re-write the meeting request to file
                DataFileHandler.WriteMeetingRequestToFile(r);
                //refresh lists and hide all un-needed modules
                LoadUserLists();
                RefreshMainMenu();
                MessageBox.Show("Meeting Accepted!");
            }
        }

        private void btn_MainMenu_DeclineMeeting_Click(object sender, EventArgs e)
        {
            int selectedIndex = listbox_MainMenu_MeetingsToAccept.SelectedIndex;
            //Get the correct meeting request in the list
            if (selectedIndex != -1)
            {
                MeetingRequest r = meetingsToAcceptList[selectedIndex];
                //Add currentUser to unavailable
                r.AddPersonToUnvailable(currentUser);
                //remove currentUser from invited
                User foundUser = null;
                foreach (User u in r.GetPeopleInvited())
                {
                    if (u.GetID() == currentUser.GetID()) { foundUser = u; }
                }
                if (foundUser != null)
                {
                    r.GetPeopleInvited().Remove(foundUser);
                }
                //re-write the meeting request to file
                DataFileHandler.WriteMeetingRequestToFile(r);
                //refresh lists and hide all un-needed modules
                LoadUserLists();
                RefreshMainMenu();
                MessageBox.Show("Meeting Declined!");
            }
        }

        private void btn_LogOut_Click(object sender, EventArgs e)
        {
            Application.Restart();
        }

        private void btn_MainMenu_Finalise_Click(object sender, EventArgs e)
        {
            int selectedIndex = listbox_MainMenu_MyMeetingRequests.SelectedIndex;
            if (selectedIndex != -1)
            {
                MeetingRequest mR = myMeetingRequestsList[selectedIndex];
                MessageBox.Show($@"{mR.GetID()} - {mR.GetPeopleConfirmed()}");
                DialogResult result = MessageBox.Show("Are you sure you want to finalise this Meeting Request", "Caution", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    int newMeetingID = DataFileHandler.GetGreatestMeetingID() + 1;
                    Meeting m = new Meeting(newMeetingID, mR);
                    MessageBox.Show($@"{m.GetMeetingID()} - {m.GetParticipants()}");
                    if (DataFileHandler.IsRoomAvailableAt(m.GetDate(), m.GetRoom()))
                    {
                        if (m.GetParticipants().Count >= 2)
                        {
                            bool userValid = true;
                            foreach (User u in m.GetParticipants())
                            {
                                if(!DataFileHandler.IsUserAvailableAt(m.GetDate(), u)) userValid = false;
                            }
                            if (userValid)
                            {
                                DataFileHandler.DeleteMeetingRequestFromFile(mR);
                                DataFileHandler.SaveMeetingToFile(m);
                                MessageBox.Show("Meeting has been finalised");
                            }
                            else if (!userValid)
                            {
                                MessageBox.Show("One or more participants have become unavailable at this time. Please create another meeting request");
                            }
                        }
                        else
                        {
                            MessageBox.Show("Meeting cannot be finalised. Must have 2 or more confirmed participants");
                        }
                    }
                }
                else { }
            }
            LoadUserLists();
            RefreshMainMenu();
        }
    }
}
