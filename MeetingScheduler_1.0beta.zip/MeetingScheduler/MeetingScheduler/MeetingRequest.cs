﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeetingScheduler
{
    class MeetingRequest
    {
        private int requestID;

        private DateTime startDateTime;
        
        private Room roomPref;       

        private List<User> invited;
        private List<User> unavailable;
        private List<User> confirmed;

        private User initiator;

        public MeetingRequest(int id, DateTime date, Room roomPref, List<User> invited, 
                              List<User> unavailable, List<User> confirmed, User initiator)
        {
            this.requestID = id; this.roomPref = roomPref;
            this.invited = invited; this.unavailable = unavailable; 
            this.confirmed = confirmed; this.initiator = initiator;
            this.startDateTime = date;
        }
        //getters
        public int GetID() { return this.requestID; }
        public DateTime GetDate() { return this.startDateTime; }
        public Room GetRoomPref() { return this.roomPref; }

        public List<User> GetPeopleInvited() { return this.invited; }
        public List<User> GetPeopleUnavailable() { return this.unavailable; }
        public List<User> GetPeopleConfirmed() { return this.confirmed; }
        public User GetInitiator() { return this.initiator; }
        
        //setters
        public void SetDate(DateTime newDate) { this.startDateTime = newDate; }
        public void SetRoomPref(Room newRoom) { this.roomPref = newRoom; }

        public void SetPeopleInvited(List<User> newList) { this.invited = newList; }
        public void SetPeopleUnavailable(List<User> newList) { this.unavailable = newList; }
        public void SetPeopleConfirmed(List<User> newList) { this.confirmed = newList; }
        public void SetInitiator(User p) { this.initiator = p; }

        // other
        public void AddPersonToInvited(User newP) { invited.Add(newP); }
        public void AddPersonToUnvailable(User newP) { unavailable.Add(newP); }
        public void AddPersonToConfirmed(User newP) { confirmed.Add(newP); }
        public void RemovePersonFromInvited(User newP) 
        {
            foreach(User p in invited)
            {
                if(p.GetID() == newP.GetID()) { invited.Remove(p); }
            }
        }
        public void RemovePersonFromUnavailable(User newP)
        {
            foreach (User p in invited)
            {
                if (p.GetID() == newP.GetID()) { unavailable.Remove(p); }
            }
        }
        public void RemovePersonFromConfirmed(User newP)
        {
            foreach (User p in invited)
            {
                if (p.GetID() == newP.GetID()) { confirmed.Remove(p); }
            }
        }
    }
}
