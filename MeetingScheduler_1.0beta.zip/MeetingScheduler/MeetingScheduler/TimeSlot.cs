﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeetingScheduler
{
    class TimeSlot
    {
        private int startHour;
        private int startMinute;

        public TimeSlot(int hour, int min)
        {
            startHour = hour;
            startMinute = min;
        }

        public int GetHour() { return startHour; }
        public int GetMinute() { return startMinute;  }
        public string GetTimeAsString() { return startHour + ":" + startMinute; }
        public void SetHour(int hour) { startHour = hour; }
        public void SetMinute(int min) { startMinute = min; }

    }
}
