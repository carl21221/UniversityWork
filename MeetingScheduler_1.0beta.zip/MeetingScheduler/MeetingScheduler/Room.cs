﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MeetingScheduler
{
    class Room
    {
        //Variables
        private string roomID = "";
        private string buildingID = "";
        
        private int maxCapacity = 0;

        private bool hasProjector = false;
        private bool hasPASystem = false;
        private bool hasWheelchairAccess = false;

        //Constructors
        public Room(string roomID, string buildingID, int maxCapacity, bool hasProjector, bool hasPASystem, bool WCAccess)
        {
            this.roomID = roomID;
            this.buildingID = buildingID;
            this.maxCapacity = maxCapacity;
            this.hasProjector = hasProjector;
            this.hasPASystem = hasPASystem;
            this.hasWheelchairAccess = WCAccess;
        }

        //Getters
        public string GetRoomID() { return this.roomID; }
        public string GetBuildingID() { return this.buildingID; }
        public int GetMaxCapacity() { return this.maxCapacity; }
        public bool HasProjector() { return this.hasProjector; }
        public bool HasPASystem() { return this.hasPASystem; }
        public bool HasWheelchairAccess() { return this.hasWheelchairAccess; }

        //Setters
        public void SetMaxCapacity(int max) { this.maxCapacity = max; }
        public void SetHasProjector(bool val) { this.hasProjector = val; }
        public void SetHasPASystem(bool val) { this.hasPASystem = val; }
        public void SetHasWheelchairAccess(bool val) { this.hasWheelchairAccess = val; }
    }
}
