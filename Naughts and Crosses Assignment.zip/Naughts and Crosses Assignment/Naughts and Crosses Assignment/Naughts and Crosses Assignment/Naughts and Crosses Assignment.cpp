/*
This is a game of Naughts and Crosses against a pseudo-AI. It will ask you to pick a position, and if the position is valid is will plot it
on the board. The AI will go after your marker is plotted. It will first check the board if there are ways it can lose in your next turn 
and go there. If there aren't any it will pick a random position and plot that marker. After the game is either won or draw, it will
ask for a rematch, if you say yes, the game will restart and whomever loses goes first.
*/

#include "pch.h"
#include <iostream>
#include <ctime>
#include <chrono>
#include <thread>
#include <string>

using namespace std;

//------essential variables-------//
const int boardSize = 3; //ceates a constant variable for the size of the board

//----Identifiers for functions----//
void printBoard(char x[][boardSize]);
void printWelcomeMessage(string name);
void switchPlayer(int &x);
void plotMarker(int choicePos, char x[][boardSize], int player);
void printBoard(char x[][boardSize]);
bool checkForWin(int playerToCheck, char board[][boardSize]);
bool checkIfValid(int choicePos, char x[][boardSize]);
void printWinner(int currentPlayer, string playerName);
int createRandomNum();
bool boardIsFull(char x[][3]);
void printDrawMessage();
bool checkForRematch();
int findPreferredPosition(char x[][boardSize]);
//-------end of Identifiers-------//


//-------start of main code-------//
int main()
{
	bool rematch = true; //declares a bool named "rematch" and sets it to true.
	string playerName;
	int currentPlayer = 1; // sets the current player to 1
	do
	{
		cout << "Please Enter Your Name:" << endl;
		getline(cin, playerName); // another way to ask player for an input. Prevents errors when the input has spaces
	} while (playerName == ""); // will keep asking if the string is empty
	do
	{
		bool inPlay = true; //declares a bool named inPlay and sets it to true

		srand(time(NULL)); //used for calling a random number using the system time

		char boardArray[boardSize][boardSize] = { {'1','2','3'},			//initialises the board array
												  {'4','5','6'},
												  {'7','8','9'} };

		cout << endl << endl;
		printWelcomeMessage(playerName); // runs a function
		printBoard(boardArray);	// This function prints the board thats passed into to as a parameter

		while (inPlay == true)
		{   //runs the following whilst the inPlay flag is true
			if (currentPlayer == 1) // if 1 is currently assigned to currentPlayer 
			{
				int x;	// declares a variable
				cout << playerName << "! Input the position you would like you place your marker." << endl;

				cin >> x; // takes a user input and assigns it to the variable
	
				while (checkIfValid(x, boardArray) == false)
				{
					cin.clear();										 // A method to ignore/clear whatever is in the cin stream so
					cin.ignore(numeric_limits<streamsize>::max(), '\n'); // so 'cin' will work later 											 

					cout << endl << "Your input is not valid, please choose another." << endl << endl; //Tells user that their input isn't valid
					cin >> x; //asks again for a user input
				}
				plotMarker(x, boardArray, currentPlayer);    //calls the function that will plot the marker, passing in the user's input, the board array and whoever the current player it
			}
			if (currentPlayer == 2) //checks if currentPlayer is 2
			{
				int x = 0; //declares a local variable named x
				do //runs the loop once first then checks a condition afterwards
				{
					x = findPreferredPosition(boardArray); //uses a function to return a value (more info inside the function's code
					if (x == 0) //checks if the findPreferredPosition function returned a 0
					{
						x = createRandomNum(); // uses a function to set x to a random number between 1 and 9
					}
				} while (checkIfValid(x, boardArray) == false); //loops again if x is an invalid position choice
				
				plotMarker(x, boardArray, currentPlayer); // calls the plotMarker function using x as the position
				
				cout << "It is the AI's turn";
				this_thread::sleep_for(chrono::seconds(1)); // pauses the program for 1 second
				cout << ".";
				this_thread::sleep_for(chrono::seconds(1)); // pauses the program for 1 second
				cout << ".";
				this_thread::sleep_for(chrono::seconds(1)); // pauses the program for 1 second
				cout << "." << endl;
				cout << "They have chosen position " << x << "." << endl;
			}
			printBoard(boardArray);											//runs the print board function for the board

			if ((checkForWin(currentPlayer, boardArray) == true))  //uses the checkForWin function to return if the current player has won
			{
				inPlay = false;												//sets inPlay to false if someone has won
				printWinner(currentPlayer, playerName);									//calls a function that prints a winner message dependant on which player is passed in
			}
			if (boardIsFull(boardArray) == true)							// calls the boardIsFull function to return whether or not the board has no playable positions
			{
				inPlay = false;												//sets in play to false;
				printDrawMessage();											//uses a function to notify the player that is a draw
			}

			if (inPlay == true)												// only switch player if the current player hasn't won
				switchPlayer(currentPlayer);								// calls a function that toggles the current player, passes the current player variable in as a parameter		
		}

		if (checkForRematch() == true) //uses a function that asks the user if they want a rematch
		{
			rematch = true; //sets rematch to true
			switchPlayer(currentPlayer); //switches player dependant on who the current player is
		} else if (checkForRematch() == false) //if this function returns false
			rematch = false; //sets rematch to false
	} while (rematch == true); //loop back to the beginning if rematch is true;
	return(0); //ends the main function
}

void printWelcomeMessage(string name)												
{
	cout << "Hi, " << name << ". Welcome to Naughts and Crosses." << endl << "Created by Carl Tyler." << endl; // prints a welcome message
}

void printBoard(char x[][boardSize])									//a function that simply prints out and formats the board when called
{
	cout << endl;
	for (int rowNum = 0; rowNum < boardSize; rowNum++)					//loop for the rows
	{
		cout << "| ";													//prints the leftmost boundry
		for (int columnNum = 0; columnNum < boardSize; columnNum++)		//loop for the columns
		{
			cout << x[rowNum][columnNum] << " | ";						//prints each position
		}
		cout << endl;
	}
	cout << endl << "________________________________________________" << endl << endl; //prints a line spacer
}

bool checkIfValid(int choicePos, char x[][boardSize])
{
	bool isTaken = false;												// initialise isTaken variable and set it to false
	bool inputValid = true;												// initialise inputValid variable and set it to true

	//------check if there is already a marker there--------//
	switch (choicePos)													//a switch case statement that uses the choicePos to find which element of the array the user has chosen
	{
		case 1: 
			if ((x[0][0] == 'O') || (x[0][0] == 'X'))					// checks if position 2 is a 'O' or 'X'
				isTaken = true;											// sets boolean to true
			break;														// ends switch statement
		case 2: 
			if ((x[0][1] == 'O') || (x[0][1] == 'X'))					// checks if position 2 is a 'O' or 'X'
				isTaken = true;											// sets boolean to true
			break;														// ends switch statement
		case 3: 
			if ((x[0][2] == 'O') || (x[0][2] == 'X'))					// checks if position 3 is a 'O' or 'X'
				isTaken = true;											// sets boolean to true
			break;														// ends switch statement
		case 4: 
			if ((x[1][0] == 'O') || (x[1][0] == 'X'))					// checks if position 4 is a 'O' or 'X'
				isTaken = true;											// sets boolean to true
			break;														// ends switch statement
		case 5: 
			if ((x[1][1] == 'O') || (x[1][1] == 'X'))					// checks if position 5 is a 'O' or 'X'
				isTaken = true;											// sets boolean to true
			break;														// ends switch statement
		case 6: 
			if ((x[1][2] == 'O') || (x[1][2] == 'X'))					// checks if position 6 is a 'O' or 'X'
				isTaken = true;											// sets boolean to true
			break;														// ends switch statement
		case 7: 
			if ((x[2][0] == 'O') || (x[2][0] == 'X'))					// checks if position 7 is a 'O' or 'X'
				isTaken = true;											// sets boolean to true
			break;														// ends switch statement
		case 8: 
			if ((x[2][1] == 'O') || (x[2][1] == 'X'))					// checks if position 8 is a 'O' or 'X'
				isTaken = true;											// sets boolean to true
			break;														// ends switch statement
		case 9: 
			if ((x[2][2] == 'O') || (x[2][2] == 'X')) 					// checks if position 9 is a 'O' or 'X'
				isTaken = true;											// sets boolean to true
			break;														// ends switch statement
	}

	//--------Check if input is in a valid range---------//
	if ((choicePos <= 9) && (choicePos >= 1))							// if the users choice is between 1 and 9 inclusive
		inputValid = true;												// sets inputValid to true
	else 
		inputValid = false;												// otherwise set inputValid to false

	if (isTaken == false && inputValid == true)							// if isTaken is false and inputValid is true
		return true;													// end function and return true
	else																// otherwise...
		return false;													// end function and return false
}

void switchPlayer(int &x)												//toggles player.
{
	if (x == 1)															//if x is equal to 1
		x = 2;															//set x to 2
	else if (x == 2)													//otherwise if its equal to 2
		x = 1;															// sets x to 1
}

void plotMarker(int choicePos, char x[][boardSize], int player)			//takes user input, board and which player
{
	char marker;														//defines a char variable named marker
	if (player == 1)													//if current player is 1...
		marker = 'O';													//set marker to 'O'
	else if (player == 2)												//otherwise if current player is 2...
		marker = 'X';													//set marker to 'X'
		
	switch (choicePos)													//a switch case statement that uses the choicePos variable to choose the corresponding position
	{
		case 1: x[0][0] = marker; break;								//if choicePos is 1, change the corresponding char in the array to whatever marker was set to
		case 2: x[0][1] = marker; break;								//if choicePos is 2, change the corresponding char in the array to whatever marker was set to
		case 3: x[0][2] = marker; break;								//if choicePos is 3, change the corresponding char in the array to whatever marker was set to
		case 4: x[1][0] = marker; break;								//if choicePos is 4, change the corresponding char in the array to whatever marker was set to
		case 5: x[1][1] = marker; break;								//if choicePos is 5, change the corresponding char in the array to whatever marker was set to
		case 6: x[1][2] = marker; break;								//if choicePos is 6, change the corresponding char in the array to whatever marker was set to
		case 7: x[2][0] = marker; break;								//if choicePos is 7, change the corresponding char in the array to whatever marker was set to
		case 8: x[2][1] = marker; break;								//if choicePos is 8, change the corresponding char in the array to whatever marker was set to
		case 9: x[2][2] = marker; break;								//if choicePos is 9, change the corresponding char in the array to whatever marker was set to
	}
}

bool checkForWin(int playerToCheck, char board[][boardSize]) //this function checks if a player has won and return 1 or 2 respectively
{
	char marker;
	bool combinationFound = false;
	if (playerToCheck == 1)      // if the player number thats passed into the function is 1
		marker = 'O';            // set the marker to 'O'
	else if (playerToCheck == 2) // otherwise if the player thats passed into the function is 2
		marker = 'X';            // set the marker to 'X'

		//The following if statemets checks all the winning combinations and returns true if any of them pass
		//verticle checks
		if (board[0][0] == marker && board[1][0] == marker && board[2][0] == marker)
			combinationFound = true; // Sets the local bool to true
		if (board[0][1] == marker && board[1][1] == marker && board[2][1] == marker)
			combinationFound = true; // Sets the local bool to true
		if (board[0][2] == marker && board[1][2] == marker && board[2][2] == marker)
			combinationFound = true; // Sets the local bool to true

		//horizontal checks
		if (board[0][0] == marker && board[0][1] == marker && board[0][2] == marker)
			combinationFound = true; // Sets the local bool to true
		if (board[1][0] == marker && board[1][1] == marker && board[1][2] == marker)
			combinationFound = true; // Sets the local bool to true
		if (board[2][0] == marker && board[2][1] == marker && board[2][2] == marker)
			combinationFound = true; // Sets the local bool to true

		//diagonal checks
		if (board[0][0] == marker && board[1][1] == marker && board[2][2] == marker)
			combinationFound = true; // Sets the local bool to true
		if (board[2][0] == marker && board[1][1] == marker && board[0][2] == marker)
			combinationFound = true; // Sets the local bool to true

		return combinationFound;
}

bool boardIsFull(char x[][3]) //checks if the board is full
{
	int markerCounter = 0; //initialises a counter variable and sets it to 0
	for (int rowNum = 0; rowNum < boardSize; rowNum++) //loop for the rows
	{		
		for (int columnNum = 0; columnNum < boardSize; columnNum++) //loop for the columns
		{
			if ((x[rowNum][columnNum] == 'X') || (x[rowNum][columnNum] == 'O')) //checks if there is an 'X' or a 'O' in the array position
			{
				markerCounter = markerCounter + 1; //add 1 to the counter
			}
		}
	}
	if (markerCounter == 9) //if the counter is 9...
		return true; //returns true back to where the function was called
	else //otherwise
		return false; //return false
}

void printWinner(int currentPlayer, string playerName) //recieves whoever has won
{
	if (currentPlayer == 1)
		cout << endl << "Congratulations, " << playerName << ". You have won!" << endl << endl; //prints a winner message before closing
	else  if (currentPlayer == 2)
		cout << endl << "Bad luck, " << playerName << ". You have lost! :(" << endl << endl; //prints a winner message before closing
}

void printDrawMessage()
{
	cout << endl << "The game is a Draw"; //prints a message saying a draw has occurred
}

bool checkForRematch()
{
	char x; // initialises a char variable named x
	do //starts a do-while loop
	{
		cout << endl << "Would you like a rematch? Type 'Y' for Yes or 'N' for No." << endl; // prints a string
		cin >> x; // puts a user input into x
		x = toupper(x); //sets whatever is in x to its uppercase version
	} while ((x !='Y') && (x !='N')); //keep looping while x isnt a Y or an N

		if (x == 'Y') //if the user's input is a Y
			return true; //returns true back to where the function was called
		else if (x =='N') //otherise check if its an N
			return false; //returns false back to where the function was called
}

//----------------AI functions---------------//
int createRandomNum() //generates a random number and returns it where the function is called
{
	int num = (rand() % 9); //gets a random number, divides it by 9, gets the remainder and puts it in the 'num' variable
	return num; //returns whatever value the num variable has
}

int findPreferredPosition(char x[][boardSize]) // Checks combinations on the board to finds the AI's preferred position.
{
	int position = 0; // Initialise a local integer variable named position and sets it to 0
	//Set the two variables below pre-emptively just in case I want to add marker choice in the future
	char opponentMarker = 'O'; //sets the opponentMarker to the 'O' char
	char AImarker = 'X'; // sets the AI's marker to the 'X' char.

	// The section below uses if statements to check the player's potentially-winning combinations, and also makes sure
	// that the space that blocks the combination is not already take by the AI (this prevents the AI continously seeing 
	// already blocked combinations even after it's been blocked).

	//Horizontal top line
	if ((x[0][1] == opponentMarker) && (x[0][2] == opponentMarker) && (x[0][0] != AImarker))
		position = 1; //sets the position variable to 1
	else if ((x[0][0] == opponentMarker) && (x[0][2] == opponentMarker) && (x[0][1] != AImarker))
		position = 2; //sets the position variable to 2
	else if ((x[0][0] == opponentMarker) && (x[0][1] == opponentMarker) && (x[0][2] != AImarker))
		position = 3; //sets the position variable to 3
	//Horizontal middle line
	if ((x[1][1] == opponentMarker) && (x[1][2] == opponentMarker) && (x[1][0] != AImarker))
		position = 4; //sets the position variable to 4
	else if ((x[1][0] == opponentMarker) && (x[1][2] == opponentMarker) && (x[1][1] != AImarker))
		position = 5; //sets the position variable to 5
	else if ((x[1][0] == opponentMarker) && (x[1][1] == opponentMarker) && (x[1][2] != AImarker))
		position = 6; //sets the position variable to 6
	//Horizontal bottom line
	if ((x[2][1] == opponentMarker) && (x[2][2] == opponentMarker) && (x[2][0] != AImarker))
		position = 7; //sets the position variable to 7
	else if ((x[2][0] == opponentMarker) && (x[2][2] == opponentMarker) && (x[2][1] != AImarker))
		position = 8; //sets the position variable to 8
	else if ((x[2][0] == opponentMarker) && (x[2][1] == opponentMarker) && (x[2][2] != AImarker))
		position = 9; //sets the position variable to 9
	//Verticle left line
	if ((x[1][0] == opponentMarker) && (x[2][0] == opponentMarker) && (x[0][0] != AImarker))
		position = 1; //sets the position variable to 1
	else if ((x[0][0] == opponentMarker) && (x[2][0] == opponentMarker) && (x[1][0] != AImarker))
		position = 4; //sets the position variable to 4
	else if ((x[0][0] == opponentMarker) && (x[1][0] == opponentMarker) && (x[2][0] != AImarker))
		position = 7; //sets the position variable to 7
	//Verticle middle line
	if ((x[1][1] == opponentMarker) && (x[2][1] == opponentMarker) && (x[0][1] != AImarker))
		position = 2; //sets the position variable to 2
	else if ((x[0][1] == opponentMarker) && (x[2][1] == opponentMarker) && (x[1][1] != AImarker))
		position = 5; //sets the position variable to 5
	else if ((x[0][1] == opponentMarker) && (x[1][1] == opponentMarker) && (x[2][1] != AImarker))
		position = 8; //sets the position variable to 8
	//Verticle Right Line
	if ((x[1][2] == opponentMarker) && (x[2][2] == opponentMarker) && (x[0][2] != AImarker))
		position = 3; //sets the position variable to 3
	else if ((x[0][2] == opponentMarker) && (x[2][2] == opponentMarker) && (x[1][2] != AImarker))
		position = 6; //sets the position variable to 6
	else if ((x[0][2] == opponentMarker) && (x[1][2] == opponentMarker) && (x[2][2] != AImarker))
		position = 9; //sets the position variable to 9
	//Diagonals
	if ((x[1][1] == opponentMarker) && (x[2][2] == opponentMarker) && (x[0][0] != AImarker))
		position = 1; //sets the position variable to 1
	else if ((x[0][0] == opponentMarker) && (x[2][2] == opponentMarker) && (x[1][1] != AImarker))
		position = 5; //sets the position variable to 5 
	else if ((x[0][0] == opponentMarker) && (x[1][1] == opponentMarker) && (x[2][2] != AImarker))
		position = 9; //sets the position variable to 9
	if ((x[2][0] == opponentMarker) && (x[1][1] == opponentMarker) && (x[0][2] != AImarker))
		position = 3; //sets the position variable to 3
	else if ((x[2][0] == opponentMarker) && (x[0][2] == opponentMarker) && (x[1][1] != AImarker))
		position = 5; //sets the position variable to 5
	else if ((x[1][1] == opponentMarker) && (x[0][2] == opponentMarker) && (x[2][0] != AImarker))
		position = 7; //sets the position variable to 7

	// This next section will check the AI's potential winning combinations and if it can plot a valid marker
	// on the winning position that will win. This comes AFTER the other checks so it will always choose a 
	// winning position over a blocking position.

	if ((x[0][1] == AImarker) && (x[0][2] == AImarker) && (x[0][0] != opponentMarker))
		position = 1; //sets the position variable to 1
	else if ((x[0][0] == AImarker) && (x[0][2] == AImarker) && (x[0][1] != opponentMarker))
		position = 2; //sets the position variable to 2
	else if ((x[0][0] == AImarker) && (x[0][1] == AImarker) && (x[0][2] != opponentMarker))
		position = 3; //sets the position variable to 3
	//Horizontal middle line
	if ((x[1][1] == AImarker) && (x[1][2] == AImarker) && (x[1][0] != opponentMarker))
		position = 4; //sets the position variable to 4
	else if ((x[1][0] == AImarker) && (x[1][2] == AImarker) && (x[1][1] != opponentMarker))
		position = 5; //sets the position variable to 5
	else if ((x[1][0] == AImarker) && (x[1][1] == AImarker) && (x[1][2] != opponentMarker))
		position = 6; //sets the position variable to 6
	//Horizontal bottom line
	if ((x[2][1] == AImarker) && (x[2][2] == AImarker) && (x[2][0] != opponentMarker))
		position = 7; //sets the position variable to 7
	else if ((x[2][0] == AImarker) && (x[2][2] == AImarker) && (x[2][1] != opponentMarker))
		position = 8; //sets the position variable to 8
	else if ((x[2][0] == AImarker) && (x[2][1] == AImarker) && (x[2][2] != opponentMarker))
		position = 9; //sets the position variable to 9
	//Verticle left line
	if ((x[1][0] == AImarker) && (x[2][0] == AImarker) && (x[0][0] != opponentMarker))
		position = 1; //sets the position variable to 1
	else if ((x[0][0] == AImarker) && (x[2][0] == AImarker) && (x[1][0] != opponentMarker))
		position = 4; //sets the position variable to 4
	else if ((x[0][0] == AImarker) && (x[1][0] == AImarker) && (x[2][0] != opponentMarker))
		position = 7; //sets the position variable to 7
	//Verticle middle line
	if ((x[1][1] == AImarker) && (x[2][1] == AImarker) && (x[0][1] != opponentMarker))
		position = 2; //sets the position variable to 2
	else if ((x[0][1] == AImarker) && (x[2][1] == AImarker) && (x[1][1] != opponentMarker))
		position = 5; //sets the position variable to 5
	else if ((x[0][1] == AImarker) && (x[1][1] == AImarker) && (x[2][1] != opponentMarker))
		position = 8; //sets the position variable to 8
	//Verticle Right Line
	if ((x[1][2] == AImarker) && (x[2][2] == AImarker) && (x[0][2] != opponentMarker))
		position = 3; //sets the position variable to 3
	else if ((x[0][2] == AImarker) && (x[2][2] == AImarker) && (x[1][2] != opponentMarker))
		position = 6; //sets the position variable to 6
	else if ((x[0][2] == AImarker) && (x[1][2] == AImarker) && (x[2][2] != opponentMarker))
		position = 9; //sets the position variable to 9
	//Diagonals
	if ((x[1][1] == AImarker) && (x[2][2] == AImarker) && (x[0][0] != opponentMarker))
		position = 1; //sets the position variable to 1
	else if ((x[0][0] == AImarker) && (x[2][2] == AImarker) && (x[1][1] != opponentMarker))
		position = 5; //sets the position variable to 5 
	else if ((x[0][0] == AImarker) && (x[1][1] == AImarker) && (x[2][2] != opponentMarker))
		position = 9; //sets the position variable to 9
	if ((x[2][0] == AImarker) && (x[1][1] == AImarker) && (x[0][2] != opponentMarker))
		position = 3; //sets the position variable to 3
	else if ((x[2][0] == AImarker) && (x[0][2] == AImarker) && (x[1][1] != opponentMarker))
		position = 5; //sets the position variable to 5
	else if ((x[1][1] == AImarker) && (x[0][2] == AImarker) && (x[2][0] != opponentMarker))
		position = 7; //sets the position variable to 7

	if (position >= 1 && position <= 9) //if the position variable is between 1 and 9 (inclusive)...
	{
		return position; //return whatever position was set to.
	}
	else //otherwise...
	{
		return 0; //returns 0 back to where the function was called
	}
}

