﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Monopoly_Assessment
{
    public partial class Form1 : Form
    {
        int player1money = 0;
        int player2money = 0;
        int player3money = 0;
        int player4money = 0;

        int dice1value;
        int dice2value;
        int dicetotalvalue;

        int player1position;
        int player2position;
        int player3position;
        int player4position;

        int totalplayercount = 0;

        int currentplayer;

        bool player1IsInJail = false;
        bool player2IsInJail = false;
        bool player3IsInJail = false;
        bool player4IsInJail = false;

        int player1JailCounter = 0;
        int player2JailCounter = 0;
        int player3JailCounter = 0;
        int player4JailCounter = 0;

        bool player1HasGetOutOfJailCard = false;
        bool player2HasGetOutOfJailCard = false;
        bool player3HasGetOutOfJailCard = false;
        bool player4HasGetOutOfJailCard = false;

        string player1alias = "Player 1";
        string player2alias = "Player 2";
        string player3alias = "Player 3";
        string player4alias = "Player 4";

        int randomChance = 0;
        int randomCommunityChest = 0;

        int oldKentRoadOwnedBy;
        int whiteChapelRoadOwnedBy;
        int theAngelIslingtonOwnedBy;
        int eustonRoadOwnedBy;
        int pentonvilleRoadOwnedBy;
        int pallMallOwnedBy;
        int whitehallOwnedBy;
        int northumberlandAvenueOwnedBy;
        int bowStreetOwnedBy;
        int marlboroughStreetOwnedBy;
        int vineStreetOwnedBy;
        int strandOwnedBy;
        int fleetStreetOwnedBy;
        int trafalgarSquareOwnedBy;
        int leicesterSquareOwnedBy;
        int coventryStreetOwnedBy;
        int piccadillyOwnedBy;
        int regentStreetOwnedBy;
        int oxfordStreetOwnedBy;
        int bondStreetOwnedBy;
        int parkLaneOwnedBy;
        int mayfairOwnedBy;

        int oldKentRoadHouses;
        int whiteChapelRoadHouses;
        int theAngelIslingtonHouses;
        int eustonRoadHouses;
        int pentonvilleRoadHouses;
        int pallMallHouses;
        int whitehallHouses;
        int northumberlandAvenueHouses;
        int bowStreetHouses;
        int marlboroughStreetHouses;
        int vineStreetHouses;
        int strandHouses;
        int fleetStreetHouses;
        int trafalgarSquareHouses;
        int leicesterSquareHouses;
        int coventryStreetHouses;
        int piccadillyHouses;
        int regentStreetHouses;
        int oxfordStreetHouses;
        int bondStreetHouses;
        int parkLaneHouses;
        int mayfairHouses;

        int waterWorksOwnedBy = 0;
        int electricCompanyOwnedBy = 0;

        int kingsCrossStationOwnedBy = 0;
        const int kingsCrossStationPrice = 200;
        int maryleboneStationOwnedBy = 0;
        const int maryleboneStationPrice = 200;
        int fenchurchStStationOwnedBy = 0;
        const int fenchurchStStationPrice = 200;
        int liverpoolStStationOwnedBy = 0;
        const int liverpoolStStationPrice = 200;

        int player1StationCount = 0;
        int player2StationCount = 0;
        int player3StationCount = 0;
        int player4StationCount = 0;

        int player1UtilityCount = 0;
        int player2UtilityCount = 0;
        int player3UtilityCount = 0;
        int player4UtilityCount = 0;

        bool player1IsActive = false;
        bool player2IsActive = false;
        bool player3IsActive = false;
        bool player4IsActive = false;


        public Form1()
        {
            InitializeComponent();
            InitialiseProperties();
            RefreshMoneyUI();
            ResetAllPlayerPosition();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        public void RefreshMoneyUI()
        {
            lbl_player1money.Text = player1alias + ": £" + player1money.ToString();
            lbl_player2money.Text = player2alias + ": £" + player2money.ToString();
            lbl_player3money.Text = player3alias + ": £" + player3money.ToString();
            lbl_player4money.Text = player4alias + ": £" + player4money.ToString();
        }

        public void ResetAllPlayerPosition()
        {
            character_player1.Left = 927;
            character_player1.Top = 913;
            character_player2.Left = 955;
            character_player2.Top = 913;
            character_player3.Left = 927;
            character_player3.Top = 942;
            character_player4.Left = 955;
            character_player4.Top = 943;
        }

        public void InitialisePlayer1()
        {
            character_player1.Visible = true; // show player marker
            character_player1.Left = 927; // sets player left to start square
            character_player1.Top = 913; // sets player top to start square
            lbl_player1money.Visible = true; //show money label
            listbox_p1properties.Visible = true;
            player1money = 1500; // sets money value to 1500
            RefreshMoneyUI(); // calls the function that refreshes the money labels
            player1position = 0; //sets player position to the GO tile
            totalplayercount++; //increases total player count by 1
            player1IsActive = true;
        }
        public void InitialisePlayer2()
        {
            character_player2.Visible = true;
            character_player2.Left = 955;
            character_player2.Top = 913;
            lbl_player2money.Visible = true; //show money label
            listbox_p2properties.Visible = true;
            player2money = 1500; // sets money value to 1500
            RefreshMoneyUI(); // calls the function that refreshes the money labels
            player2position = 0; //sets player position to the GO tile
            totalplayercount++; //increases total player count by 1
            player2IsActive = true;
        }
        public void InitialisePlayer3()
        {
            character_player3.Visible = true;
            character_player3.Left = 927;
            character_player3.Top = 942;
            lbl_player3money.Visible = true; //show money label
            listbox_p3properties.Visible = true;
            player3money = 1500; // sets money value to 1500
            RefreshMoneyUI(); // calls the function that refreshes the money labels
            player3position = 0; //sets player position to the GO tile
            totalplayercount++; //increases total player count by 1
            player3IsActive = true;
        }
        public void InitialisePlayer4()
        {
            character_player4.Visible = true;
            character_player4.Left = 955;
            character_player4.Top = 943;
            lbl_player4money.Visible = true; //show money label
            player4money = 1500; // sets money value to 1500
            listbox_p4properties.Visible = true;
            RefreshMoneyUI(); // calls the function that refreshes the money labels
            player4position = 0; //sets player position to the GO tile
            totalplayercount++; //increases total player count by 1
            player4IsActive = true;
        }

        public void ThrowDice()
        {
            int rollNumber;
            Random rnd = new Random();
            for (rollNumber = 1; rollNumber < 105; rollNumber++) //loops 105 times
            {
                dice1value = rnd.Next(1, 7); // assigns variable a random number between 1 and 6
                dice2value = rnd.Next(1, 7); // assigns variable a random number between 1 and 6
            }

            RefreshDiceImages();
            dicetotalvalue = dice1value + dice2value;
        }

        private void RefreshDiceImages()
        {
        }

        private void btn_throwdice_Click(object sender, EventArgs e)
        {
            ThrowDice();
            btn_throwdice.Visible = false;

            lbl_dice1.Text = "Dice 1: " + dice1value.ToString(); //updates dice value to its corresponding label
            lbl_dice2.Text = "Dice 2: " + dice2value.ToString();

            MovePlayers(); //calls the MovePlayers function

        }

        private void btn_startgame_Click(object sender, EventArgs e)
        {
            btn_startgame.Visible = false;
            btn_ok_players.Visible = true;

            radiobtn_2players.Visible = true;
            radiobtn_3players.Visible = true;
            radiobtn_4players.Visible = true;
        }

        private void radiobtn_2players_CheckedChanged(object sender, EventArgs e)
        {
            radiobtn_3players.Checked = false;
            radiobtn_4players.Checked = false;
        }

        private void radiobtn_3players_CheckedChanged(object sender, EventArgs e)
        {
            radiobtn_2players.Checked = false;
            radiobtn_4players.Checked = false;
        }

        private void radiobtn_4players_CheckedChanged(object sender, EventArgs e)
        {
            radiobtn_2players.Checked = false;
            radiobtn_3players.Checked = false;
        }

        private void btn_ok_players_Click(object sender, EventArgs e)
        {
            if (radiobtn_2players.Checked == true)
            {
                InitialisePlayer1();
                InitialisePlayer2();
                RefreshMoneyUI();

                lbl_debug_totalplayers.Text = totalplayercount.ToString();
            }
            else if (radiobtn_3players.Checked == true)
            {
                InitialisePlayer1();
                InitialisePlayer2();
                InitialisePlayer3();
                RefreshMoneyUI();

                lbl_debug_totalplayers.Text = totalplayercount.ToString();
            }
            else if (radiobtn_4players.Checked == true)
            {
                InitialisePlayer1();
                InitialisePlayer2();
                InitialisePlayer3();
                InitialisePlayer4();
                RefreshMoneyUI();
                lbl_debug_totalplayers.Text = totalplayercount.ToString();
            }

            radiobtn_2players.Visible = false;
            radiobtn_3players.Visible = false;
            radiobtn_4players.Visible = false;
            btn_ok_players.Visible = false;

            SetPlayer1InPlay();
        }

        public void SetPlayer1InPlay()
        {
            currentplayer = 1; //sets current player to 1
            lbl_playerturn.Visible = true; //ensures the player turn label is visible
            lbl_playerturn.Text = player1alias + "'s Turn"; //assigns the text of the label to indicate who's turn it is
            lbl_dice1.Visible = true; //ensures dice 1's label is visible
            lbl_dice2.Visible = true; // ensures dice 2's label is visible
            btn_throwdice.Visible = true; // makes the throw dice button visible
            label1.Text = currentplayer.ToString(); //inidicates which the current player is in the debug label
        }

        public void SetPlayer2InPlay()
        {
            currentplayer = 2;
            lbl_playerturn.Visible = true;
            lbl_playerturn.Text = player2alias + "'s Turn";
            lbl_dice1.Visible = true;
            lbl_dice2.Visible = true;
            btn_throwdice.Visible = true;
            label1.Text = currentplayer.ToString();

        }

        public void SetPlayer3InPlay()
        {
            currentplayer = 3;
            lbl_playerturn.Visible = true;
            lbl_playerturn.Text = player3alias + "'s Turn";
            lbl_dice1.Visible = true;
            lbl_dice2.Visible = true;
            btn_throwdice.Visible = true;
            label1.Text = currentplayer.ToString();
        }

        public void SetPlayer4InPlay()
        {
            currentplayer = 4;
            lbl_playerturn.Visible = true;
            lbl_playerturn.Text = player4alias + "'s Turn";
            lbl_dice1.Visible = true;
            lbl_dice2.Visible = true;
            btn_throwdice.Visible = true;
            label1.Text = currentplayer.ToString();
        }

        public void MovePlayers() //alters the position variable of the current player and then runs checks to see what square theyve landed on
        {
            if (currentplayer == 1 && player1IsInJail == false)  // checks if current player is player 1 and are not in jail
            {
                player1position = player1position + dicetotalvalue; // adds the die's total value to the current player's position
                lbl_debug_p1_position.Text = "Player 1 Pos: " + player1position; // updates the debug label

                if (player1position >= 40) // checks if player 1's position is greater than or equal to 40
                {
                    player1position = player1position - 40; // brings the players position back down to the corresponding tile
                    player1money = player1money + 200; //gives the player money
                    MessageBox.Show(player1alias + " has collected £200");

                    lbl_debug_p1_position.Text = "Player 1 Pos: " + player1position; // updates the debug label
                }
            }
            else if (currentplayer == 1 && player1IsInJail == true)
            {
                player1JailCounter = player1JailCounter - 1;
                debug_p1prisoncounter.Text = ("Player 1 has " + player1JailCounter + " more turns left to leave jail");

                if (player1JailCounter > 0)
                {
                    if (dice1value == dice2value)
                    {
                        p1LeaveJail();
                    }
                }
                else if (player1JailCounter <= 0)
                {
                    p1LeaveJail();
                }
            }

            if (currentplayer == 2 && player1IsInJail == false)
            {
                player2position = player2position + dicetotalvalue;
                lbl_debug_p2_position.Text = "Player 2 Pos: " + player2position;

                if (player2position >= 40)
                {
                    player2position = player2position - 40;
                    player2money = player2money + 200;
                    MessageBox.Show(player2alias + " has collected £200");

                    lbl_debug_p1_position.Text = "Player 2 Pos: " + player2position;
                }
            }
            else if (currentplayer == 2 && player2IsInJail == true)
            {
                player2JailCounter = player2JailCounter - 1;
                debug_p2prisoncounter.Text = ("Player 2 has " + player2JailCounter + " more turns left to leave jail");

                if (player2JailCounter > 0)
                {
                    if (dice1value == dice2value)
                    {
                        p2LeaveJail();
                    }
                }
                else if (player2JailCounter <= 0)
                {
                    p2LeaveJail();
                }
            }



            if (currentplayer == 3 && player3IsInJail == false)
            {
                player3position = player3position + dicetotalvalue;
                lbl_debug_p3_position.Text = "Player 3 Pos: " + player3position;

                if (player3position >= 40)
                {
                    player3position = player3position - 40;
                    player3money = player3money + 200;
                    MessageBox.Show(player3alias + " has collected £200");

                    lbl_debug_p3_position.Text = "Player 3 Pos: " + player3position;
                }
            }
            else if (currentplayer == 3 && player3IsInJail == true)
            {
                player3JailCounter = player3JailCounter - 1;
                debug_p3_prisoncounter.Text = ("Player 3 has " + player3JailCounter + " more turns left to leave jail");

                if (player3JailCounter > 0)
                {
                    if (dice1value == dice2value)
                    {
                        p3LeaveJail();
                    }
                }
                else if (player3JailCounter <= 0)
                {
                    p3LeaveJail();
                }
            }


            if (currentplayer == 4 && player4IsInJail == false)
            {
                player4position = player4position + dicetotalvalue;
                lbl_debug_p4_position.Text = "Player 4 Pos: " + player4position;

                if (player4position >= 40)
                {
                    player4position = player4position - 40;
                    player4money = player4money + 200;
                    MessageBox.Show(player4alias + " has collected £200");

                    lbl_debug_p4_position.Text = "Player 4 Pos: " + player4position;
                }
            }
            else if (currentplayer == 4 && player4IsInJail == true)
            {
                player4JailCounter = player4JailCounter - 1;
                debug_p4_prisoncounter.Text = ("Player 4 has " + player4JailCounter + " more turns left to leave jail");

                if (player4JailCounter > 0)
                {
                    if (dice1value == dice2value)
                    {
                        p4LeaveJail();
                    }
                }
                else if (player4JailCounter <= 0)
                {
                    p4LeaveJail();
                }
            }




            RedrawPlayerPositions();
            CheckUtility();
            CheckTrainStation();
            CheckProperty();
            CheckChance();
            CheckCommunityChest();
            GoToJail();
            RefreshMoneyUI();
            CheckBankruptcy();
            NextPlayer();
        }

        public void NextPlayer() //sets the current player to the next available player
        {
            if (currentplayer == 1)
            {
                if (player2IsActive == true)
                {
                    SetPlayer2InPlay();
                }
                else if (player3IsActive == true)
                {
                    SetPlayer3InPlay();
                }
                else if (player4IsActive == true)
                {
                    SetPlayer4InPlay();
                }
                else
                {
                    MessageBox.Show("Player 1 Wins");
                }
            }

            else if (currentplayer == 2)
            {
                if (player3IsActive == true)
                {
                    SetPlayer3InPlay();
                }
                else if (player4IsActive == true)
                {
                    SetPlayer4InPlay();
                }
                else if (player1IsActive == true)
                {
                    SetPlayer1InPlay();
                }
                else
                {
                    MessageBox.Show("Player 2 Wins");
                }
            }
            else if (currentplayer == 3)
            {
                if (player4IsActive == true)
                {
                    SetPlayer4InPlay();
                }
                else if (player1IsActive == true)
                {
                    SetPlayer1InPlay();
                }
                else if (player2IsActive == true)
                {
                    SetPlayer2InPlay();
                }
                else
                {
                    MessageBox.Show("Player 3 Wins");
                }
            }
            else if (currentplayer == 4)
            {
                if (player1IsActive == true)
                {
                    SetPlayer1InPlay();
                }
                else if (player2IsActive == true)
                {
                    SetPlayer2InPlay();
                }
                else if (player3IsActive == true)
                {
                    SetPlayer3InPlay();
                }
                else
                {
                    MessageBox.Show("Player 4 Wins");
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            NextPlayer();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        public void RedrawPlayerPositions() //Checks each player's position variable and move the player's counter to the correct position
        {
            //Redraw Player 1
            if (player1position == 0)
            {
                character_player1.Left = 927;
                character_player1.Top = 913;
            } 
            else if (player1position == 1)
            {
                character_player1.Left = 817;
                character_player1.Top = 940;
            }
            else if (player1position == 2)
            {
                character_player1.Left = 734;
                character_player1.Top = 940;
            }
            else if (player1position == 3)
            {
                character_player1.Left = 651;
                character_player1.Top = 940;
            }
            else if (player1position == 4)
            {
                character_player1.Left = 568;
                character_player1.Top = 940;
            }
            else if (player1position == 5)
            {
                character_player1.Left = 485;
                character_player1.Top = 940;
            }
            else if (player1position == 6)
            {
                character_player1.Left = 402;
                character_player1.Top = 940;
            }
            else if (player1position == 7)
            {
                character_player1.Left = 319;
                character_player1.Top = 940;
            }
            else if (player1position == 8)
            {
                character_player1.Left = 236;
                character_player1.Top = 940;
            }
            else if (player1position == 9)
            {
                character_player1.Left = 153;
                character_player1.Top = 940;
            }
            else if (player1position == 10)
            {
                character_player1.Left = 7;
                character_player1.Top = 902;
            }
            else if (player1position == 11)
            {
                character_player1.Left = 24;
                character_player1.Top = 818;
            }
            else if (player1position == 12)
            {
                character_player1.Left = 24;
                character_player1.Top = 735;
            }
            else if (player1position == 13)
            {
                character_player1.Left = 24;
                character_player1.Top = 652;
            }
            else if (player1position == 14)
            {
                character_player1.Left = 24;
                character_player1.Top = 569;
            }
            else if (player1position == 15)
            {
                character_player1.Left = 24;
                character_player1.Top = 486;
            }
            else if (player1position == 16)
            {
                character_player1.Left = 24;
                character_player1.Top = 403;
            }
            else if (player1position == 17)
            {
                character_player1.Left = 24;
                character_player1.Top = 320;
            }
            else if (player1position == 18)
            {
                character_player1.Left = 24;
                character_player1.Top = 237;
            }
            else if (player1position == 19)
            {
                character_player1.Left = 24;
                character_player1.Top = 154;
            }
            else if (player1position == 20)
            {
                character_player1.Left = 39;
                character_player1.Top = 36;
            }
            else if (player1position == 21)
            {
                character_player1.Left = 150;
                character_player1.Top = 19;
            }
            else if (player1position == 22)
            {
                character_player1.Left = 233;
                character_player1.Top = 19;
            }
            else if (player1position == 23)
            {
                character_player1.Left = 316;
                character_player1.Top = 19;
            }
            else if (player1position == 24)
            {
                character_player1.Left = 399;
                character_player1.Top = 19;
            }
            else if (player1position == 25)
            {
                character_player1.Left = 482;
                character_player1.Top = 19;
            }
            else if (player1position == 26)
            {
                character_player1.Left = 565;
                character_player1.Top = 19;
            }
            else if (player1position == 27)
            {
                character_player1.Left = 648;
                character_player1.Top = 19;
            }
            else if (player1position == 28)
            {
                character_player1.Left = 731;
                character_player1.Top = 19;
            }
            else if (player1position == 29)
            {
                character_player1.Left = 814;
                character_player1.Top = 19;
            }
            else if (player1position == 30)
            {
                character_player1.Left = 925;
                character_player1.Top = 35;
            }
            else if (player1position == 31)
            {
                character_player1.Left = 942;
                character_player1.Top = 146;
            }
            else if (player1position == 32)
            {
                character_player1.Left = 942;
                character_player1.Top = 229;
            }
            else if (player1position == 33)
            {
                character_player1.Left = 942;
                character_player1.Top = 312;
            }
            else if (player1position == 34)
            {
                character_player1.Left = 942;
                character_player1.Top = 395;
            }
            else if (player1position == 35)
            {
                character_player1.Left = 942;
                character_player1.Top = 478;
            }
            else if (player1position == 36)
            {
                character_player1.Left = 942;
                character_player1.Top = 561;
            }
            else if (player1position == 37)
            {
                character_player1.Left = 942;
                character_player1.Top = 644;
            }
            else if (player1position == 38)
            {
                character_player1.Left = 942;
                character_player1.Top = 727;
            }
            else if (player1position == 39)
            {
                character_player1.Left = 942;
                character_player1.Top = 810;
            }

            //Redraw Player 2
            if (player2position == 0)
            {
                character_player2.Left = 955;
                character_player2.Top = 913;
            }
            else if (player2position == 1)
            {
                character_player2.Left = 817 + 28;
                character_player2.Top = 940;
            }
            else if (player2position == 2)
            {
                character_player2.Left = 734 + 28;
                character_player2.Top = 940;
            }
            else if (player2position == 3)
            {
                character_player2.Left = 651 + 28;
                character_player2.Top = 940;
            }
            else if (player2position == 4)
            {
                character_player2.Left = 568 + 28;
                character_player2.Top = 940;
            }
            else if (player2position == 5)
            {
                character_player2.Left = 485 + 28;
                character_player2.Top = 940;
            }
            else if (player2position == 6)
            {
                character_player2.Left = 402 + 28;
                character_player2.Top = 940;
            }
            else if (player2position == 7)
            {
                character_player2.Left = 319 + 28;
                character_player2.Top = 940;
            }
            else if (player2position == 8)
            {
                character_player2.Left = 236 + 28;
                character_player2.Top = 940;
            }
            else if (player2position == 9)
            {
                character_player2.Left = 153 + 28;
                character_player2.Top = 940;
            }
            else if (player2position == 10)
            {
                character_player2.Left = 7;
                character_player2.Top = 951;
            }
            else if (player2position == 11)
            {
                character_player2.Left = 24 + 28;
                character_player2.Top = 818;
            }
            else if (player2position == 12)
            {
                character_player2.Left = 24 + 28;
                character_player2.Top = 735;
            }
            else if (player2position == 13)
            {
                character_player2.Left = 24 + 28;
                character_player2.Top = 652;
            }
            else if (player2position == 14)
            {
                character_player2.Left = 24 + 28;
                character_player2.Top = 569;
            }
            else if (player2position == 15)
            {
                character_player2.Left = 24 + 28;
                character_player2.Top = 486;
            }
            else if (player2position == 16)
            {
                character_player2.Left = 24 + 28;
                character_player2.Top = 403;
            }
            else if (player2position == 17)
            {
                character_player2.Left = 24 + 28;
                character_player2.Top = 320;
            }
            else if (player2position == 18)
            {
                character_player2.Left = 24 + 28;
                character_player2.Top = 237;
            }
            else if (player2position == 19)
            {
                character_player2.Left = 24 + 28;
                character_player2.Top = 154;
            }
            else if (player2position == 20)
            {
                character_player2.Left = 39 + 28;
                character_player2.Top = 36;
            }
            else if (player2position == 21)
            {
                character_player2.Left = 150 + 28;
                character_player2.Top = 19;
            }
            else if (player2position == 22)
            {
                character_player2.Left = 233 + 28;
                character_player2.Top = 19;
            }
            else if (player2position == 23)
            {
                character_player2.Left = 316 + 28;
                character_player2.Top = 19;
            }
            else if (player2position == 24)
            {
                character_player2.Left = 399 + 28;
                character_player2.Top = 19;
            }
            else if (player2position == 25)
            {
                character_player2.Left = 482 + 28;
                character_player2.Top = 19;
            }
            else if (player2position == 26)
            {
                character_player2.Left = 565 + 28;
                character_player2.Top = 19;
            }
            else if (player2position == 27)
            {
                character_player2.Left = 648 + 28;
                character_player2.Top = 19;
            }
            else if (player2position == 28)
            {
                character_player2.Left = 731 + 28;
                character_player2.Top = 19;
            }
            else if (player2position == 29)
            {
                character_player2.Left = 814 + 28;
                character_player2.Top = 19;
            }
            else if (player2position == 30)
            {
                character_player2.Left = 925 + 28;
                character_player2.Top = 35;
            }
            else if (player2position == 31)
            {
                character_player2.Left = 942 + 28;
                character_player2.Top = 146;
            }
            else if (player2position == 32)
            {
                character_player2.Left = 942 + 28;
                character_player2.Top = 229;
            }
            else if (player2position == 33)
            {
                character_player2.Left = 942 + 28;
                character_player2.Top = 312;
            }
            else if (player2position == 34)
            { 
                character_player2.Left = 942 + 28;
                character_player2.Top = 395;
            }
            else if (player2position == 35)
            {
                character_player2.Left = 942 + 28;
                character_player2.Top = 478;
            }
            else if (player2position == 36)
            {
                character_player2.Left = 942 + 28;
                character_player2.Top = 561;
            }
            else if (player2position == 37)
            {
                character_player2.Left = 942 + 28;
                character_player2.Top = 644;
            }
            else if (player2position == 38)
            {
                character_player2.Left = 942 + 28;
                character_player2.Top = 727;
            }
            else if (player2position == 39)
            {
                character_player2.Left = 942 + 28;
                character_player2.Top = 810;
            }

            //Redraw Player 3
            if (player3position == 0)
            {
                character_player3.Left = 927;
                character_player3.Top = 913 + 28;
            }
            else if (player3position == 1)
            {
                character_player3.Left = 817;
                character_player3.Top = 940 + 28;
            }
            else if (player3position == 2)
            {
                character_player3.Left = 734;
                character_player3.Top = 940 + 28;
            }
            else if (player3position == 3)
            {
                character_player3.Left = 651;
                character_player3.Top = 940 + 28;
            }
            else if (player3position == 4)
            {
                character_player3.Left = 568;
                character_player3.Top = 940 + 28;
            }
            else if (player3position == 5)
            {
                character_player3.Left = 485;
                character_player3.Top = 940 + 28;
            }
            else if (player3position == 6)
            {
                character_player3.Left = 402;
                character_player3.Top = 940 + 28;
            }
            else if (player3position == 7)
            {
                character_player3.Left = 319;
                character_player3.Top = 940 + 28;
            }
            else if (player3position == 8)
            {
                character_player3.Left = 236;
                character_player3.Top = 940 + 28;
            }
            else if (player3position == 9)
            {
                character_player3.Left = 153;
                character_player3.Top = 940 + 28;
            }
            else if (player3position == 10)
            {
                character_player3.Left = 7;
                character_player3.Top = 902 + 28;
            }
            else if (player3position == 11)
            {
                character_player3.Left = 24;
                character_player3.Top = 818 + 28;
            }
            else if (player3position == 12)
            {
                character_player3.Left = 24;
                character_player3.Top = 735 + 28;
            }
            else if (player3position == 13)
            {
                character_player3.Left = 24;
                character_player3.Top = 652 + 28;
            }
            else if (player3position == 14)
            {
                character_player3.Left = 24;
                character_player3.Top = 569 + 28;
            }
            else if (player3position == 15)
            {
                character_player3.Left = 24;
                character_player3.Top = 486 + 28;
            }
            else if (player3position == 16)
            {
                character_player3.Left = 24;
                character_player3.Top = 403 + 28;
            }
            else if (player3position == 17)
            {
                character_player3.Left = 24;
                character_player3.Top = 320 + 28;
            }
            else if (player3position == 18)
            {
                character_player3.Left = 24;
                character_player3.Top = 237 + 28;
            }
            else if (player3position == 19)
            {
                character_player3.Left = 24;
                character_player3.Top = 154 + 28;
            }
            else if (player3position == 20)
            {
                character_player3.Left = 39;
                character_player3.Top = 36 + 28;
            }
            else if (player3position == 21)
            {
                character_player3.Left = 150;
                character_player3.Top = 19 + 28;
            }
            else if (player3position == 22)
            {
                character_player3.Left = 233;
                character_player3.Top = 19 + 28;
            }
            else if (player3position == 23)
            {
                character_player3.Left = 316;
                character_player3.Top = 19 + 28;
            }
            else if (player3position == 24)
            {
                character_player3.Left = 399;
                character_player3.Top = 19 + 28;
            }
            else if (player3position == 25)
            {
                character_player3.Left = 482;
                character_player3.Top = 19 + 28;
            }
            else if (player3position == 26)
            {
                character_player3.Left = 565;
                character_player3.Top = 19 + 28;
            }
            else if (player3position == 27)
            {
                character_player3.Left = 648;
                character_player3.Top = 19 + 28;
            }
            else if (player3position == 28)
            {
                character_player3.Left = 731;
                character_player3.Top = 19 + 28;
            }
            else if (player3position == 29)
            {
                character_player3.Left = 814;
                character_player3.Top = 19 + 28;
            }
            else if (player3position == 30)
            {
                character_player3.Left = 925;
                character_player3.Top = 35 + 28;
            }
            else if (player3position == 31)
            {
                character_player3.Left = 942;
                character_player3.Top = 146 + 28;
            }
            else if (player3position == 32)
            {
                character_player3.Left = 942;
                character_player3.Top = 229 + 28;
            }
            else if (player3position == 33)
            {
                character_player3.Left = 942;
                character_player3.Top = 312 + 28;
            }
            else if (player3position == 34)
            {
                character_player3.Left = 942;
                character_player3.Top = 395 + 28;
            }
            else if (player3position == 35)
            {
                character_player3.Left = 942;
                character_player3.Top = 478 + 28;
            }
            else if (player3position == 36)
            {
                character_player3.Left = 942;
                character_player3.Top = 561 + 28;
            }
            else if (player3position == 37)
            {
                character_player3.Left = 942;
                character_player3.Top = 644 + 28;
            }
            else if (player3position == 38)
            {
                character_player3.Left = 942;
                character_player3.Top = 727 + 28;
            }
            else if (player3position == 39)
            {
                character_player3.Left = 942;
                character_player3.Top = 810 + 28;
            }

            //Redraw Player 4
            if (player4position == 0)
            {
                character_player4.Left = 955;
                character_player4.Top = 913 + 28;
            }
            else if (player4position == 1)
            {
                character_player4.Left = 817 + 28;
                character_player4.Top = 940 + 28;
            }
            else if (player4position == 2)
            {
                character_player4.Left = 734 + 28;
                character_player4.Top = 940 + 28;
            }
            else if (player4position == 3)
            {
                character_player4.Left = 651 + 28;
                character_player4.Top = 940 + 28;
            }
            else if (player4position == 4)
            {
                character_player4.Left = 568 + 28;
                character_player4.Top = 940 + 28;
            }
            else if (player4position == 5)
            {
                character_player4.Left = 485 + 28;
                character_player4.Top = 940 + 28;
            }
            else if (player4position == 6)
            {
                character_player4.Left = 402 + 28;
                character_player4.Top = 940 + 28;
            }
            else if (player4position == 7)
            {
                character_player4.Left = 319 + 28;
                character_player4.Top = 940 + 28;
            }
            else if (player4position == 8)
            {
                character_player4.Left = 236 + 28;
                character_player4.Top = 940 + 28;
            }
            else if (player4position == 9)
            {
                character_player4.Left = 153 + 28;
                character_player4.Top = 940 + 28;
            }
            else if (player4position == 10)
            {
                character_player4.Left = 98;
                character_player4.Top = 991;
            }
            else if (player4position == 11)
            {
                character_player4.Left = 24 + 28;
                character_player4.Top = 818 + 28;
            }
            else if (player4position == 12)
            {
                character_player4.Left = 24 + 28;
                character_player4.Top = 735 + 28;
            }
            else if (player4position == 13)
            {
                character_player4.Left = 24 + 28;
                character_player4.Top = 652 + 28;
            }
            else if (player4position == 14)
            {
                character_player4.Left = 24 + 28;
                character_player4.Top = 569 + 28;
            }
            else if (player4position == 15)
            {
                character_player4.Left = 24 + 28;
                character_player4.Top = 486 + 28;
            }
            else if (player4position == 16)
            {
                character_player4.Left = 24 + 28;
                character_player4.Top = 403 + 28;
            }
            else if (player4position == 17)
            {
                character_player4.Left = 24 + 28;
                character_player4.Top = 320 + 28;
            }
            else if (player4position == 18)
            {
                character_player4.Left = 24 + 28;
                character_player4.Top = 237 + 28;
            }
            else if (player4position == 19)
            {
                character_player4.Left = 24 + 28;
                character_player4.Top = 154 + 28;
            }
            else if (player4position == 20)
            {
                character_player4.Left = 39 + 28;
                character_player4.Top = 36 + 28;
            }
            else if (player4position == 21)
            {
                character_player4.Left = 150 + 28;
                character_player4.Top = 19 + 28;
            }
            else if (player4position == 22)
            {
                character_player4.Left = 233 + 28;
                character_player4.Top = 19 + 28;
            }
            else if (player4position == 23)
            {
                character_player4.Left = 316 + 28;
                character_player4.Top = 19 + 28;
            }
            else if (player4position == 24)
            {
                character_player4.Left = 399 + 28;
                character_player4.Top = 19 + 28;
            }
            else if (player4position == 25)
            {
                character_player4.Left = 482 + 28;
                character_player4.Top = 19 + 28;
            }
            else if (player4position == 26)
            {
                character_player4.Left = 565 + 28;
                character_player4.Top = 19 + 28;
            }
            else if (player4position == 27)
            {
                character_player4.Left = 648 + 28;
                character_player4.Top = 19 + 28;
            }
            else if (player4position == 28)
            {
                character_player4.Left = 731 + 28;
                character_player4.Top = 19 + 28;
            }
            else if (player4position == 29)
            {
                character_player4.Left = 814 + 28;
                character_player4.Top = 19 + 28;
            }
            else if (player4position == 30)
            {
                character_player4.Left = 925 + 28;
                character_player4.Top = 35 + 28;
            }
            else if (player4position == 31)
            {
                character_player4.Left = 942 + 28;
                character_player4.Top = 146 + 28;
            }
            else if (player4position == 32)
            {
                character_player4.Left = 942 + 28;
                character_player4.Top = 229 + 28;
            }
            else if (player4position == 33)
            {
                character_player4.Left = 942 + 28;
                character_player4.Top = 312 + 28;
            }
            else if (player4position == 34)
            {
                character_player4.Left = 942 + 28;
                character_player4.Top = 395 + 28;
            }
            else if (player4position == 35)
            {
                character_player4.Left = 942 + 28;
                character_player4.Top = 478 + 28;
            }
            else if (player4position == 36)
            {
                character_player4.Left = 942 + 28;
                character_player4.Top = 561 + 28;
            }
            else if (player4position == 37)
            {
                character_player4.Left = 942 + 28;
                character_player4.Top = 644 + 28;
            }
            else if (player4position == 38)
            {
                character_player4.Left = 942 + 28;
                character_player4.Top = 727 + 28;
            }
            else if (player4position == 39)
            {
                character_player4.Left = 942 + 28;
                character_player4.Top = 810 + 28;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized; //starts the form maximised
        }

        private void btn_debug_moveplayerby1_Click(object sender, EventArgs e)
        {
            if (currentplayer == 1)
            {
                player1position = player1position + 1;
            }

            if (currentplayer == 2)
            {
                player2position = player2position + 1;
            }

            if (currentplayer == 3)
            {
                player3position = player3position + 1;
            }

            if (currentplayer == 4)
            {
                player4position = player4position + 1;
            }

            RedrawPlayerPositions();
            GoToJail();
        }

        public void CheckChance()
        {
            if (currentplayer == 1)
            {
                if (player1position == 7 || player1position == 22 || player1position == 36)
                {
                    RunChance();
                }
            }

            if (currentplayer == 2)
            {
                if (player2position == 7 || player2position == 22 || player2position == 36)
                {
                    RunChance();
                }
            }

            if (currentplayer == 3)
            {
                if (player3position == 7 || player3position == 22 || player3position == 36)
                {
                    RunChance();
                }
            }

            if (currentplayer == 4)
            {
                if (player4position == 7 || player4position == 22 || player4position == 36)
                {
                    RunChance();
                }
            }
        }

        void RunChance()
        {
            Random rnd = new Random();//initialises a random number and assigns it to the "rnd" variable
            randomChance = rnd.Next(1, 17); // assigns variable a random number between 1 and 16

            if (randomChance == 1)
            {
                MessageBox.Show("Advance to Go and collect £200");
                
                if (currentplayer == 1)
                {
                    player1position = 0;
                    player1money = player1money + 200;
                }
                else if (currentplayer == 2)
                {
                    player2position = 0;
                    player2money = player2money + 200;
                }
                else if (currentplayer == 3)
                {
                    player3position = 0;
                    player3money = player3money + 200;
                }
                else if (currentplayer == 4)

                {
                    player4position = 0;
                    player4money = player4money + 200;
                }
            }
            else if (randomChance == 2)
            {
                MessageBox.Show("Go to jail. Move directly to jail. Do not pass Go. Do not collect £200");

                if (currentplayer == 1)
                {
                    character_player1.Left = 60;
                    character_player1.Top = 910;
                    player1position = 10;
                    player1IsInJail = true;
                }
                else if (currentplayer == 2)
                {
                    character_player2.Left = 60 + 28;
                    character_player2.Top = 910;
                    player2position = 10;
                    player2IsInJail = true;
                }
                else if (currentplayer == 3)
                {
                    character_player3.Left = 60;
                    character_player3.Top = 910 + 28;
                    player3position = 10;
                    player3IsInJail = true;
                }
                else if (currentplayer == 4)
                {
                    character_player4.Left = 60 + 28;
                    character_player4.Top = 910 + 28;
                    player4position = 10;
                    player4IsInJail = true;
                }
            }
            else if (randomChance == 3)
            {
                MessageBox.Show("Advance to Pall Mall. If you pass Go collect £200");

                if (currentplayer == 1)
                {
                    player1position = 11;
                }
                if (currentplayer == 2)
                {
                    player2position = 11;
                }
                if (currentplayer == 3)
                {
                    player3position = 11;
                }
                if (currentplayer == 4)
                {
                    player4position = 11;
                }
            }
            else if (randomChance == 4)
            {
                MessageBox.Show("Take a trip to Marylebone Station");

                if (currentplayer == 1)
                {
                    player1position = 15;
                }
                else if (currentplayer == 2)
                {
                    player2position = 15;
                }
                else if (currentplayer == 3)
                {
                    player3position = 15;
                }
                else if (currentplayer == 4)
                {
                    player4position = 15;
                }

            }       
            else if (randomChance == 5)
            {
                MessageBox.Show("Advance to Trafalgar Square");

                if (currentplayer == 1)
                {
                    player1position = 24;
                }
                else if (currentplayer == 2)
                {
                    player2position = 24;
                }
                else if (currentplayer == 3)
                {
                    player3position = 24;
                }
                else if (currentplayer == 4)
                {
                    player4position = 24;
                }

            }
            else if (randomChance == 6)
            {
                MessageBox.Show("Advance to Mayfair");

                if (currentplayer == 1)
                {
                    player1position = 39;
                }
                else if (currentplayer == 2)
                {
                    player2position = 39;
                }
                else if (currentplayer == 3)
                {
                    player3position = 39;
                }
                else if (currentplayer == 4)
                {
                    player4position = 39;
                }

            }
            else if (randomChance == 7)
            {
                MessageBox.Show("Go back three spaces");

                if (currentplayer == 1)
                {
                    player1position = player1position - 3;
                }
                else if (currentplayer == 2)
                {
                    player2position = player2position - 3;
                }
                else if (currentplayer == 3)
                {
                    player3position = player3position - 3;
                }
                else if (currentplayer == 4)
                {
                    player4position = player4position - 4;
                }
            }
            else if (randomChance == 8)
            {
                MessageBox.Show("Make general repairs on all of your houses. For each house pay £25. For each hotel pay £100");
            }
            else if (randomChance == 9)
            {
                MessageBox.Show("You are assessed for street repairs: £40 per house, £115 per hotel");
            }
            else if (randomChance == 10)
            {
                MessageBox.Show("Pay school fees of £150");

                if (currentplayer == 1)
                {
                    player1money = player1money - 150;
                }
                else if (currentplayer == 2)
                {
                    player2money = player2money - 150;
                }
                else if (currentplayer == 3)
                {
                    player3money = player3money - 150;
                }
                else if (currentplayer == 4)
                {
                    player4money = player4money - 150;
                }
            }
            else if (randomChance == 11)
            {
                MessageBox.Show("You are fined £20 for being drunk and disorderly");

                if (currentplayer == 1)
                {
                    player1money = player1money - 20;
                }
                else if (currentplayer == 2)
                {
                    player2money = player2money - 20;
                }
                else if (currentplayer == 3)
                {
                    player3money = player3money - 20;
                }
                else if (currentplayer == 4)
                {
                    player4money = player4money - 20;
                }
            }
            else if (randomChance == 12)
            {
                MessageBox.Show("You recieve a speeding fine of £15");

                if (currentplayer == 1)
                {
                    player1money = player1money - 15;
                }
                else if (currentplayer == 2)
                {
                    player2money = player2money - 15;
                }
                else if (currentplayer == 3)
                {
                    player3money = player3money - 15;
                }
                else if (currentplayer == 4)
                {
                    player4money = player4money - 15;
                }

            }
            else if (randomChance == 13)
            {
                MessageBox.Show("Your building loan matures. Receive £150");

                if (currentplayer == 1)
                {
                    player1money = player1money + 150;
                }
                else if (currentplayer == 2)
                {
                    player2money = player2money + 150;
                }
                else if (currentplayer == 3)
                {
                    player3money = player3money + 150;
                }
                else if (currentplayer == 4)
                {
                    player4money = player4money + 150;
                }
            }
            else if (randomChance == 14)
            {
                MessageBox.Show("You have won a crossword competition. Collect £100");

                if (currentplayer == 1)
                {
                    player1money = player1money + 100;
                }
                else if (currentplayer == 2)
                {
                    player2money = player2money + 100;
                }
                else if (currentplayer == 3)
                {
                    player3money = player3money + 100;
                }
                else if (currentplayer == 4)
                {
                    player4money = player4money + 100;
                }
            }
            else if (randomChance == 15)
            {
                MessageBox.Show("Bank pays you dividend of £50");

                if (currentplayer == 1)
                {
                    player1money = player1money + 50;
                }
                else if (currentplayer == 2)
                {
                    player2money = player2money + 50;
                }
                else if (currentplayer == 3)
                {
                    player3money = player3money + 50;
                }
                else if (currentplayer == 4)
                {
                    player4money = player4money + 50;
                }
            }
            else if (randomChance == 16)
            {
                MessageBox.Show("Get out of jail free. This card may be kept until needed or sold");
            }

            RedrawPlayerPositions();
            RefreshMoneyUI();
        }

        public void CheckCommunityChest()
        {
            if (currentplayer == 1)
            {
                if (player1position == 2 || player1position == 17 || player1position == 33)
                    {
                        RunCommunityChest();
                    }
            }

            if (currentplayer == 2)
            {
                if (player2position == 2 || player2position == 17 || player2position == 33)
                {
                    RunCommunityChest();
                }
            }

            if (currentplayer == 3)
            {
                if (player3position == 2 || player3position == 17 || player3position == 33)
                {
                    RunCommunityChest();
                }
            }

            if (currentplayer == 4)
            {
                if (player4position == 2 || player4position == 17 || player4position == 33)
                {
                    RunCommunityChest();
                }
            }
        }

        public void RunCommunityChest()
        {
                Random rnd = new Random();//initialises a random number and assigns it to the "rnd" variable
                randomCommunityChest = rnd.Next(1, 17); // assigns variable a random number between 1 and 16

                if (randomCommunityChest == 1)
                {
                    MessageBox.Show("Advance to Go");
                    if (currentplayer == 1)
                    {
                        player1position = 0;
                        player1money = player1money + 200;
                    }
                    else if (currentplayer == 2)
                    {
                        player2position = 0;
                        player2money = player2money + 200;
                    }
                    else if (currentplayer == 3)
                    {
                        player3position = 0;
                        player3money = player3money + 200;
                    }
                    else if (currentplayer == 4)
                    {
                        player4position = 0;
                        player4money = player4money + 200;
                    }
                }
                else if (randomCommunityChest == 2)
                {
                    MessageBox.Show("Go back to Old Kent Road");
                    if (currentplayer == 1)
                    {
                        player1position = 1;
                    }
                    else if (currentplayer == 2)
                    {
                        player2position = 1;
                    }
                    else if (currentplayer == 3)
                    {
                        player3position = 1;
                    }
                    else if (currentplayer == 4)
                    {
                        player4position = 1;
                    }
                }
                else if (randomCommunityChest == 3)
                {
                    MessageBox.Show("Go to jail. Move directly to jail. Do not pass Go. Do not collect £200");
                    GoToJail();
                }
                else if (randomCommunityChest == 4)
                {
                    MessageBox.Show("Pay hospital £100");
                    if (currentplayer == 1)
                    {
                        player1money = player1money - 100;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money - 100;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money - 100;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money - 100;
                    }
                }
                else if (randomCommunityChest == 5)
                {
                    MessageBox.Show("Doctor's fee. Pay £50");
                    if (currentplayer == 1)
                    {
                        player1money = player1money - 50;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money - 50;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money - 50;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money - 50;
                    }
                }
                else if (randomCommunityChest == 6)
                {
                    MessageBox.Show("Pay your insurance premium £50");
                    if (currentplayer == 1)
                    {
                        player1money = player1money - 50;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money - 50;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money - 50;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money - 50;
                    }
                }
                else if (randomCommunityChest == 7)
                {
                    MessageBox.Show("Bank error in your favour. Collect £200");
                    if (currentplayer == 1)
                    {
                        player1money = player1money + 200;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money + 200;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money + 200;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money + 200;
                    }
                }
                else if (randomCommunityChest == 8)
                {
                    MessageBox.Show("Annuity matures. Collect £100");
                    if (currentplayer == 1)
                    {
                        player1money = player1money + 100;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money + 100;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money + 100;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money + 100;
                    }
                }
                else if (randomCommunityChest == 9)
                {
                    MessageBox.Show("You inherit £100");
                    if (currentplayer == 1)
                    {
                        player1money = player1money + 100;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money + 100;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money + 100;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money + 100;
                    }
                }
                else if (randomCommunityChest == 10)
                {
                    MessageBox.Show("From sale of stock you get £50");
                    if (currentplayer == 1)
                    {
                        player1money = player1money + 50;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money + 50;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money + 50;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money + 50;
                    }
                }
                else if (randomCommunityChest == 11)
                {
                    MessageBox.Show("Receive interest on 7% preference shares: £25");
                    if (currentplayer == 1)
                    {
                        player1money = player1money + 25;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money + 25;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money + 25;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money + 25;
                    }
                }
                else if (randomCommunityChest == 12)
                {
                    MessageBox.Show("Income tax refund. Collect £20");
                    if (currentplayer == 1)
                    {
                        player1money = player1money + 20;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money + 20;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money + 20;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money + 20;
                    }
                }
                else if (randomCommunityChest == 13)
                {
                    MessageBox.Show("You have won second prize in a beauty contest. Collect £10");
                    if (currentplayer == 1)
                    {
                        player1money = player1money + 10;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money + 10;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money + 10;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money + 10;
                    }
                }
                else if (randomCommunityChest == 14)
                {
                    MessageBox.Show("It is your birthday. Collect £10 from each player");
                    if (currentplayer == 1)
                    {
                        player1money = player1money + 10;
                        player2money = player2money - 10;
                        player3money = player3money - 10;
                        player4money = player4money - 10;
                    }
                    else if (currentplayer == 2)
                    {
                        player1money = player1money - 10;
                        player2money = player2money + 10;
                        player3money = player3money - 10;
                        player4money = player4money - 10;
                    }
                    else if (currentplayer == 3)
                    {
                        player1money = player1money - 10;
                        player2money = player2money - 10;
                        player3money = player3money + 10;
                        player4money = player4money - 10;
                    }
                    else if (currentplayer == 4)
                    {
                        player1money = player1money - 10;
                        player2money = player2money - 10;
                        player3money = player3money - 10;
                        player4money = player4money + 10;
                    }
                }
                else if (randomCommunityChest == 15)
                {
                    MessageBox.Show("Get out of jail free. This card may be kept until needed or sold");
                    if (currentplayer == 1)
                    {
                        player1HasGetOutOfJailCard = true;
                    }
                    else if (currentplayer == 2)
                    {
                        player2HasGetOutOfJailCard = true;
                    }
                    else if (currentplayer == 3)
                    {
                        player3HasGetOutOfJailCard = true;
                    }
                    else if (currentplayer == 4)
                    {
                        player4HasGetOutOfJailCard = true;
                    }

                }
                else if (randomCommunityChest == 16)
                {
                    MessageBox.Show("Pay a £10 fine");
                    if (currentplayer == 1)
                    {
                        player1money = player1money - 10;
                    }
                    else if (currentplayer == 2)
                    {
                        player2money = player2money - 10;
                    }
                    else if (currentplayer == 3)
                    {
                        player3money = player3money - 10;
                    }
                    else if (currentplayer == 4)
                    {
                        player4money = player4money - 10;
                    }

                }
            RedrawPlayerPositions();
            RefreshMoneyUI();
        }

        private void btn_debug_chance_Click(object sender, EventArgs e)
        {
            RunChance();
        }

        private void btn_debug_communitychest_Click(object sender, EventArgs e)
        {
            RunCommunityChest();
        }

        public void GoToJail()
        {
            if (currentplayer == 1) // checks if current player is player 1
            {
                if (player1position == 30) // checks whether player1 is on the Go To Jail tile
                {
                    player1position = 100;
                    character_player1.Left = 60;
                    character_player1.Top = 910;
                    MessageBox.Show("Player 1 has gone to jail");
                    player1IsInJail = true; //tells system that player 1 is actually in jail
                    player1JailCounter = 3;

                    debug_p1prisoncounter.Visible = true;
                    debug_p1prisoncounter.Text = ("Player 1 has " + player1JailCounter + " turns left to leave jail.");
                }
            }
            if (currentplayer == 2)
            {
                if (player2position == 30)
                {
                    player2position = 100;
                    character_player2.Left = 88;
                    character_player2.Top = 910;
                    MessageBox.Show("Player 2 has gone to jail");
                    player2IsInJail = true;
                    player2JailCounter = 3;

                    debug_p2prisoncounter.Visible = true;
                    debug_p2prisoncounter.Text = ("Player 2 has " + player2JailCounter + " turns left to leave jail.");
                }
            }
            if (currentplayer == 3)
            {
                if (player3position == 30)
                {
                    player3position = 100;
                    character_player3.Left = 60;
                    character_player3.Top = 939;
                    MessageBox.Show("Player 3 has gone to jail");
                    player3IsInJail = true;
                    player3JailCounter = 3;

                    debug_p3_prisoncounter.Visible = true;
                    debug_p3_prisoncounter.Text = ("Player 3 has " + player3JailCounter + " turns left to leave jail.");
                }
            }

            if (currentplayer == 4)
            {
                if (player4position == 30)
                {
                    player4position = 100;
                    character_player4.Left = 88;
                    character_player4.Top = 939;
                    MessageBox.Show("Player 4 has gone to jail");
                    player4IsInJail = true;
                    player4JailCounter = 3;

                    debug_p4_prisoncounter.Visible = true;
                    debug_p4_prisoncounter.Text = ("Player 4 has " + player4JailCounter + " turns left to leave jail.");
                }
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox3_Click_1(object sender, EventArgs e)
        {
        }

        void checkJailTime()
        {
            if (currentplayer == 1)
            {
                if (player1JailCounter <=0)
                {
                    player1IsInJail = false;
                    player1position = 10;
                }
                else
                {
                    player1JailCounter--;
                }
            }
            if (currentplayer == 2)
            {
                if (player2JailCounter <= 0)
                {
                    player2IsInJail = false;
                    player2position = 10;
                }
                else
                {
                    player2JailCounter--;
                }
            }
            if (currentplayer == 3)
            {
                if (player3JailCounter <= 0)
                {
                    player3IsInJail = false;
                    player3position = 10;
                }
                else
                {
                    player4JailCounter--;
                }
            }
            if (currentplayer == 4)
            {
                if (player4JailCounter <= 0)
                {
                    player4IsInJail = false;
                    player4position = 10;
                }
                else
                {
                    player4JailCounter--;
                }
            }
        }

        void CheckUtility()
        {
            if (currentplayer == 1)
            {
                if (player1position == 4)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £200 for Income Tax");
                    player1money = player1money - 200;
                }
                else if (player1position == 12)
                {
                    if(electricCompanyOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Electric Company?", "", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            buyUtility();
                        }
                    }
                    else
                    {
                        payUtility(electricCompanyOwnedBy, currentplayer);
                    }
                }

                else if (player1position == 28)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £200 for Income Tax");
                    player1money = player1money - 200;
                }

                else if (player1position == 12)
                {
                    if (waterWorksOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Water Works?", "", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            buyUtility();
                        }
                    }
                    else
                    {
                        payUtility(waterWorksOwnedBy, currentplayer);
                    }
                }
                else if (player1position == 38)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £100 for Super Tax");
                    player1money = player1money - 100;
                }
            }

            if (currentplayer == 2)
            {
                if (player2position == 4)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £200 for Income Tax");
                    player2money = player2money - 200;
                }
                else if (player2position == 12)
                {
                    if (electricCompanyOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Electric Company?", "", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            buyUtility();
                        }
                    }
                    else
                    {
                        payUtility(electricCompanyOwnedBy, currentplayer);
                    }
                }

                else if (player2position == 28)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £200 for Income Tax");
                    player2money = player2money - 200;
                }

                else if (player2position == 12)
                {
                    if (waterWorksOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Water Works?", "", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            buyUtility();
                        }
                    }
                    else
                    {
                        payUtility(waterWorksOwnedBy, currentplayer);
                    }
                }
                else if (player2position == 38)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £100 for Super Tax");
                    player2money = player2money - 100;
                }
            }

            if (currentplayer == 3)
            {
                if (player3position == 4)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £200 for Income Tax");
                    player3money = player3money - 200;
                }
                else if (player3position == 12)
                {
                    if (electricCompanyOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Electric Company?", "", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            buyUtility();
                        }
                    }
                    else
                    {
                        payUtility(electricCompanyOwnedBy, currentplayer);
                    }
                }

                else if (player3position == 28)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £200 for Income Tax");
                    player3money = player3money - 200;
                }

                else if (player3position == 12)
                {
                    if (waterWorksOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Water Works?", "", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            buyUtility();
                        }
                    }
                    else
                    {
                        payUtility(waterWorksOwnedBy, currentplayer);
                    }
                }
                else if (player3position == 38)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £100 for Super Tax");
                    player3money = player3money - 100;
                }
            }

            if (currentplayer == 4)
            {
                if (player4position == 4)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £200 for Income Tax");
                    player4money = player4money - 200;
                }
                else if (player4position == 12)
                {
                    if (electricCompanyOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Electric Company?", "", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            buyUtility();
                        }
                    }
                    else
                    {
                        payUtility(electricCompanyOwnedBy, currentplayer);
                    }
                }

                else if (player4position == 28)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £200 for Income Tax");
                    player4money = player4money - 200;
                }

                else if (player4position == 12)
                {
                    if (waterWorksOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Water Works?", "", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            buyUtility();
                        }
                    }
                    else
                    {
                        payUtility(waterWorksOwnedBy, currentplayer);
                    }
                }
                else if (player4position == 38)
                {
                    MessageBox.Show("Player " + currentplayer + " has been charged £100 for Super Tax");
                    player4money = player4money - 100;
                }
            }

        }

        void CheckTrainStation()
        {

            //-----Player 1------
            if (currentplayer == 1)
            {
               if (player1position == 5) //Kings Cross Station
               {
                    if (kingsCrossStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Kings Cross Station?","",MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            kingsCrossStationOwnedBy = 1;
                            player1money = player1money - kingsCrossStationPrice;
                            listbox_p1properties.Items.Add("Kings Cross Station");

                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (kingsCrossStationOwnedBy == 2)
                    {
                        player1money = player1money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (kingsCrossStationOwnedBy == 3)
                    {
                        player1money = player1money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player3alias + ".");
                    }
                    else if (kingsCrossStationOwnedBy == 4)
                    {
                        player1money = player1money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player4alias + ".");
                    }
               }

               else if (player1position == 15) //Marylebone Station
               {
                    if (maryleboneStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Marylebone Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            maryleboneStationOwnedBy = 1;
                            player1money = player1money - maryleboneStationPrice;
                            listbox_p1properties.Items.Add("Marylebone Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (maryleboneStationOwnedBy == 2)
                    {
                        player1money = player1money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (maryleboneStationOwnedBy == 3)
                    {
                        player1money = player1money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player3alias + ".");
                    }
                    else if (maryleboneStationOwnedBy == 4)
                    {
                        player1money = player1money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player4alias + ".");
                    }
               }

                else if (player1position == 25) //Fenchurch Street Station
                {
                    if (fenchurchStStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Fenchurch St. Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            fenchurchStStationOwnedBy = 1;
                            player1money = player1money - fenchurchStStationPrice;
                            listbox_p1properties.Items.Add("Fenchurch St. Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (fenchurchStStationOwnedBy == 2)
                    {
                        player1money = player1money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (fenchurchStStationOwnedBy == 3)
                    {
                        player1money = player1money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player3alias + ".");
                    }
                    else if (fenchurchStStationOwnedBy == 4)
                    {
                        player1money = player1money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player4alias + ".");
                    }
                }
                else if (player1position == 35) //Liverpool Street Station
                {
                    if (liverpoolStStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Liverpool St. Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            liverpoolStStationOwnedBy = 1;
                            player1money = player1money - liverpoolStStationPrice;
                            listbox_p1properties.Items.Add("Liverpool St. Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (liverpoolStStationOwnedBy == 2)
                    {
                        player1money = player1money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (liverpoolStStationOwnedBy == 3)
                    {
                        player1money = player1money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player3alias + ".");
                    }
                    else if (liverpoolStStationOwnedBy == 4)
                    {
                        player1money = player1money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player4alias + ".");
                    }
                }

            }

            //---------Player 2-----------
            if (currentplayer == 2)
            {
                if (player2position == 5) // Kings Cross Station
                {
                    if (kingsCrossStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Kings Cross Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            kingsCrossStationOwnedBy = 2;
                            player2money = player2money - kingsCrossStationPrice;
                            listbox_p2properties.Items.Add("Kings Cross Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (kingsCrossStationOwnedBy == 1)
                    {
                        player2money = player2money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player2alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (kingsCrossStationOwnedBy == 3)
                    {
                        player2money = player2money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player2alias + " has paid £50 to " + player3alias + ".");
                    }
                    else if (kingsCrossStationOwnedBy == 4)
                    {
                        player2money = player2money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player4alias + ".");
                    }
                }

                if (player2position == 15) //Marylebone Station
                {
                    if (maryleboneStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Marylebone Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            maryleboneStationOwnedBy = 2;
                            player2money = player2money - maryleboneStationPrice;
                            listbox_p2properties.Items.Add("Marylebone Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (maryleboneStationOwnedBy == 1)
                    {
                        player2money = player2money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player2alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (maryleboneStationOwnedBy == 3)
                    {
                        player2money = player2money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player2alias + " has paid £50 to " + player3alias + ".");
                    }
                    else if (maryleboneStationOwnedBy == 4)
                    {
                        player2money = player2money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player4alias + ".");
                    }
                }
                if (player2position == 25) //Fenchurch St. Station
                {
                    if (fenchurchStStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Fenchurch St. Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            fenchurchStStationOwnedBy = 2;
                            player2money = player2money - fenchurchStStationPrice;
                            listbox_p2properties.Items.Add("Fenchurch St. Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (fenchurchStStationOwnedBy == 1)
                    {
                        player2money = player2money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player2alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (fenchurchStStationOwnedBy == 3)
                    {
                        player2money = player2money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player2alias + " has paid £50 to " + player3alias + ".");
                    }
                    else if (fenchurchStStationOwnedBy == 4)
                    {
                        player2money = player2money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player4alias + ".");
                    }
                }
                if (player2position == 35) //Liverpool St. Station
                {
                    if (liverpoolStStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Liverpool St. Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            liverpoolStStationOwnedBy = 2;
                            player2money = player2money - liverpoolStStationPrice;
                            listbox_p2properties.Items.Add("Liverpool St. Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (liverpoolStStationOwnedBy == 1)
                    {
                        player2money = player2money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player2alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (liverpoolStStationOwnedBy == 3)
                    {
                        player2money = player2money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player2alias + " has paid £50 to " + player3alias + ".");
                    }
                    else if (liverpoolStStationOwnedBy == 4)
                    {
                        player2money = player2money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player1alias + " has paid £50 to " + player4alias + ".");
                    }
                }

            }

            //---Player 3-------
            if (currentplayer == 3)
            {
                if (player3position == 5) //Kings Cross Station
                {
                    if (kingsCrossStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Kings Cross Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            kingsCrossStationOwnedBy = 3;
                            player3money = player3money - kingsCrossStationPrice;
                            listbox_p3properties.Items.Add("Kings Cross Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (kingsCrossStationOwnedBy == 1)
                    {
                        player3money = player3money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (kingsCrossStationOwnedBy == 2)
                    {
                        player3money = player3money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (kingsCrossStationOwnedBy == 4)
                    {
                        player3money = player3money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player4alias + ".");
                    }
                }

                if (player3position == 15) //Marylebone Station
                {
                    if (maryleboneStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Marylebone Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            maryleboneStationOwnedBy = 3;
                            player3money = player3money - maryleboneStationPrice;
                            listbox_p3properties.Items.Add("Marylebone Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (maryleboneStationOwnedBy == 1)
                    {
                        player3money = player3money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (maryleboneStationOwnedBy == 2)
                    {
                        player3money = player3money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (maryleboneStationOwnedBy == 4)
                    {
                        player3money = player3money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player4alias + ".");
                    }
                }
                if (player3position == 25) //Fenchurch Street Station
                {
                    if (fenchurchStStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Fenchurch St. Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            fenchurchStStationOwnedBy = 3;
                            player3money = player3money - fenchurchStStationPrice;
                            listbox_p3properties.Items.Add("Fenchurch St. Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (fenchurchStStationOwnedBy == 1)
                    {
                        player3money = player3money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (fenchurchStStationOwnedBy == 2)
                    {
                        player3money = player3money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (fenchurchStStationOwnedBy == 4)
                    {
                        player3money = player3money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player4alias + ".");
                    }
                }
                if (player3position == 35) //Liverpool Street Station
                {
                    if (liverpoolStStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Liverpool St. Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            liverpoolStStationOwnedBy = 3;
                            player3money = player3money - liverpoolStStationPrice;
                            listbox_p3properties.Items.Add("Liverpool St. Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (liverpoolStStationOwnedBy == 1)
                    {
                        player3money = player3money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (liverpoolStStationOwnedBy == 2)
                    {
                        player3money = player3money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (liverpoolStStationOwnedBy == 4)
                    {
                        player3money = player3money - 50;
                        player4money = player4money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player4alias + ".");
                    }
                }

            }
            //-----Player 4-------
            if (currentplayer == 4)
            {
                if (player4position == 5) //Kings Cross Station
                {
                    if (kingsCrossStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Kings Cross Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            kingsCrossStationOwnedBy = 4;
                            player4money = player4money - kingsCrossStationPrice;
                            listbox_p4properties.Items.Add("Kings Cross Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (kingsCrossStationOwnedBy == 1)
                    {
                        player4money = player4money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player4alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (kingsCrossStationOwnedBy == 2)
                    {
                        player4money = player4money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (kingsCrossStationOwnedBy == 3)
                    {
                        player4money = player4money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player4alias + " has paid £50 to " + player3alias + ".");
                    }
                }

                if (player4position == 15) //Marylebone Station
                {
                    if (maryleboneStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Marylebone Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            maryleboneStationOwnedBy = 4;
                            player4money = player4money - maryleboneStationPrice;
                            listbox_p4properties.Items.Add("Marylebone Station Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (maryleboneStationOwnedBy == 1)
                    {
                        player4money = player4money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player4alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (maryleboneStationOwnedBy == 2)
                    {
                        player4money = player4money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (maryleboneStationOwnedBy == 3)
                    {
                        player4money = player4money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player4alias + " has paid £50 to " + player3alias + ".");
                    }
                }

                if (player4position == 25) //Fenchurch Street Station
                {
                    if (fenchurchStStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Fenchurch St. Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            fenchurchStStationOwnedBy = 4;
                            player4money = player4money - fenchurchStStationPrice;
                            listbox_p4properties.Items.Add("Fenchurch Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (fenchurchStStationOwnedBy == 1)
                    {
                        player4money = player4money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player4alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (fenchurchStStationOwnedBy == 2)
                    {
                        player4money = player4money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (fenchurchStStationOwnedBy == 3)
                    {
                        player4money = player4money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player4alias + " has paid £50 to " + player3alias + ".");
                    }
                }

                if (player4position == 35) //Liverpool Street Station
                {
                    if (liverpoolStStationOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Liverpool St. Station?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            liverpoolStStationOwnedBy = 4;
                            player4money = player4money - liverpoolStStationPrice;
                            listbox_p4properties.Items.Add("Liverpool St. Station");
                        }
                        else if (result == DialogResult.No)
                        {

                        }
                    }
                    if (liverpoolStStationOwnedBy == 1)
                    {
                        player4money = player4money - 50;
                        player1money = player1money + 50;
                        MessageBox.Show(player4alias + " has paid £50 to " + player1alias + ".");
                    }
                    else if (liverpoolStStationOwnedBy == 2)
                    {
                        player4money = player4money - 50;
                        player2money = player2money + 50;
                        MessageBox.Show(player3alias + " has paid £50 to " + player2alias + ".");
                    }
                    else if (liverpoolStStationOwnedBy == 3)
                    {
                        player4money = player4money - 50;
                        player3money = player3money + 50;
                        MessageBox.Show(player4alias + " has paid £50 to " + player3alias + ".");
                    }
                }
            }
        }

        void CheckProperty()
        {
            if (currentplayer == 1)
            {

                if (player1position == 1)
                {
                    if (oldKentRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Old Kent Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(oldKentRoadOwnedBy, currentplayer, 2);
                    }
                }  
                else if (player1position == 3)
                {
                    if (whiteChapelRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Whitechapel Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(whiteChapelRoadOwnedBy, currentplayer, 4);
                    }
                }
                else if (player1position == 6)
                {
                    if (theAngelIslingtonOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase The Angel Islington?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(theAngelIslingtonOwnedBy, currentplayer, 6);
                    }
                }
                else if (player1position == 8)
                {
                    if (eustonRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Euston Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(eustonRoadOwnedBy, currentplayer, 6);
                    }
                }
                else if (player1position == 9)
                {
                    if (pentonvilleRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Pentonville Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(eustonRoadOwnedBy, currentplayer, 8);
                    }
                }
                else if (player1position == 11)
                {
                    if (pallMallOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Pall Mall?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(pallMallOwnedBy, currentplayer, 10);
                    }
                }
                else if (player1position == 13)
                {
                    if (whitehallOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Whitehall?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(whitehallOwnedBy, currentplayer, 10);
                    }
                }
                else if (player1position == 14)
                {
                    if (northumberlandAvenueOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Northumberland Avenue?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(northumberlandAvenueOwnedBy, currentplayer, 12);
                    }
                }
                else if (player1position == 16)
                {
                    if (bowStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Bow Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(bowStreetOwnedBy, currentplayer, 14);
                    }
                }
                else if (player1position == 18)
                {
                    if (marlboroughStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Marlborough Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(marlboroughStreetOwnedBy, currentplayer, 14);
                    }
                }
                else if (player1position == 19)
                {
                    if (vineStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Vine Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(vineStreetOwnedBy, currentplayer, 16);
                    }
                }
                else if (player1position == 21)
                {
                    if (strandOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Strand?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(strandOwnedBy, currentplayer, 18);
                    }
                }
                else if (player1position == 23)
                {
                    if (fleetStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Fleet Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(fleetStreetOwnedBy, currentplayer, 18);
                    }
                }
                else if (player1position == 24)
                {
                    if (trafalgarSquareOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Trafalgar Square", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(trafalgarSquareOwnedBy, currentplayer, 20);
                    }
                }
                else if (player1position == 26)
                {
                    if (leicesterSquareOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Leicester Square", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(leicesterSquareOwnedBy, currentplayer, 22);
                    }
                }
                else if (player1position == 27)
                {
                    if (coventryStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Coventry Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(coventryStreetOwnedBy, currentplayer, 22);
                    }
                }
                else if (player1position == 29)
                {
                    if (piccadillyOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Piccadilly", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(piccadillyOwnedBy, currentplayer, 22);
                    }
                }
                else if (player1position == 31)
                {
                    if (regentStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Regent Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(regentStreetOwnedBy, currentplayer, 26);
                    }
                }
                else if (player1position == 32)
                {
                    if (oxfordStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Oxford Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(oxfordStreetOwnedBy, currentplayer, 26);
                    }
                }
                else if (player1position == 34)
                {
                    if (bondStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Bond Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(bondStreetOwnedBy, currentplayer, 28);
                    }
                }
                else if (player1position == 37)
                {
                    if (parkLaneOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Park Lane", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(parkLaneOwnedBy, currentplayer, 35);
                    }
                }
                else if (player1position == 39)
                {
                    if (mayfairOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Mayfair", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(mayfairOwnedBy, currentplayer, 50);
                    }
                }

            }

            if (currentplayer == 2)
            {

                if (player2position == 1)
                {
                    if (oldKentRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Old Kent Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(oldKentRoadOwnedBy, currentplayer, 2);
                    }
                }
                else if (player2position == 3)
                {
                    if (whiteChapelRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Whitechapel Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(whiteChapelRoadOwnedBy, currentplayer, 4);
                    }
                }
                else if (player2position == 6)
                {
                    if (theAngelIslingtonOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase The Angel Islington?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(theAngelIslingtonOwnedBy, currentplayer, 6);
                    }
                }
                else if (player2position == 8)
                {
                    if (eustonRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Euston Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(eustonRoadOwnedBy, currentplayer, 6);
                    }
                }
                else if (player2position == 9)
                {
                    if (pentonvilleRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Pentonville Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(eustonRoadOwnedBy, currentplayer, 8);
                    }
                }
                else if (player2position == 11)
                {
                    if (pallMallOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Pall Mall?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(pallMallOwnedBy, currentplayer, 10);
                    }
                }
                else if (player2position == 13)
                {
                    if (whitehallOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Whitehall?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(whitehallOwnedBy, currentplayer, 10);
                    }
                }
                else if (player2position == 14)
                {
                    if (northumberlandAvenueOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Northumberland Avenue?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(northumberlandAvenueOwnedBy, currentplayer, 12);
                    }
                }
                else if (player2position == 16)
                {
                    if (bowStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Bow Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(bowStreetOwnedBy, currentplayer, 14);
                    }
                }
                else if (player2position == 18)
                {
                    if (marlboroughStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Marlborough Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(marlboroughStreetOwnedBy, currentplayer, 14);
                    }
                }
                else if (player2position == 19)
                {
                    if (vineStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Vine Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(vineStreetOwnedBy, currentplayer, 16);
                    }
                }
                else if (player2position == 21)
                {
                    if (strandOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Strand?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(strandOwnedBy, currentplayer, 18);
                    }
                }
                else if (player2position == 23)
                {
                    if (fleetStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Fleet Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(fleetStreetOwnedBy, currentplayer, 18);
                    }
                }
                else if (player2position == 24)
                {
                    if (trafalgarSquareOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Trafalgar Square", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(trafalgarSquareOwnedBy, currentplayer, 20);
                    }
                }
                else if (player2position == 26)
                {
                    if (leicesterSquareOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Leicester Square", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(leicesterSquareOwnedBy, currentplayer, 22);
                    }
                }
                else if (player2position == 27)
                {
                    if (coventryStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Coventry Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(coventryStreetOwnedBy, currentplayer, 22);
                    }
                }
                else if (player2position == 29)
                {
                    if (piccadillyOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Piccadilly", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(piccadillyOwnedBy, currentplayer, 22);
                    }
                }
                else if (player2position == 31)
                {
                    if (regentStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Regent Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(regentStreetOwnedBy, currentplayer, 26);
                    }
                }
                else if (player2position == 32)
                {
                    if (oxfordStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Oxford Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(oxfordStreetOwnedBy, currentplayer, 26);
                    }
                }
                else if (player2position == 34)
                {
                    if (bondStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Bond Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(bondStreetOwnedBy, currentplayer, 28);
                    }
                }
                else if (player2position == 37)
                {
                    if (parkLaneOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Park Lane", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(parkLaneOwnedBy, currentplayer, 35);
                    }
                }
                else if (player2position == 39)
                {
                    if (mayfairOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Mayfair", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(mayfairOwnedBy, currentplayer, 50);
                    }
                }

            }

            if (currentplayer == 3)
            {
                if (player3position == 1)
                {
                    if (oldKentRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Old Kent Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(oldKentRoadOwnedBy, currentplayer, 2);
                    }
                }
                else if (player3position == 3)
                {
                    if (whiteChapelRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Whitechapel Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(whiteChapelRoadOwnedBy, currentplayer, 4);
                    }
                }
                else if (player3position == 6)
                {
                    if (theAngelIslingtonOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase The Angel Islington?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(theAngelIslingtonOwnedBy, currentplayer, 6);
                    }
                }
                else if (player3position == 8)
                {
                    if (eustonRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Euston Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(eustonRoadOwnedBy, currentplayer, 6);
                    }
                }
                else if (player3position == 9)
                {
                    if (pentonvilleRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Pentonville Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(eustonRoadOwnedBy, currentplayer, 8);
                    }
                }
                else if (player3position == 11)
                {
                    if (pallMallOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Pall Mall?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(pallMallOwnedBy, currentplayer, 10);
                    }
                }
                else if (player3position == 13)
                {
                    if (whitehallOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Whitehall?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(whitehallOwnedBy, currentplayer, 10);
                    }
                }
                else if (player3position == 14)
                {
                    if (northumberlandAvenueOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Northumberland Avenue?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(northumberlandAvenueOwnedBy, currentplayer, 12);
                    }
                }
                else if (player3position == 16)
                {
                    if (bowStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Bow Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(bowStreetOwnedBy, currentplayer, 14);
                    }
                }
                else if (player3position == 18)
                {
                    if (marlboroughStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Marlborough Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(marlboroughStreetOwnedBy, currentplayer, 14);
                    }
                }
                else if (player3position == 19)
                {
                    if (vineStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Vine Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(vineStreetOwnedBy, currentplayer, 16);
                    }
                }
                else if (player3position == 21)
                {
                    if (strandOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Strand?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(strandOwnedBy, currentplayer, 18);
                    }
                }
                else if (player3position == 23)
                {
                    if (fleetStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Fleet Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(fleetStreetOwnedBy, currentplayer, 18);
                    }
                }
                else if (player3position == 24)
                {
                    if (trafalgarSquareOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Trafalgar Square", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(trafalgarSquareOwnedBy, currentplayer, 20);
                    }
                }
                else if (player3position == 26)
                {
                    if (leicesterSquareOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Leicester Square", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(leicesterSquareOwnedBy, currentplayer, 22);
                    }
                }
                else if (player3position == 27)
                {
                    if (coventryStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Coventry Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(coventryStreetOwnedBy, currentplayer, 22);
                    }
                }
                else if (player3position == 29)
                {
                    if (piccadillyOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Piccadilly", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(piccadillyOwnedBy, currentplayer, 22);
                    }
                }
                else if (player3position == 31)
                {
                    if (regentStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Regent Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(regentStreetOwnedBy, currentplayer, 26);
                    }
                }
                else if (player3position == 32)
                {
                    if (oxfordStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Oxford Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(oxfordStreetOwnedBy, currentplayer, 26);
                    }
                }
                else if (player3position == 34)
                {
                    if (bondStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Bond Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(bondStreetOwnedBy, currentplayer, 28);
                    }
                }
                else if (player3position == 37)
                {
                    if (parkLaneOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Park Lane", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(parkLaneOwnedBy, currentplayer, 35);
                    }
                }
                else if (player3position == 39)
                {
                    if (mayfairOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Mayfair", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(mayfairOwnedBy, currentplayer, 50);
                    }
                }

            }

            if (currentplayer == 4)
            {
                if (player4position == 1)
                {
                    if (oldKentRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Old Kent Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(oldKentRoadOwnedBy, currentplayer, 2);
                    }
                }
                else if (player4position == 3)
                {
                    if (whiteChapelRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Whitechapel Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(whiteChapelRoadOwnedBy, currentplayer, 4);
                    }
                }
                else if (player4position == 6)
                {
                    if (theAngelIslingtonOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase The Angel Islington?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(theAngelIslingtonOwnedBy, currentplayer, 6);
                    }
                }
                else if (player4position == 8)
                {
                    if (eustonRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Euston Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(eustonRoadOwnedBy, currentplayer, 6);
                    }
                }
                else if (player4position == 9)
                {
                    if (pentonvilleRoadOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Pentonville Road?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(eustonRoadOwnedBy, currentplayer, 8);
                    }
                }
                else if (player4position == 11)
                {
                    if (pallMallOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Pall Mall?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(pallMallOwnedBy, currentplayer, 10);
                    }
                }
                else if (player4position == 13)
                {
                    if (whitehallOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Whitehall?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(whitehallOwnedBy, currentplayer, 10);
                    }
                }
                else if (player4position == 14)
                {
                    if (northumberlandAvenueOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Northumberland Avenue?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(northumberlandAvenueOwnedBy, currentplayer, 12);
                    }
                }
                else if (player4position == 16)
                {
                    if (bowStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Bow Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(bowStreetOwnedBy, currentplayer, 14);
                    }
                }
                else if (player4position == 18)
                {
                    if (marlboroughStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Marlborough Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(marlboroughStreetOwnedBy, currentplayer, 14);
                    }
                }
                else if (player4position == 19)
                {
                    if (vineStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Vine Street?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(vineStreetOwnedBy, currentplayer, 16);
                    }
                }
                else if (player4position == 21)
                {
                    if (strandOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Strand?", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(strandOwnedBy, currentplayer, 18);
                    }
                }
                else if (player4position == 23)
                {
                    if (fleetStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Fleet Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(fleetStreetOwnedBy, currentplayer, 18);
                    }
                }
                else if (player4position == 24)
                {
                    if (trafalgarSquareOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Trafalgar Square", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(trafalgarSquareOwnedBy, currentplayer, 20);
                    }
                }
                else if (player4position == 26)
                {
                    if (leicesterSquareOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Leicester Square", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(leicesterSquareOwnedBy, currentplayer, 22);
                    }
                }
                else if (player4position == 27)
                {
                    if (coventryStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Coventry Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(coventryStreetOwnedBy, currentplayer, 22);
                    }
                }
                else if (player4position == 29)
                {
                    if (piccadillyOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Piccadilly", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(piccadillyOwnedBy, currentplayer, 22);
                    }
                }
                else if (player4position == 31)
                {
                    if (regentStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Regent Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(regentStreetOwnedBy, currentplayer, 26);
                    }
                }
                else if (player4position == 32)
                {
                    if (oxfordStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Oxford Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(oxfordStreetOwnedBy, currentplayer, 26);
                    }
                }
                else if (player4position == 34)
                {
                    if (bondStreetOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Bond Street", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(bondStreetOwnedBy, currentplayer, 28);
                    }
                }
                else if (player4position == 37)
                {
                    if (parkLaneOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Park Lane", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(parkLaneOwnedBy, currentplayer, 35);
                    }
                }
                else if (player4position == 39)
                {
                    if (mayfairOwnedBy == 0)
                    {
                        var result = MessageBox.Show("Do you want to purchase Mayfair", "", MessageBoxButtons.YesNo); //Shows a message box and returns the value of the button clicked by the user
                        if (result == DialogResult.Yes)
                        {
                            buyProperty();
                        }
                    }
                    else
                    {
                        payRent(mayfairOwnedBy, currentplayer, 50);
                    }
                }

            }
        }

        void InitialiseProperties()
        {
            oldKentRoadOwnedBy = 0;
            whiteChapelRoadOwnedBy = 0;
            theAngelIslingtonOwnedBy = 0;
            eustonRoadOwnedBy = 0;
            pentonvilleRoadOwnedBy = 0;
            pallMallOwnedBy = 0;
            whitehallOwnedBy = 0;
            northumberlandAvenueOwnedBy = 0;
            bowStreetOwnedBy = 0;
            marlboroughStreetOwnedBy = 0;
            vineStreetOwnedBy = 0;
            strandOwnedBy = 0;
            fleetStreetOwnedBy = 0;
            trafalgarSquareOwnedBy = 0;
            leicesterSquareOwnedBy = 0;
            coventryStreetOwnedBy = 0;
            piccadillyOwnedBy = 0;
            regentStreetOwnedBy = 0;
            oxfordStreetOwnedBy = 0;
            bondStreetOwnedBy = 0;
            parkLaneOwnedBy = 0;
            mayfairOwnedBy = 0;

            oldKentRoadHouses = 0;
            whiteChapelRoadHouses = 0;
            theAngelIslingtonHouses = 0;
            eustonRoadHouses = 0;
            pentonvilleRoadHouses = 0;
            pallMallHouses = 0;
            whitehallHouses = 0;
            northumberlandAvenueHouses = 0;
            bowStreetHouses = 0;
            marlboroughStreetHouses = 0;
            vineStreetHouses = 0;
            strandHouses = 0;
            fleetStreetHouses = 0;
            trafalgarSquareHouses = 0;
            leicesterSquareHouses = 0;
            coventryStreetHouses = 0;
            piccadillyHouses = 0;
            regentStreetHouses = 0;
            oxfordStreetHouses = 0;
            bondStreetHouses = 0;
            parkLaneHouses = 0;
            mayfairHouses = 0;
        }

        void buyProperty()
        {
            if (currentplayer == 1)
            {
                switch (player1position)
                {
                    case 1:
                        oldKentRoadOwnedBy = currentplayer;
                        player1money = player1money - 60;
                        listbox_p1properties.Items.Add("Old Kent Road");
                        break;
                    case 3:
                        whiteChapelRoadOwnedBy = currentplayer;
                        player1money = player1money - 60;
                        listbox_p1properties.Items.Add("White Chapel Road");
                        break;
                    case 6:
                        theAngelIslingtonOwnedBy = currentplayer;
                        player1money = player1money - 100;
                        listbox_p1properties.Items.Add("The Angel Islington");
                        break;
                    case 8:
                        eustonRoadOwnedBy = currentplayer;
                        player1money = player1money - 100;
                        listbox_p1properties.Items.Add("Euston Road");
                        break;
                    case 9:
                        pentonvilleRoadOwnedBy = currentplayer;
                        player1money = player1money - 120;
                        listbox_p1properties.Items.Add("Pentonville Road");
                        break;
                    case 11:
                        pallMallOwnedBy = currentplayer;
                        player1money = player1money - 140;
                        listbox_p1properties.Items.Add("Pall Mall");
                        break;
                    case 13:
                        whitehallOwnedBy = currentplayer;
                        player1money = player1money - 140;
                        listbox_p1properties.Items.Add("Whitehall");
                        break;
                    case 14:
                        northumberlandAvenueOwnedBy = currentplayer;
                        player1money = player1money - 160;
                        listbox_p1properties.Items.Add("Northumberland Avenue");
                        break;
                    case 16:
                        bowStreetOwnedBy = currentplayer;
                        player1money = player1money - 180;
                        listbox_p1properties.Items.Add("Bow Street");
                        break;
                    case 18:
                        marlboroughStreetOwnedBy = currentplayer;
                        player1money = player1money - 180;
                        listbox_p1properties.Items.Add("Marlborough Street");
                        break;
                    case 19:
                        vineStreetOwnedBy = currentplayer;
                        player1money = player1money - 200;
                        listbox_p1properties.Items.Add("Vine Street");
                        break;
                    case 21:
                        strandOwnedBy = currentplayer;
                        player1money = player1money - 220;
                        listbox_p1properties.Items.Add("Strand");
                        break;
                    case 23:
                        fleetStreetOwnedBy = currentplayer;
                        player1money = player1money - 220;
                        listbox_p1properties.Items.Add("Fleet Street");
                        break;
                    case 24:
                        trafalgarSquareOwnedBy = currentplayer;
                        player1money = player1money - 240;
                        listbox_p1properties.Items.Add("Trafalgar Square");
                        break;
                    case 26:
                        leicesterSquareOwnedBy = currentplayer;
                        player1money = player1money - 260;
                        listbox_p1properties.Items.Add("Leicester Square");
                        break;
                    case 27:
                        coventryStreetOwnedBy = currentplayer;
                        player1money = player1money - 260;
                        listbox_p1properties.Items.Add("Coventry Street");
                        break;
                    case 29:
                        piccadillyOwnedBy = currentplayer;
                        player1money = player1money - 280;
                        listbox_p1properties.Items.Add("Piccadilly");
                        break;
                    case 31:
                        regentStreetOwnedBy = currentplayer;
                        player1money = player1money - 300;
                        listbox_p1properties.Items.Add("Regent Street");
                        break;
                    case 32:
                        oxfordStreetOwnedBy = currentplayer;
                        player1money = player1money - 300;
                        listbox_p1properties.Items.Add("Oxford Street");
                        break;
                    case 34:
                        bondStreetOwnedBy = currentplayer;
                        player1money = player1money - 320;
                        listbox_p1properties.Items.Add("Bond Street");
                        break;
                    case 37:
                        parkLaneOwnedBy = currentplayer;
                        player1money = player1money - 350;
                        listbox_p1properties.Items.Add("Park Lane");
                        break;
                    case 39:
                        mayfairOwnedBy = currentplayer;
                        player1money = player1money - 400;
                        listbox_p1properties.Items.Add("Mayfair");
                        break;
                }
            }
            else if (currentplayer == 2)
            {
                switch (player2position)
                {
                    case 1:
                        oldKentRoadOwnedBy = currentplayer;
                        player2money = player2money - 60;
                        listbox_p2properties.Items.Add("Old Kent Road");
                        break;
                    case 3:
                        whiteChapelRoadOwnedBy = currentplayer;
                        player2money = player2money - 60;
                        listbox_p2properties.Items.Add("White Chapel Road");
                        break;
                    case 6:
                        theAngelIslingtonOwnedBy = currentplayer;
                        player2money = player2money - 100;
                        listbox_p2properties.Items.Add("The Angel Islington");
                        break;
                    case 8:
                        eustonRoadOwnedBy = currentplayer;
                        player2money = player2money - 100;
                        listbox_p2properties.Items.Add("Euston Road");
                        break;
                    case 9:
                        pentonvilleRoadOwnedBy = currentplayer;
                        player2money = player2money - 120;
                        listbox_p2properties.Items.Add("Pentonville Road");
                        break;
                    case 11:
                        pallMallOwnedBy = currentplayer;
                        player2money = player2money - 140;
                        listbox_p2properties.Items.Add("Pall Mall");
                        break;
                    case 13:
                        whitehallOwnedBy = currentplayer;
                        player2money = player2money - 140;
                        listbox_p2properties.Items.Add("Whitehall");
                        break;
                    case 14:
                        northumberlandAvenueOwnedBy = currentplayer;
                        player2money = player2money - 160;
                        listbox_p2properties.Items.Add("Northumberland Avenue");
                        break;
                    case 16:
                        bowStreetOwnedBy = currentplayer;
                        player2money = player2money - 180;
                        listbox_p2properties.Items.Add("Bow Street");
                        break;
                    case 18:
                        marlboroughStreetOwnedBy = currentplayer;
                        player2money = player2money - 180;
                        listbox_p2properties.Items.Add("Marlborough Street");
                        break;
                    case 19:
                        vineStreetOwnedBy = currentplayer;
                        player2money = player2money - 200;
                        listbox_p2properties.Items.Add("Vine Street");
                        break;
                    case 21:
                        strandOwnedBy = currentplayer;
                        player2money = player2money - 220;
                        listbox_p2properties.Items.Add("Strand");
                        break;
                    case 23:
                        fleetStreetOwnedBy = currentplayer;
                        player2money = player2money - 220;
                        listbox_p2properties.Items.Add("Fleet Street");
                        break;
                    case 24:
                        trafalgarSquareOwnedBy = currentplayer;
                        player2money = player2money - 240;
                        listbox_p2properties.Items.Add("Trafalgar Square");
                        break;
                    case 26:
                        leicesterSquareOwnedBy = currentplayer;
                        player2money = player2money - 260;
                        listbox_p2properties.Items.Add("Leicester Square");
                        break;
                    case 27:
                        coventryStreetOwnedBy = currentplayer;
                        player2money = player2money - 260;
                        listbox_p2properties.Items.Add("Coventry Street");
                        break;
                    case 29:
                        piccadillyOwnedBy = currentplayer;
                        player2money = player2money - 280;
                        listbox_p2properties.Items.Add("Piccadilly");
                        break;
                    case 31:
                        regentStreetOwnedBy = currentplayer;
                        player2money = player2money - 300;
                        listbox_p2properties.Items.Add("Regent Street");
                        break;
                    case 32:
                        oxfordStreetOwnedBy = currentplayer;
                        player2money = player2money - 300;
                        listbox_p2properties.Items.Add("Oxford Street");
                        break;
                    case 34:
                        bondStreetOwnedBy = currentplayer;
                        player2money = player2money - 320;
                        listbox_p2properties.Items.Add("Bond Street");
                        break;
                    case 37:
                        parkLaneOwnedBy = currentplayer;
                        player2money = player2money - 350;
                        listbox_p2properties.Items.Add("Park Lane");
                        break;
                    case 39:
                        mayfairOwnedBy = currentplayer;
                        player2money = player2money - 400;
                        listbox_p2properties.Items.Add("Mayfair");
                        break;
                }
            }
            else if (currentplayer == 3)
            {
                switch (player3position)
                {
                    case 1:
                        oldKentRoadOwnedBy = currentplayer;
                        player3money = player3money - 60;
                        listbox_p3properties.Items.Add("Old Kent Road");
                        break;
                    case 3:
                        whiteChapelRoadOwnedBy = currentplayer;
                        player3money = player3money - 60;
                        listbox_p3properties.Items.Add("White Chapel Road");
                        break;
                    case 6:
                        theAngelIslingtonOwnedBy = currentplayer;
                        player3money = player3money - 100;
                        listbox_p3properties.Items.Add("The Angel Islington");
                        break;
                    case 8:
                        eustonRoadOwnedBy = currentplayer;
                        player3money = player3money - 100;
                        listbox_p3properties.Items.Add("Euston Road");
                        break;
                    case 9:
                        pentonvilleRoadOwnedBy = currentplayer;
                        player3money = player3money - 120;
                        listbox_p3properties.Items.Add("Pentonville Road");
                        break;
                    case 11:
                        pallMallOwnedBy = currentplayer;
                        player3money = player3money - 140;
                        listbox_p3properties.Items.Add("Pall Mall");
                        break;
                    case 13:
                        whitehallOwnedBy = currentplayer;
                        player3money = player3money - 140;
                        listbox_p3properties.Items.Add("Whitehall");
                        break;
                    case 14:
                        northumberlandAvenueOwnedBy = currentplayer;
                        player3money = player3money - 160;
                        listbox_p3properties.Items.Add("Northumberland Avenue");
                        break;
                    case 16:
                        bowStreetOwnedBy = currentplayer;
                        player3money = player3money - 180;
                        listbox_p3properties.Items.Add("Bow Street");
                        break;
                    case 18:
                        marlboroughStreetOwnedBy = currentplayer;
                        player3money = player3money - 180;
                        listbox_p3properties.Items.Add("Marlborough Street");
                        break;
                    case 19:
                        vineStreetOwnedBy = currentplayer;
                        player3money = player3money - 200;
                        listbox_p3properties.Items.Add("Vine Street");
                        break;
                    case 21:
                        strandOwnedBy = currentplayer;
                        player3money = player3money - 220;
                        listbox_p3properties.Items.Add("Strand");
                        break;
                    case 23:
                        fleetStreetOwnedBy = currentplayer;
                        player3money = player3money - 220;
                        listbox_p3properties.Items.Add("Fleet Street");
                        break;
                    case 24:
                        trafalgarSquareOwnedBy = currentplayer;
                        player3money = player3money - 240;
                        listbox_p3properties.Items.Add("Trafalgar Square");
                        break;
                    case 26:
                        leicesterSquareOwnedBy = currentplayer;
                        player3money = player3money - 260;
                        listbox_p3properties.Items.Add("Leicester Square");
                        break;
                    case 27:
                        coventryStreetOwnedBy = currentplayer;
                        player3money = player3money - 260;
                        listbox_p3properties.Items.Add("Covenry Street");
                        break;
                    case 29:
                        piccadillyOwnedBy = currentplayer;
                        player3money = player3money - 280;
                        listbox_p3properties.Items.Add("Piccadilly");
                        break;
                    case 31:
                        regentStreetOwnedBy = currentplayer;
                        player3money = player3money - 300;
                        listbox_p3properties.Items.Add("Regent Street");
                        break;
                    case 32:
                        oxfordStreetOwnedBy = currentplayer;
                        player3money = player3money - 300;
                        listbox_p3properties.Items.Add("Oxford Street");
                        break;
                    case 34:
                        bondStreetOwnedBy = currentplayer;
                        player3money = player3money - 320;
                        listbox_p3properties.Items.Add("Bond Street");
                        break;
                    case 37:
                        parkLaneOwnedBy = currentplayer;
                        player3money = player3money - 350;
                        listbox_p3properties.Items.Add("Park Lane");
                        break;
                    case 39:
                        mayfairOwnedBy = currentplayer;
                        player3money = player3money - 400;
                        listbox_p3properties.Items.Add("Mayfair");
                        break;
                }
            }
            else if (currentplayer == 4)
            {
                switch (player4position)
                {
                    case 1:
                        oldKentRoadOwnedBy = currentplayer;
                        player4money = player4money - 60;
                        listbox_p4properties.Items.Add("Old Kent Road");
                        break;
                    case 3:
                        whiteChapelRoadOwnedBy = currentplayer;
                        player4money = player4money - 60;
                        listbox_p4properties.Items.Add("White Chapel");
                        break;
                    case 6:
                        theAngelIslingtonOwnedBy = currentplayer;
                        player4money = player4money - 100;
                        listbox_p4properties.Items.Add("The Angel Islington");
                        break;
                    case 8:
                        eustonRoadOwnedBy = currentplayer;
                        player4money = player4money - 100;
                        listbox_p4properties.Items.Add("Euston Road");
                        break;
                    case 9:
                        pentonvilleRoadOwnedBy = currentplayer;
                        player4money = player4money - 120;
                        listbox_p4properties.Items.Add("Pentonville Road");
                        break;
                    case 11:
                        pallMallOwnedBy = currentplayer;
                        player4money = player4money - 140;
                        listbox_p4properties.Items.Add("Pall Mall");
                        break;
                    case 13:
                        whitehallOwnedBy = currentplayer;
                        player4money = player4money - 140;
                        listbox_p4properties.Items.Add("Whitehall");
                        break;
                    case 14:
                        northumberlandAvenueOwnedBy = currentplayer;
                        player4money = player4money - 160;
                        listbox_p4properties.Items.Add("Northumberland Avenue");
                        break;
                    case 16:
                        bowStreetOwnedBy = currentplayer;
                        player4money = player4money - 180;
                        listbox_p4properties.Items.Add("Bow Street");
                        break;
                    case 18:
                        marlboroughStreetOwnedBy = currentplayer;
                        player4money = player4money - 180;
                        listbox_p4properties.Items.Add("Marlborough Street");
                        break;
                    case 19:
                        vineStreetOwnedBy = currentplayer;
                        player4money = player4money - 200;
                        listbox_p4properties.Items.Add("Vine Street");
                        break;
                    case 21:
                        strandOwnedBy = currentplayer;
                        player4money = player4money - 220;
                        listbox_p4properties.Items.Add("Strand");
                        break;
                    case 23:
                        fleetStreetOwnedBy = currentplayer;
                        player4money = player4money - 220;
                        listbox_p4properties.Items.Add("Fleet Street");
                        break;
                    case 24:
                        trafalgarSquareOwnedBy = currentplayer;
                        player4money = player4money - 240;
                        listbox_p4properties.Items.Add("Trafalgar Square");
                        break;
                    case 26:
                        leicesterSquareOwnedBy = currentplayer;
                        player4money = player4money - 260;
                        listbox_p4properties.Items.Add("Leicester Square");
                        break;
                    case 27:
                        coventryStreetOwnedBy = currentplayer;
                        player4money = player4money - 260;
                        listbox_p4properties.Items.Add("Coventry Street");
                        break;
                    case 29:
                        piccadillyOwnedBy = currentplayer;
                        player4money = player4money - 280;
                        listbox_p4properties.Items.Add("Piccadilly");
                        break;
                    case 31:
                        regentStreetOwnedBy = currentplayer;
                        player4money = player4money - 300;
                        listbox_p4properties.Items.Add("Regent Street");
                        break;
                    case 32:
                        oxfordStreetOwnedBy = currentplayer;
                        player4money = player4money - 300;
                        listbox_p4properties.Items.Add("Oxford Street");
                        break;
                    case 34:
                        bondStreetOwnedBy = currentplayer;
                        player4money = player4money - 320;
                        listbox_p4properties.Items.Add("Bond Street");
                        break;
                    case 37:
                        parkLaneOwnedBy = currentplayer;
                        player4money = player4money - 350;
                        listbox_p4properties.Items.Add("Park Lane");
                        break;
                    case 39:
                        mayfairOwnedBy = currentplayer;
                        player4money = player4money - 400;
                        listbox_p4properties.Items.Add("Mayfair");
                        break;
                }
            }
        }

        void buyUtility()
        {
            if (currentplayer == 1)
            {
                switch (player1position)
                {
                    case 12:
                        waterWorksOwnedBy = currentplayer;
                        player1money = player1money - 150;
                        player1UtilityCount++;
                        listbox_p1properties.Items.Add("Water Works");
                        break;
                    case 28:
                        electricCompanyOwnedBy = currentplayer;
                        player1money = player1money - 150;
                        player1UtilityCount++;
                        listbox_p1properties.Items.Add("Electric Company");
                        break;
                }
            }

            if (currentplayer == 2)
            {
                switch (player2position)
                {
                    case 12:
                        waterWorksOwnedBy = currentplayer;
                        player2money = player2money - 150;
                        player2UtilityCount++;
                        listbox_p2properties.Items.Add("Water Works");
                        break;
                    case 28:
                        electricCompanyOwnedBy = currentplayer;
                        player2money = player2money - 150;
                        player2UtilityCount++;
                        listbox_p2properties.Items.Add("Electric Company");
                        break;
                }
            }

            if (currentplayer == 3)
            {
                switch (player3position)
                {
                    case 12:
                        waterWorksOwnedBy = currentplayer;
                        player3money = player3money - 150;
                        player3UtilityCount++;
                        listbox_p3properties.Items.Add("Water Works");
                        break;
                    case 28:
                        electricCompanyOwnedBy = currentplayer;
                        player3money = player3money - 150;
                        player3UtilityCount++;
                        listbox_p3properties.Items.Add("Electric Company");
                        break;
                }
            }

            if (currentplayer == 4)
            {
                switch (player4position)
                {
                    case 12:
                        waterWorksOwnedBy = currentplayer;
                        player4money = player4money - 150;
                        player4UtilityCount++;
                        listbox_p4properties.Items.Add("Water Works");
                        break;
                    case 28:
                        electricCompanyOwnedBy = currentplayer;
                        player4money = player4money - 150;
                        player4UtilityCount++;
                        listbox_p4properties.Items.Add("Electric Company");
                        break;
                }
            }

        }

        void payRent(int playerToRecieve, int playerToGive, int price)
        {
            if (playerToGive == 1)
            {
                switch (playerToRecieve)
                {
                    case 2:
                        player2money = player2money + price;
                        player1money = player1money - price;
                        MessageBox.Show(player1alias + " has paid " + player2alias + " £" + price + " for rent.");
                        break;
                    case 3:
                        player3money = player3money + price;
                        player1money = player1money - price;
                        MessageBox.Show(player1alias + " has paid " + player3alias + " £" + price + " for rent.");
                        break;
                    case 4:
                        player4money = player4money + price;
                        player1money = player1money - price;
                        MessageBox.Show(player1alias + " has paid " + player4alias + " £" + price + " for rent.");
                        break;
                }
            }
            else if (playerToGive == 2)
            {
                switch (playerToRecieve)
                {
                    case 1:
                        player1money = player1money + price;
                        player2money = player2money - price;
                        MessageBox.Show(player2alias + " has paid " + player1alias + " £" + price + " for rent.");
                        break;
                    case 3:
                        player3money = player3money + price;
                        player2money = player2money - price;
                        MessageBox.Show(player2alias + " has paid " + player3alias + " £" + price + " for rent.");
                        break;
                    case 4:
                        player4money = player4money + price;
                        player2money = player2money - price;
                        MessageBox.Show(player2alias + " has paid " + player4alias + " £" + price + " for rent.");
                        break;
                }
            }
            else if (playerToGive == 3)
            {
                switch (playerToRecieve)
                {
                    case 1:
                        player1money = player1money + price;
                        player3money = player3money - price;
                        MessageBox.Show(player3alias + " has paid " + player1alias + " £" + price + " for rent.");
                        break;
                    case 2:
                        player2money = player2money + price;
                        player3money = player3money - price;
                        MessageBox.Show(player3alias + " has paid " + player2alias + " £" + price + " for rent.");
                        break;
                    case 4:
                        player4money = player4money + price;
                        player3money = player3money - price;
                        MessageBox.Show(player3alias + " has paid " + player4alias + " £" + price + " for rent.");
                        break;
                }
            }
            else if (playerToGive == 4)
            {
                switch (playerToRecieve)
                {
                    case 1:
                        player1money = player1money + price;
                        player4money = player4money - price;
                        MessageBox.Show(player4alias + " has paid " + player1alias + " £" + price + " for rent.");
                        break;
                    case 2:
                        player2money = player2money + price;
                        player4money = player4money - price;
                        MessageBox.Show(player4alias + " has paid " + player2alias + " £" + price + " for rent.");
                        break;
                    case 3:
                        player3money = player3money + price;
                        player4money = player4money - price;
                        MessageBox.Show(player4alias + " has paid " + player3alias + " £" + price + " for rent.");
                        break;
                }
            }
        }

        void payUtility(int playerToRecieve, int playerToGive)
        {
            if (playerToGive == 1)
            {
                int multiplier = 0;
                switch (playerToRecieve)
                {
                    case 2:
                        if (player2UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player2UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player2money = (player2money + (multiplier * dicetotalvalue));
                        player1money = (player1money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player1alias + " has paid " + (multiplier*dicetotalvalue) + " in utility bills to " + player2alias + ".");
                        break;
                    case 3:
                        if (player3UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player3UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player3money = (player3money + (multiplier * dicetotalvalue));
                        player1money = (player1money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player1alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player3alias + ".");
                        break;
                    case 4:
                        if (player4UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player4UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player4money = (player4money + (multiplier * dicetotalvalue));
                        player1money = (player1money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player1alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player4alias + ".");
                        break;
                }
            }

            else if (playerToGive == 2)
            {
                int multiplier = 0;
                switch (playerToRecieve)
                {
                    case 1:
                        if (player1UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player1UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player1money = (player1money + (multiplier * dicetotalvalue));
                        player2money = (player2money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player2alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player1alias + ".");
                        break;
                    case 3:
                        if (player3UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player3UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player3money = (player3money + (multiplier * dicetotalvalue));
                        player2money = (player2money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player2alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player3alias + ".");
                        break;
                    case 4:
                        if (player4UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player4UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player4money = (player4money + (multiplier * dicetotalvalue));
                        player2money = (player2money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player2alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player4alias + ".");
                        break;
                }
            }

            else if (playerToGive == 3)
            {
                int multiplier = 0;
                switch (playerToRecieve)
                {
                    case 1:
                        if (player1UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player1UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player1money = (player1money + (multiplier * dicetotalvalue));
                        player3money = (player3money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player3alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player1alias + ".");
                        break;
                    case 2:
                        if (player2UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player2UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player2money = (player2money + (multiplier * dicetotalvalue));
                        player3money = (player3money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player3alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player2alias + ".");
                        break;
                    case 4:
                        if (player4UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player4UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player4money = (player4money + (multiplier * dicetotalvalue));
                        player3money = (player3money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player3alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player4alias + ".");
                        break;
                }
            }

            if (playerToGive == 4)
            {
                int multiplier = 0;
                switch (playerToRecieve)
                {
                    case 1:
                        if (player1UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player1UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player1money = (player1money + (multiplier * dicetotalvalue));
                        player4money = (player4money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player4alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player1alias + ".");
                        break;
                    case 2:
                        if (player2UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player2UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player2money = (player2money + (multiplier * dicetotalvalue));
                        player4money = (player4money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player4alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player2alias + ".");
                        break;
                    case 3:
                        if (player3UtilityCount == 1)
                        {
                            multiplier = 4;
                        }
                        else if (player3UtilityCount == 2)
                        {
                            multiplier = 10;
                        }
                        player3money = (player3money + (multiplier * dicetotalvalue));
                        player4money = (player4money - (multiplier * dicetotalvalue));
                        MessageBox.Show(player4alias + " has paid " + (multiplier * dicetotalvalue) + " in utility bills to " + player3alias + ".");
                        break;
                }
            }

        }

        void CheckBankruptcy()
        {
            if (player1money < 0)
            {
                BankruptPlayer1();
            }

            if (player2money < 0)
            {
                BankruptPlayer2();
            }

            if (player3money < 0)
            {
                BankruptPlayer3();
            }

            if (player4money < 0)
            {
                BankruptPlayer4();
            }
        }

        void BankruptPlayer1()
        {
            player1IsActive = false;
            lbl_player1money.Text = ("Player 1 (Bankrupt)");
            character_player1.Visible = false;
        }

        void BankruptPlayer2()
        {
            player2IsActive = false;
            lbl_player2money.Text = ("Player 2 (Bankrupt)");
            character_player2.Visible = false;
        }

        void BankruptPlayer3()
        {
            player3IsActive = false;
            lbl_player3money.Text = ("Player 3 (Bankrupt)");
            character_player3.Visible = false;
        }

        void BankruptPlayer4()
        {
            player4IsActive = false;
            lbl_player4money.Text = ("Player 4 (Bankrupt)");
            character_player4.Visible = false;
        }

        void p1LeaveJail()
        {
            player1IsInJail = false;
            player1position = 10;
            MessageBox.Show("Player 1 has left jail");
            player1JailCounter = 0;
            debug_p1prisoncounter.Visible = false;
        }
        void p2LeaveJail()
        {
            player2IsInJail = false;
            player2position = 10;
            MessageBox.Show("Player 2 has left jail");
            player2JailCounter = 0;
            debug_p2prisoncounter.Visible = false;
        }
        void p3LeaveJail()
        {
            player3IsInJail = false;
            player3position = 10;
            MessageBox.Show("Player 3 has left jail");
            player3JailCounter = 0;
            debug_p3_prisoncounter.Visible = false;
        }
        void p4LeaveJail()
        {
            player4IsInJail = false;
            player4position = 10;
            MessageBox.Show("Player 4 has left jail");
            player4JailCounter = 0;
            debug_p4_prisoncounter.Visible = false;
        }
    }
}
