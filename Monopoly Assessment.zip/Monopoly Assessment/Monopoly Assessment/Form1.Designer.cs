﻿namespace Monopoly_Assessment
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.character_player1 = new System.Windows.Forms.PictureBox();
            this.character_player2 = new System.Windows.Forms.PictureBox();
            this.character_player3 = new System.Windows.Forms.PictureBox();
            this.character_player4 = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lbl_scoreheader = new System.Windows.Forms.Label();
            this.lbl_player1money = new System.Windows.Forms.Label();
            this.lbl_player2money = new System.Windows.Forms.Label();
            this.lbl_player3money = new System.Windows.Forms.Label();
            this.lbl_player4money = new System.Windows.Forms.Label();
            this.btn_throwdice = new System.Windows.Forms.Button();
            this.lbl_dice1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_dice2 = new System.Windows.Forms.Label();
            this.btn_startgame = new System.Windows.Forms.Button();
            this.radiobtn_2players = new System.Windows.Forms.RadioButton();
            this.radiobtn_3players = new System.Windows.Forms.RadioButton();
            this.radiobtn_4players = new System.Windows.Forms.RadioButton();
            this.btn_ok_players = new System.Windows.Forms.Button();
            this.lbl_playerturn = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_debug_totalplayers = new System.Windows.Forms.Label();
            this.btn_debug_moveplayerby1 = new System.Windows.Forms.Button();
            this.lbl_debug_p1_position = new System.Windows.Forms.Label();
            this.lbl_debug_p2_position = new System.Windows.Forms.Label();
            this.lbl_debug_p3_position = new System.Windows.Forms.Label();
            this.lbl_debug_p4_position = new System.Windows.Forms.Label();
            this.btn_debug_chance = new System.Windows.Forms.Button();
            this.btn_debug_communitychest = new System.Windows.Forms.Button();
            this.img_dice1 = new System.Windows.Forms.PictureBox();
            this.img_dice2 = new System.Windows.Forms.PictureBox();
            this.img_chancecard = new System.Windows.Forms.PictureBox();
            this.img_communitychestcard = new System.Windows.Forms.PictureBox();
            this.listbox_p1properties = new System.Windows.Forms.ListBox();
            this.listbox_p2properties = new System.Windows.Forms.ListBox();
            this.listbox_p3properties = new System.Windows.Forms.ListBox();
            this.listbox_p4properties = new System.Windows.Forms.ListBox();
            this.debug_p1prisoncounter = new System.Windows.Forms.Label();
            this.debug_p2prisoncounter = new System.Windows.Forms.Label();
            this.debug_p3_prisoncounter = new System.Windows.Forms.Label();
            this.debug_p4_prisoncounter = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.character_player1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.character_player2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.character_player3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.character_player4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_dice1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_dice2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_chancecard)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_communitychestcard)).BeginInit();
            this.SuspendLayout();
            // 
            // character_player1
            // 
            this.character_player1.BackColor = System.Drawing.Color.Red;
            this.character_player1.Location = new System.Drawing.Point(60, 910);
            this.character_player1.Name = "character_player1";
            this.character_player1.Size = new System.Drawing.Size(25, 25);
            this.character_player1.TabIndex = 0;
            this.character_player1.TabStop = false;
            this.character_player1.Visible = false;
            // 
            // character_player2
            // 
            this.character_player2.BackColor = System.Drawing.Color.Blue;
            this.character_player2.Location = new System.Drawing.Point(88, 910);
            this.character_player2.Name = "character_player2";
            this.character_player2.Size = new System.Drawing.Size(25, 25);
            this.character_player2.TabIndex = 1;
            this.character_player2.TabStop = false;
            this.character_player2.Visible = false;
            // 
            // character_player3
            // 
            this.character_player3.BackColor = System.Drawing.Color.Yellow;
            this.character_player3.Location = new System.Drawing.Point(60, 939);
            this.character_player3.Name = "character_player3";
            this.character_player3.Size = new System.Drawing.Size(25, 25);
            this.character_player3.TabIndex = 2;
            this.character_player3.TabStop = false;
            this.character_player3.Visible = false;
            // 
            // character_player4
            // 
            this.character_player4.BackColor = System.Drawing.Color.Lime;
            this.character_player4.Location = new System.Drawing.Point(88, 939);
            this.character_player4.Name = "character_player4";
            this.character_player4.Size = new System.Drawing.Size(25, 25);
            this.character_player4.TabIndex = 3;
            this.character_player4.TabStop = false;
            this.character_player4.Visible = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(-2, -4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1024, 1027);
            this.pictureBox1.TabIndex = 4;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // lbl_scoreheader
            // 
            this.lbl_scoreheader.AutoSize = true;
            this.lbl_scoreheader.Font = new System.Drawing.Font("Berlin Sans FB", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_scoreheader.ForeColor = System.Drawing.Color.White;
            this.lbl_scoreheader.Location = new System.Drawing.Point(1055, 12);
            this.lbl_scoreheader.Name = "lbl_scoreheader";
            this.lbl_scoreheader.Size = new System.Drawing.Size(144, 26);
            this.lbl_scoreheader.TabIndex = 5;
            this.lbl_scoreheader.Text = "Game Details";
            // 
            // lbl_player1money
            // 
            this.lbl_player1money.AutoSize = true;
            this.lbl_player1money.Font = new System.Drawing.Font("Berlin Sans FB", 15F);
            this.lbl_player1money.ForeColor = System.Drawing.Color.White;
            this.lbl_player1money.Location = new System.Drawing.Point(1048, 48);
            this.lbl_player1money.Name = "lbl_player1money";
            this.lbl_player1money.Size = new System.Drawing.Size(80, 23);
            this.lbl_player1money.TabIndex = 6;
            this.lbl_player1money.Text = "Player 1:";
            this.lbl_player1money.Visible = false;
            // 
            // lbl_player2money
            // 
            this.lbl_player2money.AutoSize = true;
            this.lbl_player2money.Font = new System.Drawing.Font("Berlin Sans FB", 15F);
            this.lbl_player2money.ForeColor = System.Drawing.Color.White;
            this.lbl_player2money.Location = new System.Drawing.Point(1048, 143);
            this.lbl_player2money.Name = "lbl_player2money";
            this.lbl_player2money.Size = new System.Drawing.Size(84, 23);
            this.lbl_player2money.TabIndex = 7;
            this.lbl_player2money.Text = "Player 2:";
            this.lbl_player2money.Visible = false;
            // 
            // lbl_player3money
            // 
            this.lbl_player3money.AutoSize = true;
            this.lbl_player3money.Font = new System.Drawing.Font("Berlin Sans FB", 15F);
            this.lbl_player3money.ForeColor = System.Drawing.Color.White;
            this.lbl_player3money.Location = new System.Drawing.Point(1048, 236);
            this.lbl_player3money.Name = "lbl_player3money";
            this.lbl_player3money.Size = new System.Drawing.Size(83, 23);
            this.lbl_player3money.TabIndex = 8;
            this.lbl_player3money.Text = "Player 3:";
            this.lbl_player3money.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lbl_player3money.Visible = false;
            // 
            // lbl_player4money
            // 
            this.lbl_player4money.AutoSize = true;
            this.lbl_player4money.Font = new System.Drawing.Font("Berlin Sans FB", 15F);
            this.lbl_player4money.ForeColor = System.Drawing.Color.White;
            this.lbl_player4money.Location = new System.Drawing.Point(1049, 331);
            this.lbl_player4money.Name = "lbl_player4money";
            this.lbl_player4money.Size = new System.Drawing.Size(84, 23);
            this.lbl_player4money.TabIndex = 9;
            this.lbl_player4money.Text = "Player 4:";
            this.lbl_player4money.Visible = false;
            // 
            // btn_throwdice
            // 
            this.btn_throwdice.BackColor = System.Drawing.Color.White;
            this.btn_throwdice.Font = new System.Drawing.Font("Berlin Sans FB", 12.25F);
            this.btn_throwdice.Location = new System.Drawing.Point(1044, 977);
            this.btn_throwdice.Name = "btn_throwdice";
            this.btn_throwdice.Size = new System.Drawing.Size(173, 35);
            this.btn_throwdice.TabIndex = 12;
            this.btn_throwdice.Text = "Throw Dice";
            this.btn_throwdice.UseVisualStyleBackColor = false;
            this.btn_throwdice.Visible = false;
            this.btn_throwdice.Click += new System.EventHandler(this.btn_throwdice_Click);
            // 
            // lbl_dice1
            // 
            this.lbl_dice1.AutoSize = true;
            this.lbl_dice1.Font = new System.Drawing.Font("Berlin Sans FB", 15F);
            this.lbl_dice1.ForeColor = System.Drawing.Color.White;
            this.lbl_dice1.Location = new System.Drawing.Point(1041, 942);
            this.lbl_dice1.Name = "lbl_dice1";
            this.lbl_dice1.Size = new System.Drawing.Size(62, 23);
            this.lbl_dice1.TabIndex = 13;
            this.lbl_dice1.Text = "Dice 1:";
            this.lbl_dice1.Visible = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(1045, 773);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 14;
            this.label2.Text = "label2";
            // 
            // lbl_dice2
            // 
            this.lbl_dice2.AutoSize = true;
            this.lbl_dice2.Font = new System.Drawing.Font("Berlin Sans FB", 15F);
            this.lbl_dice2.ForeColor = System.Drawing.Color.White;
            this.lbl_dice2.Location = new System.Drawing.Point(1134, 942);
            this.lbl_dice2.Name = "lbl_dice2";
            this.lbl_dice2.Size = new System.Drawing.Size(71, 23);
            this.lbl_dice2.TabIndex = 15;
            this.lbl_dice2.Text = "Dice 2: ";
            this.lbl_dice2.Visible = false;
            // 
            // btn_startgame
            // 
            this.btn_startgame.Font = new System.Drawing.Font("Berlin Sans FB", 12.25F);
            this.btn_startgame.Location = new System.Drawing.Point(1040, 585);
            this.btn_startgame.Name = "btn_startgame";
            this.btn_startgame.Size = new System.Drawing.Size(181, 29);
            this.btn_startgame.TabIndex = 19;
            this.btn_startgame.Text = "Start Game";
            this.btn_startgame.UseVisualStyleBackColor = true;
            this.btn_startgame.Click += new System.EventHandler(this.btn_startgame_Click);
            // 
            // radiobtn_2players
            // 
            this.radiobtn_2players.AutoSize = true;
            this.radiobtn_2players.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.radiobtn_2players.Font = new System.Drawing.Font("Berlin Sans FB", 12.25F);
            this.radiobtn_2players.ForeColor = System.Drawing.Color.White;
            this.radiobtn_2players.Location = new System.Drawing.Point(1040, 621);
            this.radiobtn_2players.Name = "radiobtn_2players";
            this.radiobtn_2players.Size = new System.Drawing.Size(90, 23);
            this.radiobtn_2players.TabIndex = 20;
            this.radiobtn_2players.TabStop = true;
            this.radiobtn_2players.Text = "2 Players";
            this.radiobtn_2players.UseVisualStyleBackColor = true;
            this.radiobtn_2players.Visible = false;
            this.radiobtn_2players.CheckedChanged += new System.EventHandler(this.radiobtn_2players_CheckedChanged);
            // 
            // radiobtn_3players
            // 
            this.radiobtn_3players.AutoSize = true;
            this.radiobtn_3players.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.radiobtn_3players.Font = new System.Drawing.Font("Berlin Sans FB", 12.25F);
            this.radiobtn_3players.ForeColor = System.Drawing.Color.White;
            this.radiobtn_3players.Location = new System.Drawing.Point(1040, 645);
            this.radiobtn_3players.Name = "radiobtn_3players";
            this.radiobtn_3players.Size = new System.Drawing.Size(90, 23);
            this.radiobtn_3players.TabIndex = 21;
            this.radiobtn_3players.TabStop = true;
            this.radiobtn_3players.Text = "3 Players";
            this.radiobtn_3players.UseVisualStyleBackColor = true;
            this.radiobtn_3players.Visible = false;
            this.radiobtn_3players.CheckedChanged += new System.EventHandler(this.radiobtn_3players_CheckedChanged);
            // 
            // radiobtn_4players
            // 
            this.radiobtn_4players.AutoSize = true;
            this.radiobtn_4players.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.radiobtn_4players.Font = new System.Drawing.Font("Berlin Sans FB", 12.25F);
            this.radiobtn_4players.ForeColor = System.Drawing.Color.White;
            this.radiobtn_4players.Location = new System.Drawing.Point(1040, 669);
            this.radiobtn_4players.Name = "radiobtn_4players";
            this.radiobtn_4players.Size = new System.Drawing.Size(91, 23);
            this.radiobtn_4players.TabIndex = 22;
            this.radiobtn_4players.TabStop = true;
            this.radiobtn_4players.Text = "4 Players";
            this.radiobtn_4players.UseVisualStyleBackColor = true;
            this.radiobtn_4players.Visible = false;
            this.radiobtn_4players.CheckedChanged += new System.EventHandler(this.radiobtn_4players_CheckedChanged);
            // 
            // btn_ok_players
            // 
            this.btn_ok_players.Font = new System.Drawing.Font("Berlin Sans FB", 12F);
            this.btn_ok_players.Location = new System.Drawing.Point(1149, 638);
            this.btn_ok_players.Name = "btn_ok_players";
            this.btn_ok_players.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.btn_ok_players.Size = new System.Drawing.Size(56, 36);
            this.btn_ok_players.TabIndex = 23;
            this.btn_ok_players.Text = "OK";
            this.btn_ok_players.UseVisualStyleBackColor = true;
            this.btn_ok_players.Visible = false;
            this.btn_ok_players.Click += new System.EventHandler(this.btn_ok_players_Click);
            // 
            // lbl_playerturn
            // 
            this.lbl_playerturn.AutoSize = true;
            this.lbl_playerturn.BackColor = System.Drawing.Color.DarkRed;
            this.lbl_playerturn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbl_playerturn.Font = new System.Drawing.Font("Berlin Sans FB", 30.25F);
            this.lbl_playerturn.ForeColor = System.Drawing.Color.White;
            this.lbl_playerturn.Location = new System.Drawing.Point(382, 139);
            this.lbl_playerturn.Name = "lbl_playerturn";
            this.lbl_playerturn.Size = new System.Drawing.Size(272, 47);
            this.lbl_playerturn.TabIndex = 24;
            this.lbl_playerturn.Text = "Player(n) Turn";
            this.lbl_playerturn.Visible = false;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(143, 669);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(153, 23);
            this.button1.TabIndex = 25;
            this.button1.Text = "Next Player debug";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.White;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(143, 759);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 17);
            this.label1.TabIndex = 26;
            this.label1.Text = "label1";
            // 
            // lbl_debug_totalplayers
            // 
            this.lbl_debug_totalplayers.AutoSize = true;
            this.lbl_debug_totalplayers.BackColor = System.Drawing.Color.White;
            this.lbl_debug_totalplayers.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_debug_totalplayers.ForeColor = System.Drawing.Color.Black;
            this.lbl_debug_totalplayers.Location = new System.Drawing.Point(143, 780);
            this.lbl_debug_totalplayers.Name = "lbl_debug_totalplayers";
            this.lbl_debug_totalplayers.Size = new System.Drawing.Size(95, 17);
            this.lbl_debug_totalplayers.TabIndex = 27;
            this.lbl_debug_totalplayers.Text = "Total Players:";
            // 
            // btn_debug_moveplayerby1
            // 
            this.btn_debug_moveplayerby1.Location = new System.Drawing.Point(144, 699);
            this.btn_debug_moveplayerby1.Name = "btn_debug_moveplayerby1";
            this.btn_debug_moveplayerby1.Size = new System.Drawing.Size(152, 23);
            this.btn_debug_moveplayerby1.TabIndex = 28;
            this.btn_debug_moveplayerby1.Text = "move player by 1";
            this.btn_debug_moveplayerby1.UseVisualStyleBackColor = true;
            this.btn_debug_moveplayerby1.Click += new System.EventHandler(this.btn_debug_moveplayerby1_Click);
            // 
            // lbl_debug_p1_position
            // 
            this.lbl_debug_p1_position.AutoSize = true;
            this.lbl_debug_p1_position.BackColor = System.Drawing.Color.White;
            this.lbl_debug_p1_position.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_debug_p1_position.ForeColor = System.Drawing.Color.Black;
            this.lbl_debug_p1_position.Location = new System.Drawing.Point(143, 801);
            this.lbl_debug_p1_position.Name = "lbl_debug_p1_position";
            this.lbl_debug_p1_position.Size = new System.Drawing.Size(92, 17);
            this.lbl_debug_p1_position.TabIndex = 29;
            this.lbl_debug_p1_position.Text = "Player 1 Pos:";
            // 
            // lbl_debug_p2_position
            // 
            this.lbl_debug_p2_position.AutoSize = true;
            this.lbl_debug_p2_position.BackColor = System.Drawing.Color.White;
            this.lbl_debug_p2_position.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_debug_p2_position.ForeColor = System.Drawing.Color.Black;
            this.lbl_debug_p2_position.Location = new System.Drawing.Point(142, 822);
            this.lbl_debug_p2_position.Name = "lbl_debug_p2_position";
            this.lbl_debug_p2_position.Size = new System.Drawing.Size(96, 17);
            this.lbl_debug_p2_position.TabIndex = 30;
            this.lbl_debug_p2_position.Text = "Player 2 Pos: ";
            // 
            // lbl_debug_p3_position
            // 
            this.lbl_debug_p3_position.AutoSize = true;
            this.lbl_debug_p3_position.BackColor = System.Drawing.Color.White;
            this.lbl_debug_p3_position.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_debug_p3_position.ForeColor = System.Drawing.Color.Black;
            this.lbl_debug_p3_position.Location = new System.Drawing.Point(142, 843);
            this.lbl_debug_p3_position.Name = "lbl_debug_p3_position";
            this.lbl_debug_p3_position.Size = new System.Drawing.Size(92, 17);
            this.lbl_debug_p3_position.TabIndex = 31;
            this.lbl_debug_p3_position.Text = "Player 3 Pos:";
            // 
            // lbl_debug_p4_position
            // 
            this.lbl_debug_p4_position.AutoSize = true;
            this.lbl_debug_p4_position.BackColor = System.Drawing.Color.White;
            this.lbl_debug_p4_position.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.25F);
            this.lbl_debug_p4_position.ForeColor = System.Drawing.Color.Black;
            this.lbl_debug_p4_position.Location = new System.Drawing.Point(142, 864);
            this.lbl_debug_p4_position.Name = "lbl_debug_p4_position";
            this.lbl_debug_p4_position.Size = new System.Drawing.Size(92, 17);
            this.lbl_debug_p4_position.TabIndex = 32;
            this.lbl_debug_p4_position.Text = "Player 4 Pos:";
            // 
            // btn_debug_chance
            // 
            this.btn_debug_chance.Location = new System.Drawing.Point(143, 728);
            this.btn_debug_chance.Name = "btn_debug_chance";
            this.btn_debug_chance.Size = new System.Drawing.Size(75, 23);
            this.btn_debug_chance.TabIndex = 33;
            this.btn_debug_chance.Text = "Chance";
            this.btn_debug_chance.UseVisualStyleBackColor = true;
            this.btn_debug_chance.Click += new System.EventHandler(this.btn_debug_chance_Click);
            // 
            // btn_debug_communitychest
            // 
            this.btn_debug_communitychest.Location = new System.Drawing.Point(221, 728);
            this.btn_debug_communitychest.Name = "btn_debug_communitychest";
            this.btn_debug_communitychest.Size = new System.Drawing.Size(75, 23);
            this.btn_debug_communitychest.TabIndex = 34;
            this.btn_debug_communitychest.Text = "C Chest";
            this.btn_debug_communitychest.UseVisualStyleBackColor = true;
            this.btn_debug_communitychest.Click += new System.EventHandler(this.btn_debug_communitychest_Click);
            // 
            // img_dice1
            // 
            this.img_dice1.BackColor = System.Drawing.Color.Transparent;
            this.img_dice1.Location = new System.Drawing.Point(1044, 870);
            this.img_dice1.Name = "img_dice1";
            this.img_dice1.Size = new System.Drawing.Size(73, 65);
            this.img_dice1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_dice1.TabIndex = 35;
            this.img_dice1.TabStop = false;
            this.img_dice1.Click += new System.EventHandler(this.pictureBox3_Click);
            // 
            // img_dice2
            // 
            this.img_dice2.Location = new System.Drawing.Point(1127, 870);
            this.img_dice2.Name = "img_dice2";
            this.img_dice2.Size = new System.Drawing.Size(72, 65);
            this.img_dice2.TabIndex = 36;
            this.img_dice2.TabStop = false;
            // 
            // img_chancecard
            // 
            this.img_chancecard.Image = ((System.Drawing.Image)(resources.GetObject("img_chancecard.Image")));
            this.img_chancecard.Location = new System.Drawing.Point(664, 621);
            this.img_chancecard.Name = "img_chancecard";
            this.img_chancecard.Size = new System.Drawing.Size(154, 225);
            this.img_chancecard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_chancecard.TabIndex = 37;
            this.img_chancecard.TabStop = false;
            // 
            // img_communitychestcard
            // 
            this.img_communitychestcard.Image = ((System.Drawing.Image)(resources.GetObject("img_communitychestcard.Image")));
            this.img_communitychestcard.Location = new System.Drawing.Point(210, 176);
            this.img_communitychestcard.Name = "img_communitychestcard";
            this.img_communitychestcard.Size = new System.Drawing.Size(154, 225);
            this.img_communitychestcard.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.img_communitychestcard.TabIndex = 38;
            this.img_communitychestcard.TabStop = false;
            // 
            // listbox_p1properties
            // 
            this.listbox_p1properties.BackColor = System.Drawing.Color.Black;
            this.listbox_p1properties.Font = new System.Drawing.Font("Berlin Sans FB", 10.25F);
            this.listbox_p1properties.ForeColor = System.Drawing.Color.White;
            this.listbox_p1properties.FormattingEnabled = true;
            this.listbox_p1properties.ItemHeight = 16;
            this.listbox_p1properties.Location = new System.Drawing.Point(1051, 71);
            this.listbox_p1properties.Name = "listbox_p1properties";
            this.listbox_p1properties.Size = new System.Drawing.Size(155, 68);
            this.listbox_p1properties.TabIndex = 39;
            this.listbox_p1properties.Visible = false;
            // 
            // listbox_p2properties
            // 
            this.listbox_p2properties.BackColor = System.Drawing.Color.Black;
            this.listbox_p2properties.Font = new System.Drawing.Font("Berlin Sans FB", 10.25F);
            this.listbox_p2properties.ForeColor = System.Drawing.Color.White;
            this.listbox_p2properties.FormattingEnabled = true;
            this.listbox_p2properties.ItemHeight = 16;
            this.listbox_p2properties.Location = new System.Drawing.Point(1052, 166);
            this.listbox_p2properties.Name = "listbox_p2properties";
            this.listbox_p2properties.Size = new System.Drawing.Size(155, 68);
            this.listbox_p2properties.TabIndex = 40;
            this.listbox_p2properties.Visible = false;
            // 
            // listbox_p3properties
            // 
            this.listbox_p3properties.BackColor = System.Drawing.Color.Black;
            this.listbox_p3properties.Font = new System.Drawing.Font("Berlin Sans FB", 10.25F);
            this.listbox_p3properties.ForeColor = System.Drawing.Color.White;
            this.listbox_p3properties.FormattingEnabled = true;
            this.listbox_p3properties.ItemHeight = 16;
            this.listbox_p3properties.Location = new System.Drawing.Point(1051, 259);
            this.listbox_p3properties.Name = "listbox_p3properties";
            this.listbox_p3properties.Size = new System.Drawing.Size(155, 68);
            this.listbox_p3properties.TabIndex = 41;
            this.listbox_p3properties.Visible = false;
            // 
            // listbox_p4properties
            // 
            this.listbox_p4properties.BackColor = System.Drawing.Color.Black;
            this.listbox_p4properties.Font = new System.Drawing.Font("Berlin Sans FB", 10.25F);
            this.listbox_p4properties.ForeColor = System.Drawing.Color.White;
            this.listbox_p4properties.FormattingEnabled = true;
            this.listbox_p4properties.HorizontalScrollbar = true;
            this.listbox_p4properties.ItemHeight = 16;
            this.listbox_p4properties.Location = new System.Drawing.Point(1052, 355);
            this.listbox_p4properties.Name = "listbox_p4properties";
            this.listbox_p4properties.Size = new System.Drawing.Size(155, 68);
            this.listbox_p4properties.TabIndex = 42;
            this.listbox_p4properties.Visible = false;
            // 
            // debug_p1prisoncounter
            // 
            this.debug_p1prisoncounter.AutoSize = true;
            this.debug_p1prisoncounter.BackColor = System.Drawing.Color.White;
            this.debug_p1prisoncounter.Font = new System.Drawing.Font("Berlin Sans FB", 10.25F);
            this.debug_p1prisoncounter.Location = new System.Drawing.Point(143, 551);
            this.debug_p1prisoncounter.Name = "debug_p1prisoncounter";
            this.debug_p1prisoncounter.Size = new System.Drawing.Size(103, 16);
            this.debug_p1prisoncounter.TabIndex = 43;
            this.debug_p1prisoncounter.Text = "p1_prisoncounter";
            this.debug_p1prisoncounter.Visible = false;
            // 
            // debug_p2prisoncounter
            // 
            this.debug_p2prisoncounter.AutoSize = true;
            this.debug_p2prisoncounter.BackColor = System.Drawing.Color.White;
            this.debug_p2prisoncounter.Font = new System.Drawing.Font("Berlin Sans FB", 10.25F);
            this.debug_p2prisoncounter.ForeColor = System.Drawing.Color.Black;
            this.debug_p2prisoncounter.Location = new System.Drawing.Point(143, 572);
            this.debug_p2prisoncounter.Name = "debug_p2prisoncounter";
            this.debug_p2prisoncounter.Size = new System.Drawing.Size(106, 16);
            this.debug_p2prisoncounter.TabIndex = 44;
            this.debug_p2prisoncounter.Text = "p2_prisoncounter";
            this.debug_p2prisoncounter.Visible = false;
            // 
            // debug_p3_prisoncounter
            // 
            this.debug_p3_prisoncounter.AutoSize = true;
            this.debug_p3_prisoncounter.BackColor = System.Drawing.Color.White;
            this.debug_p3_prisoncounter.Font = new System.Drawing.Font("Berlin Sans FB", 10.25F);
            this.debug_p3_prisoncounter.ForeColor = System.Drawing.Color.Black;
            this.debug_p3_prisoncounter.Location = new System.Drawing.Point(143, 594);
            this.debug_p3_prisoncounter.Name = "debug_p3_prisoncounter";
            this.debug_p3_prisoncounter.Size = new System.Drawing.Size(106, 16);
            this.debug_p3_prisoncounter.TabIndex = 45;
            this.debug_p3_prisoncounter.Text = "p3_prisoncounter";
            this.debug_p3_prisoncounter.Visible = false;
            // 
            // debug_p4_prisoncounter
            // 
            this.debug_p4_prisoncounter.AutoSize = true;
            this.debug_p4_prisoncounter.BackColor = System.Drawing.Color.White;
            this.debug_p4_prisoncounter.Font = new System.Drawing.Font("Berlin Sans FB", 10.25F);
            this.debug_p4_prisoncounter.ForeColor = System.Drawing.Color.Black;
            this.debug_p4_prisoncounter.Location = new System.Drawing.Point(143, 617);
            this.debug_p4_prisoncounter.Name = "debug_p4_prisoncounter";
            this.debug_p4_prisoncounter.Size = new System.Drawing.Size(106, 16);
            this.debug_p4_prisoncounter.TabIndex = 46;
            this.debug_p4_prisoncounter.Text = "p4_prisoncounter";
            this.debug_p4_prisoncounter.Visible = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(1239, 1024);
            this.Controls.Add(this.debug_p4_prisoncounter);
            this.Controls.Add(this.debug_p3_prisoncounter);
            this.Controls.Add(this.debug_p2prisoncounter);
            this.Controls.Add(this.debug_p1prisoncounter);
            this.Controls.Add(this.listbox_p4properties);
            this.Controls.Add(this.listbox_p3properties);
            this.Controls.Add(this.listbox_p2properties);
            this.Controls.Add(this.listbox_p1properties);
            this.Controls.Add(this.img_communitychestcard);
            this.Controls.Add(this.img_chancecard);
            this.Controls.Add(this.img_dice2);
            this.Controls.Add(this.img_dice1);
            this.Controls.Add(this.btn_debug_communitychest);
            this.Controls.Add(this.btn_debug_chance);
            this.Controls.Add(this.lbl_debug_p4_position);
            this.Controls.Add(this.lbl_debug_p3_position);
            this.Controls.Add(this.lbl_debug_p2_position);
            this.Controls.Add(this.lbl_debug_p1_position);
            this.Controls.Add(this.btn_debug_moveplayerby1);
            this.Controls.Add(this.lbl_debug_totalplayers);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lbl_playerturn);
            this.Controls.Add(this.btn_ok_players);
            this.Controls.Add(this.radiobtn_4players);
            this.Controls.Add(this.radiobtn_3players);
            this.Controls.Add(this.radiobtn_2players);
            this.Controls.Add(this.btn_startgame);
            this.Controls.Add(this.lbl_dice2);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.lbl_dice1);
            this.Controls.Add(this.btn_throwdice);
            this.Controls.Add(this.lbl_player4money);
            this.Controls.Add(this.lbl_player3money);
            this.Controls.Add(this.lbl_player2money);
            this.Controls.Add(this.lbl_player1money);
            this.Controls.Add(this.lbl_scoreheader);
            this.Controls.Add(this.character_player4);
            this.Controls.Add(this.character_player3);
            this.Controls.Add(this.character_player2);
            this.Controls.Add(this.character_player1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Name = "Form1";
            this.Text = "Monopoly";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.character_player1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.character_player2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.character_player3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.character_player4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_dice1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_dice2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_chancecard)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.img_communitychestcard)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox character_player1;
        private System.Windows.Forms.PictureBox character_player2;
        private System.Windows.Forms.PictureBox character_player3;
        private System.Windows.Forms.PictureBox character_player4;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbl_scoreheader;
        private System.Windows.Forms.Label lbl_player1money;
        private System.Windows.Forms.Label lbl_player2money;
        private System.Windows.Forms.Label lbl_player3money;
        private System.Windows.Forms.Label lbl_player4money;
        private System.Windows.Forms.Button btn_throwdice;
        private System.Windows.Forms.Label lbl_dice1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lbl_dice2;
        private System.Windows.Forms.Button btn_startgame;
        private System.Windows.Forms.RadioButton radiobtn_2players;
        private System.Windows.Forms.RadioButton radiobtn_3players;
        private System.Windows.Forms.RadioButton radiobtn_4players;
        private System.Windows.Forms.Button btn_ok_players;
        private System.Windows.Forms.Label lbl_playerturn;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbl_debug_totalplayers;
        private System.Windows.Forms.Button btn_debug_moveplayerby1;
        private System.Windows.Forms.Label lbl_debug_p1_position;
        private System.Windows.Forms.Label lbl_debug_p2_position;
        private System.Windows.Forms.Label lbl_debug_p3_position;
        private System.Windows.Forms.Label lbl_debug_p4_position;
        private System.Windows.Forms.Button btn_debug_chance;
        private System.Windows.Forms.Button btn_debug_communitychest;
        private System.Windows.Forms.PictureBox img_dice1;
        private System.Windows.Forms.PictureBox img_dice2;
        private System.Windows.Forms.PictureBox img_chancecard;
        private System.Windows.Forms.PictureBox img_communitychestcard;
        private System.Windows.Forms.ListBox listbox_p1properties;
        private System.Windows.Forms.ListBox listbox_p2properties;
        private System.Windows.Forms.ListBox listbox_p3properties;
        private System.Windows.Forms.ListBox listbox_p4properties;
        private System.Windows.Forms.Label debug_p1prisoncounter;
        private System.Windows.Forms.Label debug_p2prisoncounter;
        private System.Windows.Forms.Label debug_p3_prisoncounter;
        private System.Windows.Forms.Label debug_p4_prisoncounter;
    }
}

